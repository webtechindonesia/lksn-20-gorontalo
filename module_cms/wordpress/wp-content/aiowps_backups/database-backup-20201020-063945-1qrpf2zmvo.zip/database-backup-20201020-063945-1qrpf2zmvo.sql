-- All In One WP Security & Firewall 4.3.9.4
-- MySQL dump
-- 2020-10-20 06:39:45

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_cntctfrm_field`;

CREATE TABLE `wp_cntctfrm_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `wp_cntctfrm_field` VALUES("1","name");
INSERT INTO `wp_cntctfrm_field` VALUES("2","email");
INSERT INTO `wp_cntctfrm_field` VALUES("3","subject");
INSERT INTO `wp_cntctfrm_field` VALUES("4","message");
INSERT INTO `wp_cntctfrm_field` VALUES("5","gdpr");
INSERT INTO `wp_cntctfrm_field` VALUES("6","address");
INSERT INTO `wp_cntctfrm_field` VALUES("7","phone");
INSERT INTO `wp_cntctfrm_field` VALUES("8","attachment");
INSERT INTO `wp_cntctfrm_field` VALUES("9","attachment_explanations");
INSERT INTO `wp_cntctfrm_field` VALUES("10","send_copy");
INSERT INTO `wp_cntctfrm_field` VALUES("11","sent_from");
INSERT INTO `wp_cntctfrm_field` VALUES("12","date_time");
INSERT INTO `wp_cntctfrm_field` VALUES("13","coming_from");
INSERT INTO `wp_cntctfrm_field` VALUES("14","user_agent");


DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_comments` VALUES("1","1","A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2020-10-20 04:43:45","2020-10-20 04:43:45","Hi, this is a comment.
To get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.
Commenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.","0","1","","comment","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://localhost/lksn-20-gorontalo/module_cms/wordpress","yes");
INSERT INTO `wp_options` VALUES("2","home","http://localhost/lksn-20-gorontalo/module_cms/wordpress","yes");
INSERT INTO `wp_options` VALUES("3","blogname","Pusat Informasi Covid-19","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Just another WordPress site","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","yasdilofficial@gmail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("29","rewrite_rules","a:117:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:10:\"vslides/?$\";s:27:\"index.php?post_type=vslides\";s:40:\"vslides/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=vslides&feed=$matches[1]\";s:35:\"vslides/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=vslides&feed=$matches[1]\";s:27:\"vslides/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=vslides&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"vslides/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"vslides/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"vslides/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"vslides/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"vslides/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"vslides/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"vslides/([^/]+)/embed/?$\";s:40:\"index.php?vslides=$matches[1]&embed=true\";s:28:\"vslides/([^/]+)/trackback/?$\";s:34:\"index.php?vslides=$matches[1]&tb=1\";s:48:\"vslides/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?vslides=$matches[1]&feed=$matches[2]\";s:43:\"vslides/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?vslides=$matches[1]&feed=$matches[2]\";s:36:\"vslides/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?vslides=$matches[1]&paged=$matches[2]\";s:43:\"vslides/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?vslides=$matches[1]&cpage=$matches[2]\";s:32:\"vslides/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?vslides=$matches[1]&page=$matches[2]\";s:24:\"vslides/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"vslides/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"vslides/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"vslides/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"vslides/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"vslides/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:3:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:36:\"contact-form-plugin/contact_form.php\";i:2;s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","a:2:{i:0;s:93:\"C:\\xampp\\htdocs\\lksn-20-gorontalo\\module_cms\\wordpress/wp-content/themes/blankslate/style.css\";i:1;s:0:\"\";}","no");
INSERT INTO `wp_options` VALUES("40","template","blankslate","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","blankslate","yes");
INSERT INTO `wp_options` VALUES("42","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("43","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("44","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("45","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("46","db_version","48748","yes");
INSERT INTO `wp_options` VALUES("47","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("48","upload_path","","yes");
INSERT INTO `wp_options` VALUES("49","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("50","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("51","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("52","tag_base","","yes");
INSERT INTO `wp_options` VALUES("53","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("54","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("55","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("56","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("57","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("59","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("60","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("61","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("62","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("63","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("64","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("65","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("66","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("67","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("68","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("69","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("70","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("71","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("72","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("73","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("74","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("75","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("76","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("77","widget_text","a:5:{i:2;a:4:{s:5:\"title\";s:28:\"Ketahui Risiko dari COVID-19\";s:4:\"text\";s:381:\"COVID-19 merupakan penyakit yang disebabkan Novel Coronavirus 2019. Meski bergejala mirip dengan flu biasa, COVID-19 sampai saat ini memiliki fatalitas lebih tinggi. Virus ini juga menyebar dengan sangat cepat karena bisa pindah dari orang ke orang bahkan sebelum orang tersebut menunjukkan gejala.

&nbsp;

<a class=\"btn btn-light\" role=\"button\" href=\"#\">Periksa Diri Saya</a>\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:16:\"Di Sponsori oleh\";s:4:\"text\";s:728:\"<img class=\"size-medium wp-image-21\" src=\"http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/hut-tjp-300x36.gif\" alt=\"\" width=\"300\" height=\"36\" />     <img class=\"size-full wp-image-9\" src=\"http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/logo.png\" alt=\"\" width=\"120\" height=\"120\" />
<img class=\"size-medium wp-image-36\" src=\"http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/vice-1-360x240-1-300x200.png\" alt=\"\" width=\"300\" height=\"200\" /> <img class=\"size-medium wp-image-35\" src=\"http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/vice_logo_0-300x169.jpg\" alt=\"\" width=\"300\" height=\"169\" />\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:4;a:4:{s:5:\"title\";s:78:\"Tanya kepada sesama warga Gorontalo soal penanganan COVID-19 di Forum Pikobar!\";s:4:\"text\";s:62:\"<a class=\"btn btn-success\" role=\"button\" href=\"#\">Tanyakan</a>\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:5;a:4:{s:5:\"title\";s:19:\"Hubungi Call Center\";s:4:\"text\";s:586:\"<table class=\"table\">
  <thead>
    <tr>
      <th scope=\"col\">#</th>
      <th scope=\"col\">First</th>
      <th scope=\"col\">Last</th>
      <th scope=\"col\">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope=\"row\">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope=\"row\">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope=\"row\">3</th>
      <td>Larry</td>
      <td>the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("78","widget_rss","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("79","uninstall_plugins","a:2:{s:36:\"contact-form-plugin/contact_form.php\";s:23:\"cntctfrm_delete_options\";s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";s:21:\"wrjs_uninstall_slider\";}","no");
INSERT INTO `wp_options` VALUES("80","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("81","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("82","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("83","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("84","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("85","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("86","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("87","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("88","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("89","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("90","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("91","admin_email_lifespan","1618721025","yes");
INSERT INTO `wp_options` VALUES("92","disallowed_keys","","no");
INSERT INTO `wp_options` VALUES("93","comment_previously_approved","1","yes");
INSERT INTO `wp_options` VALUES("94","auto_plugin_theme_update_emails","a:0:{}","no");
INSERT INTO `wp_options` VALUES("95","initial_db_version","48748","yes");
INSERT INTO `wp_options` VALUES("96","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("97","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("98","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("103","sidebars_widgets","a:7:{s:19:\"wp_inactive_widgets\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}s:19:\"primary-widget-area\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:15:\"top-widget-area\";a:1:{i:0;s:6:\"text-2\";}s:18:\"bottom-widget-area\";a:1:{i:0;s:6:\"text-3\";}s:21:\"head-left-widget-area\";a:1:{i:0;s:6:\"text-5\";}s:22:\"head-right-widget-area\";a:1:{i:0;s:6:\"text-4\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("104","cron","a:8:{i:1603176226;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1603179566;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1603212226;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1603255426;a:2:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1603255434;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1603255439;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1603262366;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("113","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("115","recovery_keys","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("116","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.5.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.5.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.5.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.5.1-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.5.1\";s:7:\"version\";s:5:\"5.5.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1603169027;s:15:\"version_checked\";s:5:\"5.5.1\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("117","theme_mods_twentytwenty","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1603169095;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("119","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1603175964;s:7:\"checked\";a:5:{s:19:\"akismet/akismet.php\";s:5:\"4.1.6\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:7:\"4.3.9.4\";s:36:\"contact-form-plugin/contact_form.php\";s:5:\"4.1.5\";s:9:\"hello.php\";s:5:\"1.7.2\";s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";s:3:\"1.7\";}s:8:\"response\";a:2:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.4\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.5.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:36:\"contact-form-plugin/contact_form.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:33:\"w.org/plugins/contact-form-plugin\";s:4:\"slug\";s:19:\"contact-form-plugin\";s:6:\"plugin\";s:36:\"contact-form-plugin/contact_form.php\";s:11:\"new_version\";s:5:\"4.2.1\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/contact-form-plugin/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/contact-form-plugin.4.2.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/contact-form-plugin/assets/icon-256x256.png?rev=2318180\";s:2:\"1x\";s:72:\"https://ps.w.org/contact-form-plugin/assets/icon-128x128.png?rev=2318180\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/contact-form-plugin/assets/banner-1544x500.jpg?rev=2318180\";s:2:\"1x\";s:74:\"https://ps.w.org/contact-form-plugin/assets/banner-772x250.jpg?rev=2318180\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.5.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.6\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:41:\"w.org/plugins/wp-responsive-jquery-slider\";s:4:\"slug\";s:27:\"wp-responsive-jquery-slider\";s:6:\"plugin\";s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:58:\"https://wordpress.org/plugins/wp-responsive-jquery-slider/\";s:7:\"package\";s:74:\"https://downloads.wordpress.org/plugin/wp-responsive-jquery-slider.1.7.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:80:\"https://ps.w.org/wp-responsive-jquery-slider/assets/icon-128x128.jpg?rev=2108004\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:82:\"https://ps.w.org/wp-responsive-jquery-slider/assets/banner-772x250.jpg?rev=2108004\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES("122","_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1603169092;s:7:\"checked\";a:4:{s:10:\"blankslate\";s:6:\"2019.1\";s:14:\"twentynineteen\";s:3:\"1.7\";s:15:\"twentyseventeen\";s:3:\"2.4\";s:12:\"twentytwenty\";s:3:\"1.5\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:4:{s:10:\"blankslate\";a:6:{s:5:\"theme\";s:10:\"blankslate\";s:11:\"new_version\";s:6:\"2019.1\";s:3:\"url\";s:40:\"https://wordpress.org/themes/blankslate/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/blankslate.2019.1.zip\";s:8:\"requires\";s:3:\"5.1\";s:12:\"requires_php\";b:0;}s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.1.7.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentyseventeen\";a:6:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.4\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.4.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.5.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("123","_site_transient_timeout_browser_44a5e524f134e3228c7b0b16c2224ffc","1603773837","no");
INSERT INTO `wp_options` VALUES("124","_site_transient_browser_44a5e524f134e3228c7b0b16c2224ffc","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"86.0.4240.75\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("125","_site_transient_timeout_php_check_c6e81a88aa62f0eea87d84f96662ea28","1603773838","no");
INSERT INTO `wp_options` VALUES("126","_site_transient_php_check_c6e81a88aa62f0eea87d84f96662ea28","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("128","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("129","_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e","1603212292","no");
INSERT INTO `wp_options` VALUES("130","_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e","a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:2:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:75:\"Discussion Group: Writing a pitch for being accepted to speak at a WP event\";s:3:\"url\";s:68:\"https://www.meetup.com/learn-wordpress-discussions/events/273798352/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2020-10-19 07:00:00\";s:8:\"end_date\";s:19:\"2020-10-19 08:00:00\";s:20:\"start_unix_timestamp\";i:1603116000;s:18:\"end_unix_timestamp\";i:1603119600;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297;s:9:\"longitude\";d:-122.41999816895;}}i:1;a:10:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:17:\"WordCamp Bulgaria\";s:3:\"url\";s:35:\"https://bulgaria.wordcamp.org/2020/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2020-10-24 10:00:00\";s:8:\"end_date\";s:19:\"2020-10-24 10:00:00\";s:20:\"start_unix_timestamp\";i:1603522800;s:18:\"end_unix_timestamp\";i:1603522800;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"BG\";s:8:\"latitude\";d:42.733883;s:9:\"longitude\";d:25.48583;}}}}","no");
INSERT INTO `wp_options` VALUES("131","_transient_timeout_feed_9bbd59226dc36b9b26cd43f15694c5c3","1603212242","no");
INSERT INTO `wp_options` VALUES("132","_transient_feed_9bbd59226dc36b9b26cd43f15694c5c3","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"News –  – WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Oct 2020 09:34:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.6-alpha-49172\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"The Month in WordPress: September 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wordpress.org/news/2020/10/the-month-in-wordpress-september-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Oct 2020 09:34:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9026\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:363:\"This month was characterized by some exciting announcements from the WordPress core team! Read on to catch up with all the WordPress news and updates from September.&#160; WordPress 5.5.1 Launch On September 1, the&#160; Core team released WordPress 5.5.1. This maintenance release included several bug fixes for both core and the editor, and many other [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:8713:\"
<p>This month was characterized by some exciting announcements from the WordPress core team! Read on to catch up with all the WordPress news and updates from September.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.5.1 Launch</h2>



<p>On September 1, the&nbsp; Core team released <a href=\"https://wordpress.org/news/2020/09/wordpress-5-5-1-maintenance-release/\">WordPress 5.5.1</a>. This maintenance release included several bug fixes for both core and the editor, and many other enhancements. You can update to the latest version directly from your WordPress dashboard or <a href=\"https://wordpress.org/download/\">download</a> it directly from WordPress.org. The next major release will be <a href=\"https://make.wordpress.org/core/5-6/\">version 5.6</a>.</p>



<p>Want to be involved in the next release?&nbsp; You can help to build WordPress Core by following<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>, and joining the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Gutenberg 9.1, 9.0, and 8.9 are out</h2>



<p>The core team launched <a href=\"https://make.wordpress.org/core/2020/09/16/whats-new-in-gutenberg-16-september/\">version 9.0</a> of the Gutenberg plugin on September 16, and <a href=\"https://make.wordpress.org/core/2020/10/01/whats-new-in-gutenberg-30-september/\">version 9.1</a> on September 30. <a href=\"https://make.wordpress.org/core/2020/09/16/whats-new-in-gutenberg-16-september/\">Version 9.0</a> features some useful enhancements — like a new look for the navigation screen (with drag and drop support in the list view) and modifications to the query block (including search, filtering by author, and support for tags). <a href=\"https://make.wordpress.org/core/2020/10/01/whats-new-in-gutenberg-30-september/\">Version 9.1</a> adds improvements to global styles, along with improvements for the UI and several blocks. <a href=\"https://make.wordpress.org/core/2020/09/03/whats-new-in-gutenberg-2-september/\">Version 8.9</a> of Gutenberg, which came out earlier in September, enables the block-based widgets feature (also known as block areas, and was previously available in the experiments section) by default — replacing the default WordPress widgets to the plugin. You can find out more about the Gutenberg roadmap in the <a href=\"https://make.wordpress.org/core/2020/09/03/whats-next-in-gutenberg-september/\">What’s next in Gutenberg blog post</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Twenty Twenty One is the WordPress 5.6 default theme</h2>



<p><a href=\"https://make.wordpress.org/core/2020/09/23/introducing-twenty-twenty-one/\">Twenty Twenty One</a>, the brand new default theme for <a href=\"https://make.wordpress.org/core/5-6/\">WordPress 5.6</a>, has been announced! Twenty Twenty One is designed to be a blank canvas for the block editor, and will adopt a straightforward, yet refined, design. The theme has a limited color palette: a pastel green background color, two shades of dark grey for text, and a native set of system fonts. Twenty Twenty One will use a modified version of the <a href=\"https://wordpress.org/themes/seedlet/\">Seedlet theme</a> as its base. It will have a comprehensive system of nested CSS variables to make child theming easier, a native support for global styles, and full site editing.&nbsp;</p>



<p>Follow the <a href=\"https://make.wordpress.org/core/\">Make/Core</a> blog if you wish to contribute to Twenty Twenty One. There will be weekly meetings every Monday at 15:00 UTC and triage sessions every Friday at 15:00 UTC in the #core-themes Slack channel. Theme development will happen <a href=\"https://github.com/wordpress/twentytwentyone.\">on GitHub</a>. </p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>WordPress plugin authors can now <a href=\"https://meta.trac.wordpress.org/changeset/10255\">opt into confirming plugin updates via email</a>. This feature will allow plugin authors to approve any plugin updates over email before release.</li><li>September was the busiest month for online WordCamps so far, with seven events taking place: <a href=\"https://ogijima.wordcamp.org/2020/\">WordCamp Ogijima Online</a>, <a href=\"https://colombia.wordcamp.org/2020/\">WordCamp Colombia Online</a>, <a href=\"https://2020.asheville.wordcamp.org/2020/\">WordCamp Asheville, NC USA</a>, <a href=\"https://saopaulo.wordcamp.org/2020/\">WordCamp São Paulo, Brazil</a>, <a href=\"https://2020.virginiabeach.wordcamp.org/\">WordCamp Virginia Beach</a>, <a href=\"https://2020.lima.wordcamp.org/\">WordCamp Lima Peru</a>, and <a href=\"https://philadelphia.wordcamp.org/2020/\">WordCamp Philadelphia, PA, USA</a>. You can find live stream recaps of these events on their websites. The camps are also in the process of uploading their videos to <a href=\"https://wordpress.tv/\">WordPress.tv</a>. Check out the <a href=\"https://central.wordcamp.org/schedule/\">WordCamp Schedule</a> to follow upcoming online WordCamps!</li><li>The Themes team has added a <a href=\"https://meta.trac.wordpress.org/changeset/10240\">delist feature</a> to the themes directory. The feature will allow a theme to be temporarily hidden from search, while still making it available. The team may delist themes if they violate the <a href=\"https://make.wordpress.org/themes/handbook/review/required/\">Theme Directory guidelines</a>. </li><li>The Themes Team has also released its <a href=\"https://make.wordpress.org/themes/2020/09/25/new-package-to-allow-locally-hosting-webfonts/\">new web fonts Loader project</a>. The webfonts loader will allow theme developers to load web fonts from the user’s site, rather than through a third-party CDN. The project lives in the team’s <a href=\"https://github.com/WPTT/webfont-loader\">GitHub repository</a>.</li><li>The Support team is discussing<a href=\"https://make.wordpress.org/support/2020/09/talking-point-allowing-self-archival-of-topics/\"> the level of control users should have</a> over their support forum topics. The team is thinking of allowing users to archive their topics and lengthen time-to-edit to remove any semi-sensitive data. In a separate, but related, post, Support team members have started discussing <a href=\"https://make.wordpress.org/support/2020/09/talking-point-handling-support-for-commercial-users-on-the-wordpress-forums/\">how to curb support requests for commercial products</a>.</li><li>The Mobile team <a href=\"https://make.wordpress.org/core/2020/09/21/proposal-dual-licensing-gutenberg-under-gpl-v2-0-and-mpl-v2-0/\">came up with a proposal for dual licensing Gutenberg</a> under GPL 2.0 and MPL (Mozilla Public License) 2.0, so that non-WordPress software developers can potentially use it for their projects.  </li><li>Since Facebook and Instagram are deprecating oEmbeds, the Core Team <a href=\"https://make.wordpress.org/core/2020/09/22/facebook-and-instagram-embeds-to-be-deprecated-october-24th/\">will be removing Facebook and Instagram’s oEmbed endpoints</a> from WordPress core code. </li><li>Following extensive discussion, the Documentation team <a href=\"https://make.wordpress.org/docs/2020/09/14/external-linking-policy-meeting-notes-august-25th/\">has tentatively decided to allow external and commercial links in the WordPress documentation</a>. The team aims to publish a formal proposal that will be left open for feedback before finalizing it.</li><li>Members of the Polyglots and Marketing teams are celebrating the <a href=\"https://make.wordpress.org/polyglots/2020/09/09/lets-celebrate-international-translation-day-together/\">International Translation Day</a> for WordPress over the week of September 28 &#8211; October 4! Community members can join or organize translation events, or contribute to WordPress core, theme, or plugin translations during this period. </li><li><a href=\"https://wpaccessibilityday.org/\">WP Accessibility day</a> — a 24-hour global online event dedicated to addressing website accessibility in WordPress, is being held on October 2. The event is open for all and has <a href=\"https://wpaccessibilityday.org/#talk-time\">experts from all over the world as speakers</a>.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"9026\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 5.5.1 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2020/09/wordpress-5-5-1-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 01 Sep 2020 19:13:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8979\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:460:\"WordPress 5.5.1 is now available! This maintenance release features&#160;34 bug fixes, 5 enhancements, and&#160;5 bug fixes&#160;for the&#160;block&#160;editor. These bugs affect WordPress version 5.5, so you’ll want to upgrade. You can download WordPress 5.5.1 directly, or visit the&#160;Dashboard → Updates screen&#160;and click&#160;Update Now. If your sites support automatic background updates, they’ve already started the update process. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Jb Audras\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9020:\"
<p>WordPress 5.5.1 is now available!</p>



<p>This maintenance release features&nbsp;<a rel=\"noreferrer noopener\" href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=5.5.1&amp;group=status&amp;col=id&amp;col=summary&amp;col=milestone&amp;col=owner&amp;col=type&amp;col=status&amp;col=priority&amp;order=priority\" target=\"_blank\">34 bug fixes, 5 enhancements</a>, and&nbsp;<a rel=\"noreferrer noopener\" href=\"https://github.com/WordPress/gutenberg/pull/24828\" target=\"_blank\">5 bug fixes</a>&nbsp;for the&nbsp;block&nbsp;editor. These bugs affect WordPress version 5.5, so you’ll want to upgrade.</p>



<p>You can <a href=\"https://wordpress.org/wordpress-5.5.1.zip\">download WordPress 5.5.1 directly</a>, or visit the<strong>&nbsp;Dashboard → Updates</strong> screen&nbsp;and click&nbsp;<strong>Update Now</strong>. If your sites support automatic background updates, they’ve already started the update process.</p>



<p>WordPress 5.5.1 is a short-cycle maintenance release. The next major release will be <a href=\"https://make.wordpress.org/core/5-6/\">version 5.6</a>.</p>



<p>To see a full list of changes, you can browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=5.5.1&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">list on Trac</a>, read the <a href=\"https://make.wordpress.org/core/2020/08/27/wordpress-5-5-1-rc1/\">5.5.1 RC1</a> and <a href=\"https://make.wordpress.org/core/2020/08/31/wordpress-5-5-1-rc2/\">5.5.1 RC2</a> posts, or visit the <a href=\"https://wordpress.org/support/wordpress-version/version-5-5-1/\">5.5.1 documentation page</a>.</p>



<h2>Thanks and props!</h2>



<p>The 5.5.1 release was led by <a href=\'https://profiles.wordpress.org/audrasjb/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>audrasjb</a>, <a href=\'https://profiles.wordpress.org/azhiyadev/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>azhiyadev</a>, <a href=\'https://profiles.wordpress.org/davidbaumwald/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>davidbaumwald</a>, <a href=\'https://profiles.wordpress.org/desrosj/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>desrosj</a>, <a href=\'https://profiles.wordpress.org/johnbillion/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>johnbillion</a>, <a href=\'https://profiles.wordpress.org/planningwrite/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>planningwrite</a>, <a href=\'https://profiles.wordpress.org/sergeybiryukov/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>sergeybiryukov</a> and <a href=\'https://profiles.wordpress.org/whyisjake/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>whyisjake</a>.</p>



<p>Thank you to everyone who helped make WordPress 5.5.1 happen:</p>



<a href=\"https://profiles.wordpress.org/wpamitkumar/\">Amit Dudhat</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey &#8220;Rarst&#8221; Savchenko</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/akissz/\">Angel Hess</a>, <a href=\"https://profiles.wordpress.org/avixansa/\">avixansa</a>, <a href=\"https://profiles.wordpress.org/bobbingwide/\">bobbingwide</a>, <a href=\"https://profiles.wordpress.org/brianhogg/\">Brian Hogg</a>, <a href=\"https://profiles.wordpress.org/chunkysteveo/\">chunkysteveo</a>, <a href=\"https://profiles.wordpress.org/claytoncollie/\">Clayton Collie</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dd32/\">dd32</a>, <a href=\"https://profiles.wordpress.org/demetris/\">demetris</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/dushakov/\">dushakov</a>, <a href=\"https://profiles.wordpress.org/elrae/\">Earle Davies</a>, <a href=\"https://profiles.wordpress.org/nrqsnchz/\">Enrique Sánchez</a>, <a href=\"https://profiles.wordpress.org/fjarrett/\">Frankie Jarrett</a>, <a href=\"https://profiles.wordpress.org/fullofcaffeine/\">fullofcaffeine</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/garyj/\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/gchtr/\">gchtr</a>, <a href=\"https://profiles.wordpress.org/azhiyadev/\">Hauwa</a>, <a href=\"https://profiles.wordpress.org/herregroen/\">Herre Groen</a>, <a href=\"https://profiles.wordpress.org/howdy_mcgee/\">Howdy_McGee</a>, <a href=\"https://profiles.wordpress.org/ipstenu/\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jeroenrotty/\">Jeroen Rotty</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen A.</a>, <a href=\"https://profiles.wordpress.org/johannadevos/\">Johanna de Vos</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/psykro/\">Jonathan Bossenger</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jonathanstegall/\">Jonathan Stegall</a>, <a href=\"https://profiles.wordpress.org/joostdevalk/\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/akabarikalpesh/\">Kalpesh Akabari</a>, <a href=\"https://profiles.wordpress.org/khag7/\">Kevin Hagerty</a>, <a href=\"https://profiles.wordpress.org/knutsp/\">Knut Sparhell</a>, <a href=\"https://profiles.wordpress.org/kbjohnson90/\">Kyle B. Johnson</a>, <a href=\"https://profiles.wordpress.org/landau/\">landau</a>, <a href=\"https://profiles.wordpress.org/laxman-prajapati/\">Laxman Prajapati</a>, <a href=\"https://profiles.wordpress.org/gamerz/\">Lester Chan</a>, <a href=\"https://profiles.wordpress.org/mailnew2ster/\">mailnew2ster</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/markjaquith/\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/mapk/\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/gothickgothickorguk/\">Matt Gibson</a>, <a href=\"https://profiles.wordpress.org/tw2113/\">Michael Beckwith</a>, <a href=\"https://profiles.wordpress.org/mikeyarce/\">Mikey Arce</a>, <a href=\"https://profiles.wordpress.org/batmoo/\">Mohammad Jangda</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/nabilmoqbel/\">Nabil Moqbel</a>, <a href=\"https://profiles.wordpress.org/krstarica/\">net</a>, <a href=\"https://profiles.wordpress.org/oakesjosh/\">oakesjosh</a>, <a href=\"https://profiles.wordpress.org/nosolosw/\">O André</a>, <a href=\"https://profiles.wordpress.org/omarreiss/\">Omar Reiss</a>, <a href=\"https://profiles.wordpress.org/ov3rfly/\">Ov3rfly</a>, <a href=\"https://profiles.wordpress.org/paddy/\">Paddy</a>, <a href=\"https://profiles.wordpress.org/casiepa/\">Pascal Casier</a>, <a href=\"https://profiles.wordpress.org/pbiron/\">Paul Biron</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/rajeshsingh520/\">rajeshsingh520</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/rebasaurus/\">rebasaurus</a>, <a href=\"https://profiles.wordpress.org/riaanlom/\">riaanlom</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/kreppar/\">Rodrigo Arias</a>, <a href=\"https://profiles.wordpress.org/rtagliento/\">rtagliento</a>, <a href=\"https://profiles.wordpress.org/salvoaranzulla/\">salvoaranzulla</a>, <a href=\"https://profiles.wordpress.org/sanzeeb3/\">Sanjeev Aryal</a>, <a href=\"https://profiles.wordpress.org/sarahricker/\">sarahricker</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sabernhardt/\">Stephen Bernhardt</a>, <a href=\"https://profiles.wordpress.org/sterndata/\">Steven Stern (sterndata)</a>, <a href=\"https://profiles.wordpress.org/webzunft/\">Thomas M</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/tobiasbg/\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tobifjellner/\">tobifjellner (Tor-Bjorn Fjellner)</a>, <a href=\"https://profiles.wordpress.org/twentyzerotwo/\">TwentyZeroTwo</a>, <a href=\"https://profiles.wordpress.org/planningwrite/\">Winstina</a>, <a href=\"https://profiles.wordpress.org/wittich/\">wittich</a>, and <a href=\"https://profiles.wordpress.org/yoavf/\">Yoav Farhi</a>.
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8979\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"The Month in WordPress: August 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2020/09/the-month-in-wordpress-august-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 01 Sep 2020 09:32:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8983\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:362:\"August was special for WordPress lovers, as one of the most anticipated releases, WordPress 5.5, was launched. The month also saw several updates from various contributor teams, including the soft-launch of the Learn WordPress project and updates to Gutenberg. Read on to find out about the latest updates from the WordPress world. WordPress 5.5 Launch [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9605:\"
<p>August was special for WordPress lovers, as one of the most anticipated releases, WordPress 5.5, was launched. The month also saw several updates from various contributor teams, including the soft-launch of the Learn WordPress project and updates to Gutenberg. Read on to find out about the latest updates from the WordPress world.</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.5 Launch</h2>



<p>The team launched <a href=\"https://wordpress.org/news/2020/08/eckstine/\">WordPress 5.5</a> on August 11. The major release comes with a host of features like automatic updates for plugins and themes, enabling updates over uploaded ZIP files, a block directory, XML sitemaps, block patterns, inline image editing, and lazy-loading images, to name a few. WordPress 5.5 is now available in 50 languages too! You can update to the latest version directly from your WordPress dashboard or <a href=\"https://wordpress.org/download/\">download</a> it directly from WordPress.org. Subsequent to the 5.5 release, the <a href=\"https://make.wordpress.org/core/2020/08/27/wordpress-5-5-1-rc1/\">5.5.1 release candidate</a> came out on August 28, which will be followed by its official launch of the minor release on September 1.</p>



<p>A record 805 people contributed to WordPress 5.5, hailing from 58 different countries. <a href=\'https://profiles.wordpress.org/audrasjb/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>audrasjb</a> has <a href=\"https://jeanbaptisteaudras.com/en/2020/08/wordpress-5-5-core-stats-contributions-by-country-company/\">compiled many more stats like that</a> and they’re well worth a read!</p>



<p>Want to get involved in building WordPress Core? Follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Gutenberg 8.7 and 8.8</h2>



<p>The core team launched Gutenberg <a href=\"https://make.wordpress.org/core/2020/08/05/whats-new-in-gutenberg-august-5/\">8.7</a> and <a href=\"https://make.wordpress.org/core/2020/08/19/whats-new-in-gutenberg-august-19/\">8.8</a>. Version 8.7 saw many improvements to the Post Block suite, along with other changes like adding a block example to the Buttons block, consistently autosaving edits, and updating the group block description. Version 8.8 offers updates to Global Styles, the Post Block suite, and Template management. The release significantly improves the back-compatibility of the new Widget Screen, and also includes other important accessibility and mobile improvements to user interfaces like the Toolbar, navigation menus, and Popovers. For full details on the latest versions of these Gutenberg releases, visit these posts about <a href=\"https://make.wordpress.org/core/2020/08/05/whats-new-in-gutenberg-august-5/\">8.7</a> and <a href=\"https://make.wordpress.org/core/2020/08/19/whats-new-in-gutenberg-august-19/\">8.8</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Check out the brand new Learn WordPress platform!</h2>



<p><a href=\"https://learn.wordpress.org/\">Learn WordPress</a> is a brand new cross-team initiative led by the <a href=\"https://make.wordpress.org/community/\">WordPress Community team</a>, with support from the <a href=\"https://make.wordpress.org/training/\">training team</a>, the <a href=\"https://make.wordpress.org/tv/\">TV team</a>, and the <a href=\"https://make.wordpress.org/meta/\">meta team</a>. This platform is a learning repository on <a href=\"https://learn.wordpress.org/\">learn.wordpress.org</a>, where WordPress learning content will be made available. Video workshops published on the site will be followed up by supplementary discussion groups based on workshop content. The first of these discussion groups have been scheduled, and you can join an upcoming discussion <a href=\"https://www.meetup.com/learn-wordpress-discussions/events/\">on the dedicated meetup group</a>. The community team invites members to contribute to the project. You can apply to <a href=\"https://wordcampcentral.survey.fm/learn-wordpress-workshop-application\">present a workshop</a>, <a href=\"https://wordcampcentral.survey.fm/learn-wordpress-reviewer-application\">assist with reviewing</a> submitted workshops, and <a href=\"https://docs.google.com/spreadsheets/d/1A6BYIZAtqk3alBFtJBg-7Q7Y7NBLRnoRFbRTGho2rfI/edit\">add ideas for workshops</a> that you would like to see on the site. You can also apply<a href=\"https://wordcampcentral.survey.fm/learn-wordpress-discussion-group-leader-application\"> to be a discussion group leader</a> to organize discussions directly through the <a href=\"https://learn.wordpress.org\">learn.wordpress.org</a> platform. We are also creating a dedicated Learn WordPress working group and have <a href=\"https://make.wordpress.org/community/2020/08/24/learn-wordpress-working-group-call-for-volunteers/\">posted a call for volunteers</a>. Meetup organizers can use <a href=\"https://learn.wordpress.org/\">Learn WordPress</a> content for their meetup events (without applying as a discussion group leader). Simply ask your meetup group to watch one of the workshops in the weeks leading up to your scheduled event, and then host a discussion group for that content as your event.</p>



<p>Want to get involved with the Community team? <a href=\"https://make.wordpress.org/community/\">Follow the Community blog</a>, or join them in the #community-events channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>. To organize a local WordPress community event, <a href=\"https://make.wordpress.org/community/handbook/virtual-events/welcome/applying-for-a-virtual-event/\">visit the handbook page</a>. </p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>As <a href=\"https://make.wordpress.org/core/2020/03/11/all-women-release-squad/\">proposed previously</a>, WordPress 5.6 will have an all-women release squad. The team has <a href=\"https://make.wordpress.org/core/2020/08/13/wordpress-5-6-release-planning/\">started work on the 5.6 release planning</a>.</li><li>The community team has decided to <a href=\"https://make.wordpress.org/community/2020/08/04/announcement-flagship-events-in-2021/\">cancel in-person flagship WordPress events</a> in 2021. While new applications for flagship events in 2021 will not be accepted, organizers of existing flagship events (such as WordCamp US, Europe, and Asia) will have the option to move their event online. </li><li>The core team is working on <a href=\"https://core.trac.wordpress.org/ticket/37110\">updating the jQuery version</a> that comes with WordPress. As the first step, the <a href=\"https://make.wordpress.org/core/2020/06/29/updating-jquery-version-shipped-with-wordpress/\">team removed the jQuery Migrate 1.4.1 script </a>from WordPress 5.5. Those who wish to use jQuery migrate for maintaining plugin compatibility can install the <a href=\"https://wordpress.org/plugins/enable-jquery-migrate-helper/\">Enable jQuery Migrate Helper plugin</a>, which has currently reached the 100k installs mark. </li><li>The WordPress documentation team is continuing its discussion on modifying the external linking policy. The conversation is taking place on a <a href=\"https://docs.google.com/document/d/1i0ipOTmKPShSIMoFuEXnI3gkOOUrPJb9t4HMf30JWC0/edit#heading=h.l0cppyl5zvhs\">shared Google doc</a>. Feel free to add comments if you have any thoughts on the topic. </li><li>WordPress will <a href=\"https://core.trac.wordpress.org/ticket/51043#comment:7\">not drop support for PHP 5.6</a>, as initially decided, in order to maintain better version compatibility. The team has additionally come up with a <a href=\"https://make.wordpress.org/core/2020/08/24/proposal-dropping-support-for-old-php-versions-via-a-fixed-schedule/\">proposal to drop support for old PHP versions via a fixed schedule</a>.</li><li>The maiden edition of <a href=\"https://doaction.org/event/india-2020\">do_action India online</a> was held from August 15 to 23. The event, which was held online with collaboration tools, had 94 participants who built fully functional websites for five NGOs from across the country. You can read more about 2020 do_action events <a href=\"https://wordpressfoundation.org/2020/charity-hackathons-august-2020-report/\">on the WordPress Foundation blog</a>.</li><li>The Accessibility team has <a href=\"https://make.wordpress.org/accessibility/2020/08/25/accessibility-teams-goals-for-wordpress-5-6-and-beyond/\">published their goals for WordPress 5.6 and beyond</a> and has started working on them.</li><li><a href=\"https://minneapolis.wordcamp.org/2020/\">WordCamp Minneapolis/St. Paul</a> was held successfully on August 21. The event, which sold over 1400 tickets, had 18 speakers and 12 sponsors.</li><li>The Polyglots team has completed the translation <a href=\"https://make.wordpress.org/polyglots/2020/08/19/polyglots-handbook-reorganization-update/\">handbook structure organization</a>. The handbook now has clear guides for translators, PTEs/GTEs, global mentors, and Plugin/Theme authors.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8983\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		

					
										
					
		
		



			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"WordPress 5.5 “Eckstine”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"https://wordpress.org/news/2020/08/eckstine/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Aug 2020 19:03:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"5.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8799\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:354:\"Version 5.5 \"Eckstine\" of WordPress is available for download or update in your WordPress dashboard. With this release, your site gets new power in three major areas: 
speed (lazy-loading images), search (sitemaps included by default), and security (auto-updates for plugins and themes), along with many new features and improvements to the block editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:3:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:48:\"https://s.w.org/images/core/5.5/auto-updates.mp4\";s:6:\"length\";s:6:\"238264\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:50:\"https://s.w.org/images/core/5.5/block-patterns.mp4\";s:6:\"length\";s:7:\"3518792\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:56:\"https://s.w.org/images/core/5.5/inline-image-editing.mp4\";s:6:\"length\";s:7:\"3145140\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:71062:\"
<p>Here it is! Named “Eckstine” in honor of Billy Eckstine, this latest and greatest version of WordPress is available for&nbsp;<a href=\"https://wordpress.org/download/\">download</a> or update in your dashboard.</p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"514\" src=\"https://i0.wp.com/wordpress.org/news/files/2020/08/Billy_duotone-1000px_quiche-sans-top.png?resize=632%2C514&#038;ssl=1\" alt=\"\" class=\"wp-image-8930\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2020/08/Billy_duotone-1000px_quiche-sans-top.png?w=1000&amp;ssl=1 1000w, https://i0.wp.com/wordpress.org/news/files/2020/08/Billy_duotone-1000px_quiche-sans-top.png?resize=300%2C244&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2020/08/Billy_duotone-1000px_quiche-sans-top.png?resize=768%2C625&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<div class=\"wp-block-cover has-background-dim\" style=\"background-color:#f2edd4;min-height:300px\"><div class=\"wp-block-cover__inner-container\">
<p class=\"has-text-align-center has-black-color has-text-color has-background has-large-font-size\" style=\"background-color:#f2edd4\">Welcome to WordPress 5.5.</p>



<h3 class=\"has-text-align-center has-black-color has-text-color\">In WordPress 5.5, your site gets new power in three major areas: <br>speed, search, and security.</h3>
</div></div>



<div class=\"wp-block-columns has-white-background-color has-background\">
<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>



<div class=\"wp-block-column\" style=\"flex-basis:96%\">
<h2>Speed</h2>



<p><strong>Posts and pages feel faster, thanks to lazy-loaded images.</strong></p>



<p>Images give your story a lot of impact, but they can sometimes make your site seem slow.</p>



<p>In WordPress 5.5, images wait to load until they’re just about to scroll into view. The technical term is ‘lazy loading.’</p>



<p>On mobile, lazy loading can also keep browsers from loading files meant for other devices. That can save your readers money on data — and help preserve battery life.</p>



<h2>Search</h2>



<p><strong>Say hello to your new sitemap.</strong></p>



<p>WordPress sites work well with search engines.</p>



<p>Now, by default, WordPress 5.5 includes an XML sitemap that helps search engines discover your most important pages from the very minute you go live.</p>



<p>So more people will find your site sooner, giving you more time to engage, retain and convert them to subscribers, customers or whatever fits your definition of success.</p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>
</div>



<div class=\"wp-block-columns has-background\" style=\"background-color:#ebcd3d\">
<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>



<div class=\"wp-block-column\" style=\"flex-basis:96%\">
<h2>Security</h2>



<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.5/auto-updates.mp4\"></video><figcaption>Now you can choose to update plugins and themes automatically–or pick just a few–from the screens you’ve always used.</figcaption></figure>



<p><strong>Auto-updates for Plugins and Themes</strong></p>



<p>Now you can set plugins and themes to update automatically — or not! — in the WordPress admin. So you always know your site is running the latest code available.</p>



<p>You can also turn auto-updates on or off for each plugin or theme you have installed — all on the same screens you’ve always used.</p>



<p><strong>Update by uploading ZIP files</strong></p>



<p>If updating plugins and themes manually is your thing, now that’s easier too — just upload a ZIP file.</p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>
</div>



<div class=\"wp-block-columns has-background\" style=\"background-color:#f2edd4\">
<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>



<div class=\"wp-block-column\" style=\"flex-basis:96%\">
<h2>Highlights from the block editor</h2>



<p>Once again, the latest WordPress release packs a long list of exciting new features for the block editor. For example:</p>



<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.5/block-patterns.mp4\"></video></figure>



<div class=\"wp-block-columns\">
<div class=\"wp-block-column\">
<h3>Block patterns</h3>



<p>New block patterns make it simple and fun to create complex, beautiful layouts, using combinations of text and media that you can mix and match to fit your story.</p>



<p>You will also find block patterns in a wide variety of plugins and themes, with more added all the time. Pick any of them from a single place — just click and go!</p>
</div>



<div class=\"wp-block-column\">
<h3>The new block directory</h3>



<p>Now it’s easier than ever to find the block you need. The new block directory is built right into the block editor, so you can install new block types to your site without ever leaving the editor.</p>



<h3>Inline image editing</h3>



<p>Crop, rotate, and zoom your photos right from the image block. If you spend a lot of time on images, this could save you hours!</p>
</div>
</div>



<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.5/inline-image-editing.mp4\"></video></figure>



<h3>And so much more.</h3>



<p>The highlights above are a tiny fraction of the new block editor features you’ve just installed. Open the block editor and enjoy!</p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>
</div>



<div class=\"wp-block-columns has-white-background-color has-background\">
<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>



<div class=\"wp-block-column\" style=\"flex-basis:96%\">
<h2>Accessibility</h2>



<p>Every release adds improvements to the accessible publishing experience, and that remains true for WordPress 5.5.</p>



<p>Now you can copy links in media screens and modal dialogs with a button, instead of trying to highlight a line of text.</p>



<p>You can also move meta boxes with the keyboard, and edit images in WordPress with your assistive device, as it can read you the instructions in the image editor.</p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>
</div>



<div class=\"wp-block-columns has-black-color has-text-color has-background\" style=\"background-color:#ebcd3d\">
<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>



<div class=\"wp-block-column\" style=\"flex-basis:96%\">
<h2>For developers</h2>



<p>5.5 also brings a big box of changes just for developers.</p>



<div class=\"wp-block-columns\">
<div class=\"wp-block-column\">
<h3>Server-side registered blocks in the REST API</h3>



<p>The addition of block types endpoints means that JavaScript apps (like the block editor) can retrieve definitions for any blocks registered on the server.</p>



<h3>Defining environments</h3>



<p>WordPress now has a standardized way to define a site’s environment type (staging, production, etc). Retrieve that type with&nbsp;<code>wp_get_environment_type()</code>&nbsp;and execute only the appropriate code.</p>



<h3>Dashicons</h3>



<p>The Dashicons library has received its final update in 5.5. It adds 39 block editor icons along with 26 others.</p>



<h3>Passing data to template files</h3>



<p>The template loading functions (<code>get_header()</code>,&nbsp;<code>get_template_part()</code>, etc.) have a new&nbsp;<code>$args</code>&nbsp;argument. So now you can pass an entire array’s worth of data to those templates.</p>
</div>



<div class=\"wp-block-column\">
<h3>More changes for developers</h3>



<ul><li>The PHPMailer library just got a major update, going from version 5.2.27 to 6.1.6.</li><li>Now get more fine-grained control of&nbsp;<code>redirect_guess_404_permalink()</code>.</li><li>Sites that use PHP’s OPcache will see more reliable cache invalidation, thanks to the new&nbsp;<code>wp_opcache_invalidate()</code>&nbsp;function during updates (including to plugins and themes).</li><li>Custom post types associated with the category taxonomy can now opt-in to supporting the default term.</li><li>Default terms can now be specified for custom taxonomies in&nbsp;<code>register_taxonomy()</code>.</li><li>The REST API now officially supports specifying default metadata values through&nbsp;<code>register_meta()</code>.</li><li>You will find updated versions of these bundled libraries: SimplePie, Twemoji, Masonry, imagesLoaded, getID3, Moment.js, and clipboard.js.</li></ul>
</div>
</div>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>
</div>



<div class=\"wp-block-columns has-white-background-color has-background\">
<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>



<div class=\"wp-block-column\" style=\"flex-basis:96%\">
<h2>The Squad</h2>



<p>Leading this release were&nbsp;<a href=\"http://ma.tt/\">Matt Mullenweg</a>,&nbsp;<a href=\"https://profiles.wordpress.org/whyisjake\">Jake Spurlock,</a> and&nbsp;<a href=\"https://dream-encode.com/blog/\">David Baumwald</a>. Supporting them was this highly enthusiastic release squad:</p>



<ul><li><strong>Editor Tech</strong>: Ella Van Durpe (<a href=\'https://profiles.wordpress.org/ellatrix/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>ellatrix</a>)</li><li><strong>Editor Design</strong>: Michael Arestad (<a href=\'https://profiles.wordpress.org/michael-arestad/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>michael-arestad</a>)</li><li><strong>Core Tech</strong>: Sergey Biryukov (<a href=\'https://profiles.wordpress.org/sergeybiryukov/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>sergeybiryukov</a>)</li><li><strong>Media Tech: </strong>Andrew Ozz (<a href=\'https://profiles.wordpress.org/azaozz/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>azaozz</a>)</li><li><strong>Accessibility Tech</strong>: JB Audras (<a href=\'https://profiles.wordpress.org/audrasjb/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>audrasjb</a>)</li><li><strong>Docs Coordinator</strong>:&nbsp;Justin Ahinon (<a href=\'https://profiles.wordpress.org/justinahinon/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>justinahinon</a>)</li><li><strong>Marketing/Comms Coordinator</strong>: Mary Baum (<a href=\'https://profiles.wordpress.org/marybaum/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>marybaum</a>)</li></ul>



<p>Joining the squad throughout the release cycle were <strong>805 generous volunteer contributors</strong> who collectively worked on over <strong><a href=\"https://core.trac.wordpress.org/milestone/5.5\">523</a> tickets on Trac</strong> and <strong>over 1660 pull requests on GitHub</strong>.</p>



<p>Put on a Billy Eckstine playlist, click that update button (or&nbsp;<a href=\"https://wordpress.org/download/\">download it directly</a>), and check the profiles of the fine folks that helped:</p>


<a href=\"https://profiles.wordpress.org/a2hosting/\">A2 Hosting</a>, <a href=\"https://profiles.wordpress.org/a4jpcom/\">a4jp . com</a>, <a href=\"https://profiles.wordpress.org/a6software/\">a6software</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell/\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abderrahman/\">abderrahman</a>, <a href=\"https://profiles.wordpress.org/webcommsat/\">Abha Thakor</a>, <a href=\"https://profiles.wordpress.org/ibachal/\">Achal Jain</a>, <a href=\"https://profiles.wordpress.org/achbed/\">achbed</a>, <a href=\"https://profiles.wordpress.org/achyuthajoy/\">Achyuth Ajoy</a>, <a href=\"https://profiles.wordpress.org/acosmin/\">acosmin</a>, <a href=\"https://profiles.wordpress.org/acsnaterse/\">acsnaterse</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/addiestavlo/\">Addie</a>, <a href=\"https://profiles.wordpress.org/addyosmani/\">addyosmani</a>, <a href=\"https://profiles.wordpress.org/adnanlimdi/\">adnan.limdi</a>, <a href=\"https://profiles.wordpress.org/adrian/\">adrian</a>, <a href=\"https://profiles.wordpress.org/airamerica/\">airamerica</a>, <a href=\"https://profiles.wordpress.org/ajayghaghretiya1/\">Ajay Ghaghretiya</a>, <a href=\"https://profiles.wordpress.org/ajitbohra/\">Ajit Bohra</a>, <a href=\"https://profiles.wordpress.org/akbarhusen/\">akbarhusen</a>, <a href=\"https://profiles.wordpress.org/akbarhusen429/\">akbarhusen429</a>, <a href=\"https://profiles.wordpress.org/akhileshsabharwal/\">Akhilesh Sabharwal</a>, <a href=\"https://profiles.wordpress.org/atachibana/\">Akira Tachibana</a>, <a href=\"https://profiles.wordpress.org/schlessera/\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/aljullu/\">Albert Juh&#233; Lluveras</a>, <a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/akirk/\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/ajlende/\">Alex Lende</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/alishanvr/\">Ali Shan</a>, <a href=\"https://profiles.wordpress.org/ali11007/\">ali11007</a>, <a href=\"https://profiles.wordpress.org/allendav/\">Allen Snook</a>, <a href=\"https://profiles.wordpress.org/amaschas/\">amaschas</a>, <a href=\"https://profiles.wordpress.org/wpamitkumar/\">Amit Dudhat</a>, <a href=\"https://profiles.wordpress.org/anbumz/\">anbumz</a>, <a href=\"https://profiles.wordpress.org/andfinally/\">andfinally</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton/\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/dontdream/\">Andrea Tarantini</a>, <a href=\"https://profiles.wordpress.org/andraganescu/\">Andrei Draganescu</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/nacin/\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/anevins/\">Andrew Nevins</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey \"Rarst\" Savchenko</a>, <a href=\"https://profiles.wordpress.org/nosolosw/\">Andrés Maneiro</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/andizer/\">Andy Meerwaldt</a>, <a href=\"https://profiles.wordpress.org/apeatling/\">Andy Peatling</a>, <a href=\"https://profiles.wordpress.org/akissz/\">Angel Hess</a>, <a href=\"https://profiles.wordpress.org/angelasjin/\">Angela Jin</a>, <a href=\"https://profiles.wordpress.org/la-geek/\">Angelika Reisiger</a>, <a href=\"https://profiles.wordpress.org/rilwis/\">Anh Tran</a>, <a href=\"https://profiles.wordpress.org/wpgurudev/\">Ankit Gade</a>, <a href=\"https://profiles.wordpress.org/ankit-k-gupta/\">Ankit K Gupta</a>, <a href=\"https://profiles.wordpress.org/ankitmaru/\">Ankit Panchal</a>, <a href=\"https://profiles.wordpress.org/annezazu/\">Anne McCarthy</a>, <a href=\"https://profiles.wordpress.org/antpb/\">Anthony Burchell</a>, <a href=\"https://profiles.wordpress.org/ahortin/\">Anthony Hortin</a>, <a href=\"https://profiles.wordpress.org/atimmer/\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/antonisme/\">Antonis Lilis</a>, <a href=\"https://profiles.wordpress.org/apedog/\">apedog</a>, <a href=\"https://profiles.wordpress.org/archon810/\">archon810</a>, <a href=\"https://profiles.wordpress.org/argentite/\">argentite</a>, <a href=\"https://profiles.wordpress.org/arpitgshah/\">Arpit G Shah</a>, <a href=\"https://profiles.wordpress.org/passoniate/\">Arslan Ahmed</a>, <a href=\"https://profiles.wordpress.org/asalce/\">asalce</a>, <a href=\"https://profiles.wordpress.org/ashiagr/\">ashiagr</a>, <a href=\"https://profiles.wordpress.org/ashour/\">ashour</a>, <a href=\"https://profiles.wordpress.org/tacitonic/\">Atharva Dhekne</a>, <a href=\"https://profiles.wordpress.org/ajoah/\">Aur&#233;lien Joahny</a>, <a href=\"https://profiles.wordpress.org/aussi/\">aussi</a>, <a href=\"https://profiles.wordpress.org/automaton/\">automaton</a>, <a href=\"https://profiles.wordpress.org/avixansa/\">avixansa</a>, <a href=\"https://profiles.wordpress.org/ayeshrajans/\">Ayesh Karunaratne</a>, <a href=\"https://profiles.wordpress.org/backups/\">BackuPs</a>, <a href=\"https://profiles.wordpress.org/barry/\">Barry</a>, <a href=\"https://profiles.wordpress.org/barryceelen/\">Barry Ceelen</a>, <a href=\"https://profiles.wordpress.org/bartczyz/\">Bart Czyz</a>, <a href=\"https://profiles.wordpress.org/bartekcholewa/\">bartekcholewa</a>, <a href=\"https://profiles.wordpress.org/bartkalisz/\">bartkalisz</a>, <a href=\"https://profiles.wordpress.org/bastho/\">Bastien Ho</a>, <a href=\"https://profiles.wordpress.org/bmartinent/\">Bastien Martinent</a>, <a href=\"https://profiles.wordpress.org/bcworkz/\">bcworkz</a>, <a href=\"https://profiles.wordpress.org/bdbch/\">bdbch</a>, <a href=\"https://profiles.wordpress.org/bdcstr/\">bdcstr</a>, <a href=\"https://profiles.wordpress.org/empireoflight/\">Ben Dunkle</a>, <a href=\"https://profiles.wordpress.org/grapestain/\">Bence Szalai</a>, <a href=\"https://profiles.wordpress.org/bencroskery/\">bencroskery</a>, <a href=\"https://profiles.wordpress.org/benjamingosset/\">Benjamin Gosset</a>, <a href=\"https://profiles.wordpress.org/benoitchantre/\">Benoit Chantre</a>, <a href=\"https://profiles.wordpress.org/bernhard-reiter/\">Bernhard Reiter</a>, <a href=\"https://profiles.wordpress.org/bettyjj/\">BettyJJ</a>, <a href=\"https://profiles.wordpress.org/bgermann/\">bgermann</a>, <a href=\"https://profiles.wordpress.org/bigcloudmedia/\">bigcloudmedia</a>, <a href=\"https://profiles.wordpress.org/bigdawggi/\">bigdawggi</a>, <a href=\"https://profiles.wordpress.org/billerickson/\">Bill Erickson</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/bph/\">Birgit Pauli-Haack</a>, <a href=\"https://profiles.wordpress.org/bjornw/\">BjornW</a>, <a href=\"https://profiles.wordpress.org/bobbingwide/\">bobbingwide</a>, <a href=\"https://profiles.wordpress.org/gitlost/\">bonger</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/bbrdaric/\">Boris Brdarić</a>, <a href=\"https://profiles.wordpress.org/ibdz/\">Boy Witthaya</a>, <a href=\"https://profiles.wordpress.org/kraftbj/\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/bpayton/\">Brandon Payton</a>, <a href=\"https://profiles.wordpress.org/brentswisher/\">Brent Swisher</a>, <a href=\"https://profiles.wordpress.org/brianhogg/\">Brian Hogg</a>, <a href=\"https://profiles.wordpress.org/krogsgard/\">Brian Krogsgard</a>, <a href=\"https://profiles.wordpress.org/bruandet/\">bruandet</a>, <a href=\"https://profiles.wordpress.org/bhargavbhandari90/\">Bunty</a>, <a href=\"https://profiles.wordpress.org/burhandodhy/\">Burhan Nasir</a>, <a href=\"https://profiles.wordpress.org/caiocrcosta/\">caiocrcosta</a>, <a href=\"https://profiles.wordpress.org/cvoell/\">Cameron Voell</a>, <a href=\"https://profiles.wordpress.org/cameronamcintyre/\">cameronamcintyre</a>, <a href=\"https://profiles.wordpress.org/carike/\">Carike</a>, <a href=\"https://profiles.wordpress.org/stuffradio/\">Carl Wuensche</a>, <a href=\"https://profiles.wordpress.org/carloslfu/\">Carlos Galarza</a>, <a href=\"https://profiles.wordpress.org/poena/\">Carolina Nymark</a>, <a href=\"https://profiles.wordpress.org/sixhours/\">Caroline Moore</a>, <a href=\"https://profiles.wordpress.org/carriganvb/\">Carrigan</a>, <a href=\"https://profiles.wordpress.org/ceyhun/\">ceyhun</a>, <a href=\"https://profiles.wordpress.org/shireling/\">Chad</a>, <a href=\"https://profiles.wordpress.org/cbutlerjr/\">Chad Butler</a>, <a href=\"https://profiles.wordpress.org/mackensen/\">Charles Fulton</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/chintan1896/\">Chintan hingrajiya</a>, <a href=\"https://profiles.wordpress.org/chipsnyder/\">Chip Snyder</a>, <a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a>, <a href=\"https://profiles.wordpress.org/chouby/\">Chouby</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten/\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/chriscct7/\">chriscct7</a>, <a href=\"https://profiles.wordpress.org/christian1012/\">Christian Chung</a>, <a href=\"https://profiles.wordpress.org/cjbj/\">Christian Jongeneel</a>, <a href=\"https://profiles.wordpress.org/pixelverbieger/\">Christian Sabo</a>, <a href=\"https://profiles.wordpress.org/needle/\">Christian Wach</a>, <a href=\"https://profiles.wordpress.org/christophherr/\">Christoph Herr</a>, <a href=\"https://profiles.wordpress.org/vimes1984/\">Christopher Churchill</a>, <a href=\"https://profiles.wordpress.org/chunkysteveo/\">chunkysteveo</a>, <a href=\"https://profiles.wordpress.org/cklee/\">cklee</a>, <a href=\"https://profiles.wordpress.org/clayray/\">clayray</a>, <a href=\"https://profiles.wordpress.org/claytoncollie/\">Clayton Collie</a>, <a href=\"https://profiles.wordpress.org/cliffpaulick/\">Clifford Paulick</a>, <a href=\"https://profiles.wordpress.org/codeforest/\">codeforest</a>, <a href=\"https://profiles.wordpress.org/commeuneimage/\">Commeuneimage</a>, <a href=\"https://profiles.wordpress.org/copons/\">Copons</a>, <a href=\"https://profiles.wordpress.org/coreymckrill/\">Corey McKrill</a>, <a href=\"https://profiles.wordpress.org/cpasqualini/\">cpasqualini</a>, <a href=\"https://profiles.wordpress.org/cristovaov/\">Cristovao Verstraeten</a>, <a href=\"https://profiles.wordpress.org/littlebigthing/\">Csaba (LittleBigThings)</a>, <a href=\"https://profiles.wordpress.org/curtisbelt/\">Curtis Belt</a>, <a href=\"https://profiles.wordpress.org/clarinetlord/\">Cyrus Collier</a>, <a href=\"https://profiles.wordpress.org/dperonne/\">D.PERONNE</a>, <a href=\"https://profiles.wordpress.org/dsixinetu/\">d6</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber/\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/danielhuesken/\">Daniel H&#252;sken</a>, <a href=\"https://profiles.wordpress.org/danieltj/\">Daniel James</a>, <a href=\"https://profiles.wordpress.org/diddledan/\">Daniel Llewellyn</a>, <a href=\"https://profiles.wordpress.org/talldanwp/\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/confridin/\">Daniel Roch</a>, <a href=\"https://profiles.wordpress.org/mte90/\">Daniele Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/dboy1988/\">Danny</a>, <a href=\"https://profiles.wordpress.org/darkog/\">Darko G.</a>, <a href=\"https://profiles.wordpress.org/nerrad/\">Darren Ethier (nerrad)</a>, <a href=\"https://profiles.wordpress.org/dmchale/\">Dave McHale</a>, <a href=\"https://profiles.wordpress.org/drw158/\">Dave Whitley</a>, <a href=\"https://profiles.wordpress.org/davidakennedy/\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/davilera/\">David Aguilera</a>, <a href=\"https://profiles.wordpress.org/davidanderson/\">David Anderson</a>, <a href=\"https://profiles.wordpress.org/dartiss/\">David Artiss</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/dbrumbaugh10up/\">David Brumbaugh</a>, <a href=\"https://profiles.wordpress.org/desmith/\">David E. Smith</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dryanpress/\">David Ryan</a>, <a href=\"https://profiles.wordpress.org/dshanske/\">David Shanske</a>, <a href=\"https://profiles.wordpress.org/get_dave/\">David Smith</a>, <a href=\"https://profiles.wordpress.org/davidbinda/\">david.binda</a>, <a href=\"https://profiles.wordpress.org/davidvee/\">davidvee</a>, <a href=\"https://profiles.wordpress.org/dchymko/\">dchymko</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/deepaklalwani/\">Deepak Lalwani</a>, <a href=\"https://profiles.wordpress.org/dekervit/\">dekervit</a>, <a href=\"https://profiles.wordpress.org/delowardev/\">Delowar Hossain</a>, <a href=\"https://profiles.wordpress.org/demetris/\">demetris</a>, <a href=\"https://profiles.wordpress.org/denisco/\">Denis Yanchevskiy</a>, <a href=\"https://profiles.wordpress.org/derekakelly/\">derekakelly</a>, <a href=\"https://profiles.wordpress.org/pcfreak30/\">Derrick Hammer</a>, <a href=\"https://profiles.wordpress.org/emrikol/\">Derrick Tennant</a>, <a href=\"https://profiles.wordpress.org/dianeco/\">Diane Co</a>, <a href=\"https://profiles.wordpress.org/dilipbheda/\">Dilip Bheda</a>, <a href=\"https://profiles.wordpress.org/dimitrism/\">Dimitris Mitsis</a>, <a href=\"https://profiles.wordpress.org/dingo_d/\">dingo-d</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dency/\">Dixita Dusara</a>, <a href=\"https://profiles.wordpress.org/djennez/\">djennez</a>, <a href=\"https://profiles.wordpress.org/dmenard/\">dmenard</a>, <a href=\"https://profiles.wordpress.org/dmethvin/\">dmethvin</a>, <a href=\"https://profiles.wordpress.org/doc987/\">doc987</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/donmhico/\">donmhico</a>, <a href=\"https://profiles.wordpress.org/dono12/\">Dono12</a>, <a href=\"https://profiles.wordpress.org/doobeedoo/\">Doobeedoo</a>, <a href=\"https://profiles.wordpress.org/dossy/\">Dossy Shiobara</a>, <a href=\"https://profiles.wordpress.org/dpacks/\">dpacks</a>, <a href=\"https://profiles.wordpress.org/dratwas/\">dratwas</a>, <a href=\"https://profiles.wordpress.org/drewapicture/\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/drlightman/\">DrLightman</a>, <a href=\"https://profiles.wordpress.org/drprotocols/\">DrProtocols</a>, <a href=\"https://profiles.wordpress.org/dsifford/\">dsifford</a>, <a href=\"https://profiles.wordpress.org/dudo/\">dudo</a>, <a href=\"https://profiles.wordpress.org/dushakov/\">dushakov</a>, <a href=\"https://profiles.wordpress.org/dustinbolton/\">Dustin Bolton</a>, <a href=\"https://profiles.wordpress.org/dvershinin/\">dvershinin</a>, <a href=\"https://profiles.wordpress.org/cyberhobo/\">Dylan Kuhn</a>, <a href=\"https://profiles.wordpress.org/elrae/\">Earle Davies</a>, <a href=\"https://profiles.wordpress.org/seedsca/\">ecotechie</a>, <a href=\"https://profiles.wordpress.org/eddiemoya/\">Eddie Moya</a>, <a href=\"https://profiles.wordpress.org/eddystile/\">Eddy</a>, <a href=\"https://profiles.wordpress.org/ediamin/\">Edi Amin</a>, <a href=\"https://profiles.wordpress.org/ehtis/\">ehtis</a>, <a href=\"https://profiles.wordpress.org/itsjusteileen/\">Eileen Violini</a>, <a href=\"https://profiles.wordpress.org/ekatherine/\">Ekaterina</a>, <a href=\"https://profiles.wordpress.org/ellatrix/\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/elmastudio/\">elmastudio</a>, <a href=\"https://profiles.wordpress.org/emanuel_blagonic/\">Emanuel Blagonic</a>, <a href=\"https://profiles.wordpress.org/emlebrun/\">Emilie LEBRUN</a>, <a href=\"https://profiles.wordpress.org/manooweb/\">Emmanuel Hesry</a>, <a href=\"https://profiles.wordpress.org/enej/\">Enej Bajgoric</a>, <a href=\"https://profiles.wordpress.org/enricosorcinelli/\">Enrico Sorcinelli</a>, <a href=\"https://profiles.wordpress.org/epiqueras/\">Enrique Piqueras</a>, <a href=\"https://profiles.wordpress.org/nrqsnchz/\">Enrique Sánchez</a>, <a href=\"https://profiles.wordpress.org/shamai/\">Eric</a>, <a href=\"https://profiles.wordpress.org/ericlewis/\">Eric Andrew Lewis</a>, <a href=\"https://profiles.wordpress.org/ebinnion/\">Eric Binnion</a>, <a href=\"https://profiles.wordpress.org/kebbet/\">Erik Betshammar</a>, <a href=\"https://profiles.wordpress.org/folletto/\">Erin \'Folletto\' Casali</a>, <a href=\"https://profiles.wordpress.org/esemlabel/\">esemlabel</a>, <a href=\"https://profiles.wordpress.org/esoj/\">esoj</a>, <a href=\"https://profiles.wordpress.org/espiat/\">espiat</a>, <a href=\"https://profiles.wordpress.org/estelaris/\">Estela Rueda</a>, <a href=\"https://profiles.wordpress.org/etoledom/\">etoledom</a>, <a href=\"https://profiles.wordpress.org/etruel/\">etruel</a>, <a href=\"https://profiles.wordpress.org/ev3rywh3re/\">Ev3rywh3re</a>, <a href=\"https://profiles.wordpress.org/circlecube/\">Evan Mullins</a>, <a href=\"https://profiles.wordpress.org/fabiankaegy/\">Fabian K&#228;gy</a>, <a href=\"https://profiles.wordpress.org/gaambo/\">Fabian Todt</a>, <a href=\"https://profiles.wordpress.org/fftfaisal/\">Faisal Ahmed</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/felix-edelmann/\">Felix Edelmann</a>, <a href=\"https://profiles.wordpress.org/ferdiesletering/\">ferdiesletering</a>, <a href=\"https://profiles.wordpress.org/finomeno/\">finomeno</a>, <a href=\"https://profiles.wordpress.org/florianbrinkmann/\">Florian Brinkmann</a>, <a href=\"https://profiles.wordpress.org/mista-flo/\">Florian TIAR</a>, <a href=\"https://profiles.wordpress.org/truchot/\">Florian Truchot</a>, <a href=\"https://profiles.wordpress.org/florianatwhodunit/\">florianatwhodunit</a>, <a href=\"https://profiles.wordpress.org/foliovision/\">FolioVision</a>, <a href=\"https://profiles.wordpress.org/francina/\">Francesca Marano</a>, <a href=\"https://profiles.wordpress.org/francoist/\">Francois Thibaud</a>, <a href=\"https://profiles.wordpress.org/futtta/\">Frank Goossens</a>, <a href=\"https://profiles.wordpress.org/frank-klein/\">Frank Klein</a>, <a href=\"https://profiles.wordpress.org/frankprendergast/\">Frank.Prendergast</a>, <a href=\"https://profiles.wordpress.org/fjarrett/\">Frankie Jarrett</a>, <a href=\"https://profiles.wordpress.org/franzarmas/\">Franz Armas</a>, <a href=\"https://profiles.wordpress.org/fullofcaffeine/\">fullofcaffeine</a>, <a href=\"https://profiles.wordpress.org/mintindeed/\">Gabriel Koen</a>, <a href=\"https://profiles.wordpress.org/gma992/\">Gabriel Maldonado</a>, <a href=\"https://profiles.wordpress.org/gmays/\">Gabriel Mays</a>, <a href=\"https://profiles.wordpress.org/gadgetroid/\">gadgetroid</a>, <a href=\"https://profiles.wordpress.org/galbaras/\">Gal Baras</a>, <a href=\"https://profiles.wordpress.org/garavani/\">Garavani</a>, <a href=\"https://profiles.wordpress.org/garethgillman/\">garethgillman</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/garyc40/\">Gary Cao</a>, <a href=\"https://profiles.wordpress.org/garyj/\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/gchtr/\">gchtr</a>, <a href=\"https://profiles.wordpress.org/geertdd/\">Geert De Deckere</a>, <a href=\"https://profiles.wordpress.org/geminilabs/\">Gemini Labs</a>, <a href=\"https://profiles.wordpress.org/soulseekah/\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/geriux/\">geriux</a>, <a href=\"https://profiles.wordpress.org/giorgio25b/\">Giorgio25b</a>, <a href=\"https://profiles.wordpress.org/gisselfeldt/\">gisselfeldt</a>, <a href=\"https://profiles.wordpress.org/glendaviesnz/\">glendaviesnz</a>, <a href=\"https://profiles.wordpress.org/goldsounds/\">goldsounds</a>, <a href=\"https://profiles.wordpress.org/gh640/\">Goto Hayato</a>, <a href=\"https://profiles.wordpress.org/gkloveweb/\">Govind Kumar</a>, <a href=\"https://profiles.wordpress.org/greglone/\">Gr&#233;gory Viguier</a>, <a href=\"https://profiles.wordpress.org/gradina/\">gradina</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">Greg Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/gregmulhauser/\">gregmulhauser</a>, <a href=\"https://profiles.wordpress.org/grierson/\">grierson</a>, <a href=\"https://profiles.wordpress.org/grzegorzjanoszka/\">Grzegorz.Janoszka</a>, <a href=\"https://profiles.wordpress.org/gsmumbo/\">gsmumbo</a>, <a href=\"https://profiles.wordpress.org/wido/\">Guido Scialfa</a>, <a href=\"https://profiles.wordpress.org/guidobras/\">guidobras</a>, <a href=\"https://profiles.wordpress.org/netsurfer2705/\">Gunther Pilz</a>, <a href=\"https://profiles.wordpress.org/gwwar/\">gwwar</a>, <a href=\"https://profiles.wordpress.org/hvar/\">H-var</a>, <a href=\"https://profiles.wordpress.org/hakre/\">hakre</a>, <a href=\"https://profiles.wordpress.org/halgatewood/\">Halacious</a>, <a href=\"https://profiles.wordpress.org/hankthetank/\">hankthetank</a>, <a href=\"https://profiles.wordpress.org/psdtohtmlguru/\">Hapiuc Robert</a>, <a href=\"https://profiles.wordpress.org/hareesh-pillai/\">Hareesh</a>, <a href=\"https://profiles.wordpress.org/haukep/\">haukep</a>, <a href=\"https://profiles.wordpress.org/azhiyadev/\">Hauwa</a>, <a href=\"https://profiles.wordpress.org/hazdiego/\">Haz</a>, <a href=\"https://profiles.wordpress.org/h71/\">Hector Farahani</a>, <a href=\"https://profiles.wordpress.org/helen/\">Helen Hou-Sandi</a>, <a href=\"https://profiles.wordpress.org/henrywright/\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/herregroen/\">Herre Groen</a>, <a href=\"https://profiles.wordpress.org/hlanggo/\">hlanggo</a>, <a href=\"https://profiles.wordpress.org/hommealone/\">hommealone</a>, <a href=\"https://profiles.wordpress.org/ryanshoover/\">Hoover</a>, <a href=\"https://profiles.wordpress.org/howdy_mcgee/\">Howdy_McGee</a>, <a href=\"https://profiles.wordpress.org/hronak/\">Hronak Nahar</a>, <a href=\"https://profiles.wordpress.org/huntlyc/\">huntlyc</a>, <a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/iandstewart/\">Ian Stewart</a>, <a href=\"https://profiles.wordpress.org/ianjvr/\">ianjvr</a>, <a href=\"https://profiles.wordpress.org/ifrins/\">ifrins</a>, <a href=\"https://profiles.wordpress.org/infinum/\">infinum</a>, <a href=\"https://profiles.wordpress.org/ipstenu/\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/isabel_brison/\">Isabel Brison</a>, <a href=\"https://profiles.wordpress.org/ishitaka/\">ishitaka</a>, <a href=\"https://profiles.wordpress.org/jdgrimes/\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jackfungi/\">jackfungi</a>, <a href=\"https://profiles.wordpress.org/jacklinkers/\">jacklinkers</a>, <a href=\"https://profiles.wordpress.org/jadonn/\">Jadon N</a>, <a href=\"https://profiles.wordpress.org/jadpm/\">jadpm</a>, <a href=\"https://profiles.wordpress.org/jagirbahesh/\">jagirbahesh</a>, <a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>, <a href=\"https://profiles.wordpress.org/twentyzerotwo/\">Jake Whiteley</a>, <a href=\"https://profiles.wordpress.org/jameskoster/\">James Koster</a>, <a href=\"https://profiles.wordpress.org/jnylen0/\">James Nylen</a>, <a href=\"https://profiles.wordpress.org/foack/\">Jan Koch</a>, <a href=\"https://profiles.wordpress.org/janr/\">Jan Reilink</a>, <a href=\"https://profiles.wordpress.org/janthiel/\">Jan Thiel</a>, <a href=\"https://profiles.wordpress.org/javidalkaruzi/\">Janvo Aldred</a>, <a href=\"https://profiles.wordpress.org/jarretc/\">Jarret</a>, <a href=\"https://profiles.wordpress.org/jason_the_adams/\">Jason Adams</a>, <a href=\"https://profiles.wordpress.org/strangerstudios/\">Jason Coleman</a>, <a href=\"https://profiles.wordpress.org/boogah/\">Jason Cosper</a>, <a href=\"https://profiles.wordpress.org/coolmann/\">Jason Crouse</a>, <a href=\"https://profiles.wordpress.org/madtownlems/\">Jason LeMahieu (MadtownLems)</a>, <a href=\"https://profiles.wordpress.org/jaz_on/\">Jason Rouet</a>, <a href=\"https://profiles.wordpress.org/jaswsinc/\">JasWSInc</a>, <a href=\"https://profiles.wordpress.org/javiercasares/\">Javier Casares</a>, <a href=\"https://profiles.wordpress.org/shiki/\">Jayson Basanes</a>, <a href=\"https://profiles.wordpress.org/jbinda/\">jbinda</a>, <a href=\"https://profiles.wordpress.org/jbouganim/\">jbouganim</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jean-Baptiste Audras</a>, <a href=\"https://profiles.wordpress.org/jean-david/\">Jean-David Daviet</a>, <a href=\"https://profiles.wordpress.org/jeffr0/\">Jeff Chandler</a>, <a href=\"https://profiles.wordpress.org/jfarthing84/\">Jeff Farthing</a>, <a href=\"https://profiles.wordpress.org/jffng/\">Jeff Ong</a>, <a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeff Paul</a>, <a href=\"https://profiles.wordpress.org/jenmylo/\">Jen</a>, <a href=\"https://profiles.wordpress.org/jenilk/\">Jenil Kanani</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jeherve/\">Jeremy Herve</a>, <a href=\"https://profiles.wordpress.org/jeremyyip/\">Jeremy Yip</a>, <a href=\"https://profiles.wordpress.org/jeroenrotty/\">Jeroen Rotty</a>, <a href=\"https://profiles.wordpress.org/jeryj/\">jeryj</a>, <a href=\"https://profiles.wordpress.org/jesin/\">Jesin A</a>, <a href=\"https://profiles.wordpress.org/jigneshnakrani/\">Jignesh Nakrani</a>, <a href=\"https://profiles.wordpress.org/jim_panse/\">Jim_Panse</a>, <a href=\"https://profiles.wordpress.org/jipmoors/\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/jivanpal/\">jivanpal</a>, <a href=\"https://profiles.wordpress.org/joedolson/\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joehoyle/\">Joe Hoyle</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johannadevos/\">Johanna de Vos</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/jdorner/\">John Dorner</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/johnpgreen/\">John P. Green</a>, <a href=\"https://profiles.wordpress.org/rastaban/\">John Richards II</a>, <a href=\"https://profiles.wordpress.org/johnwatkins0/\">John Watkins</a>, <a href=\"https://profiles.wordpress.org/johnnyb/\">johnnyb</a>, <a href=\"https://profiles.wordpress.org/itsjonq/\">Jon Quach</a>, <a href=\"https://profiles.wordpress.org/jonsurrell/\">Jon Surrell</a>, <a href=\"https://profiles.wordpress.org/psykro/\">Jonathan Bossenger</a>, <a href=\"https://profiles.wordpress.org/jrchamp/\">Jonathan Champ</a>, <a href=\"https://profiles.wordpress.org/jchristopher/\">Jonathan Christopher</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jonathanstegall/\">Jonathan Stegall</a>, <a href=\"https://profiles.wordpress.org/jonkolbert/\">jonkolbert</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jonnybot/\">jonnybot</a>, <a href=\"https://profiles.wordpress.org/jonoaldersonwp/\">Jono Alderson</a>, <a href=\"https://profiles.wordpress.org/joostdevalk/\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/koke/\">Jorge Bernal</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/josephdickson/\">Joseph Dickson</a>, <a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha Haden</a>, <a href=\"https://profiles.wordpress.org/procifer/\">Josh Smith</a>, <a href=\"https://profiles.wordpress.org/joshuawold/\">JoshuaWold</a>, <a href=\"https://profiles.wordpress.org/joyously/\">Joy</a>, <a href=\"https://profiles.wordpress.org/juanfra/\">Juanfra Aldasoro</a>, <a href=\"https://profiles.wordpress.org/juanlopez4691/\">juanlopez4691</a>, <a href=\"https://profiles.wordpress.org/jules-colle/\">Jules Colle</a>, <a href=\"https://profiles.wordpress.org/julianm/\">julianm</a>, <a href=\"https://profiles.wordpress.org/jrf/\">Juliette Reinders Folmer</a>, <a href=\"https://profiles.wordpress.org/juliobox/\">Julio Potier</a>, <a href=\"https://profiles.wordpress.org/jgrodel/\">Julka Grodel</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/devesine/\">Justin de Vesine</a>, <a href=\"https://profiles.wordpress.org/greenshady/\">Justin Tadlock</a>, <a href=\"https://profiles.wordpress.org/justlevine/\">justlevine</a>, <a href=\"https://profiles.wordpress.org/justnorris/\">justnorris</a>, <a href=\"https://profiles.wordpress.org/kadamwhite/\">K. Adam White</a>, <a href=\"https://profiles.wordpress.org/kaggdesign/\">kaggdesign</a>, <a href=\"https://profiles.wordpress.org/trepmal/\">Kailey (trepmal)</a>, <a href=\"https://profiles.wordpress.org/kaira/\">Kaira</a>, <a href=\"https://profiles.wordpress.org/kaitlin414/\">Kaitlin Bolling</a>, <a href=\"https://profiles.wordpress.org/akabarikalpesh/\">Kalpesh Akabari</a>, <a href=\"https://profiles.wordpress.org/kamataryo/\">KamataRyo</a>, <a href=\"https://profiles.wordpress.org/leprincenoir/\">Kantari Samy</a>, <a href=\"https://profiles.wordpress.org/kasparsd/\">Kaspars</a>, <a href=\"https://profiles.wordpress.org/properlypurple/\">Kavya Gokul</a>, <a href=\"https://profiles.wordpress.org/keesiemeijer/\">keesiemeijer</a>, <a href=\"https://profiles.wordpress.org/ryelle/\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kennethroberson5556/\">kennethroberson5556</a>, <a href=\"https://profiles.wordpress.org/khag7/\">Kevin Hagerty</a>, <a href=\"https://profiles.wordpress.org/kharisblank/\">Kharis Sulistiyono</a>, <a href=\"https://profiles.wordpress.org/itzmekhokan/\">Khokan Sardar</a>, <a href=\"https://profiles.wordpress.org/kinjaldalwadi/\">kinjaldalwadi</a>, <a href=\"https://profiles.wordpress.org/kirilzh/\">Kiril Zhelyazkov</a>, <a href=\"https://profiles.wordpress.org/kburgoine/\">Kirsty Burgoine</a>, <a href=\"https://profiles.wordpress.org/kishanjasani/\">Kishan Jasani</a>, <a href=\"https://profiles.wordpress.org/kitchin/\">kitchin</a>, <a href=\"https://profiles.wordpress.org/ixkaito/\">Kite</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/knutsp/\">Knut Sparhell</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/xkon/\">Konstantinos Xenos</a>, <a href=\"https://profiles.wordpress.org/ksoares/\">ksoares</a>, <a href=\"https://profiles.wordpress.org/kthmd/\">KT Cheung</a>, <a href=\"https://profiles.wordpress.org/sainthkh/\">Kukhyeon Heo</a>, <a href=\"https://profiles.wordpress.org/kbjohnson90/\">Kyle B. Johnson</a>, <a href=\"https://profiles.wordpress.org/lalitpendhare/\">lalitpendhare</a>, <a href=\"https://profiles.wordpress.org/landau/\">landau</a>, <a href=\"https://profiles.wordpress.org/laternastudio/\">Laterna Studio</a>, <a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>, <a href=\"https://profiles.wordpress.org/offereins/\">Laurens Offereins</a>, <a href=\"https://profiles.wordpress.org/laxman-prajapati/\">Laxman Prajapati</a>, <a href=\"https://profiles.wordpress.org/gamerz/\">Lester Chan</a>, <a href=\"https://profiles.wordpress.org/levdbas/\">Levdbas</a>, <a href=\"https://profiles.wordpress.org/layotte/\">Lew Ayotte</a>, <a href=\"https://profiles.wordpress.org/lex_robinson/\">Lex Robinson</a>, <a href=\"https://profiles.wordpress.org/linyows/\">linyows</a>, <a href=\"https://profiles.wordpress.org/lipathor/\">lipathor</a>, <a href=\"https://profiles.wordpress.org/lschuyler/\">Lisa Schuyler</a>, <a href=\"https://profiles.wordpress.org/liuhaibin/\">liuhaibin</a>, <a href=\"https://profiles.wordpress.org/ljharb/\">ljharb</a>, <a href=\"https://profiles.wordpress.org/logig/\">logig</a>, <a href=\"https://profiles.wordpress.org/lucasbustamante/\">lucasbustamante</a>, <a href=\"https://profiles.wordpress.org/lwill/\">luiswill</a>, <a href=\"https://profiles.wordpress.org/lukecavanagh/\">Luke Cavanagh</a>, <a href=\"https://profiles.wordpress.org/happiryu/\">Luke Walczak</a>, <a href=\"https://profiles.wordpress.org/lukestramasonder/\">lukestramasonder</a>, <a href=\"https://profiles.wordpress.org/asif2bd/\">M Asif Rahman</a>, <a href=\"https://profiles.wordpress.org/msafi/\">M.K. Safi</a>, <a href=\"https://profiles.wordpress.org/cloudstek/\">Maarten de Boer</a>, <a href=\"https://profiles.wordpress.org/aladin02dz/\">Mahfoudh Arous</a>, <a href=\"https://profiles.wordpress.org/mailnew2ster/\">mailnew2ster</a>, <a href=\"https://profiles.wordpress.org/manojlovic/\">manojlovic</a>, <a href=\"https://profiles.wordpress.org/targz-1/\">Manuel Schmalstieg</a>, <a href=\"https://profiles.wordpress.org/neodjandre/\">maraki</a>, <a href=\"https://profiles.wordpress.org/iworks/\">Marcin Pietrzak</a>, <a href=\"https://profiles.wordpress.org/marcio-zebedeu/\">Marcio Zebedeu</a>, <a href=\"https://profiles.wordpress.org/pereirinha/\">Marco Pereirinha</a>, <a href=\"https://profiles.wordpress.org/marcoz/\">MarcoZ</a>, <a href=\"https://profiles.wordpress.org/netweblogic/\">Marcus</a>, <a href=\"https://profiles.wordpress.org/mkaz/\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/marekdedic/\">Marek Dědič</a>, <a href=\"https://profiles.wordpress.org/marekhrabe/\">Marek Hrabe</a>, <a href=\"https://profiles.wordpress.org/mariovalney/\">Mario Valney</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius Jensen</a>, <a href=\"https://profiles.wordpress.org/machouinard/\">Mark Chouinard</a>, <a href=\"https://profiles.wordpress.org/markjaquith/\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/markparnell/\">Mark Parnell</a>, <a href=\"https://profiles.wordpress.org/mapk/\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/markdubois/\">markdubois</a>, <a href=\"https://profiles.wordpress.org/markgoho/\">markgoho</a>, <a href=\"https://profiles.wordpress.org/vindl/\">Marko Andrijasevic</a>, <a href=\"https://profiles.wordpress.org/markoheijnen/\">Marko Heijnen</a>, <a href=\"https://profiles.wordpress.org/markrh/\">MarkRH</a>, <a href=\"https://profiles.wordpress.org/markshep/\">markshep</a>, <a href=\"https://profiles.wordpress.org/markusthiel/\">markusthiel</a>, <a href=\"https://profiles.wordpress.org/martijn-van-der-kooij/\">Martijn van der Kooij</a>, <a href=\"https://profiles.wordpress.org/martychc23/\">martychc23</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>, <a href=\"https://profiles.wordpress.org/matheusfd/\">Matheus Martins</a>, <a href=\"https://profiles.wordpress.org/imath/\">Mathieu Viet</a>, <a href=\"https://profiles.wordpress.org/matveb/\">Matias Ventura</a>, <a href=\"https://profiles.wordpress.org/matjack1/\">matjack1</a>, <a href=\"https://profiles.wordpress.org/webdevmattcrom/\">Matt Cromwell</a>, <a href=\"https://profiles.wordpress.org/gothickgothickorguk/\">Matt Gibson</a>, <a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/mattrad/\">Matt Radford</a>, <a href=\"https://profiles.wordpress.org/veraxus/\">Matt van Andel</a>, <a href=\"https://profiles.wordpress.org/mattchowning/\">mattchowning</a>, <a href=\"https://profiles.wordpress.org/mboynes/\">Matthew Boynes</a>, <a href=\"https://profiles.wordpress.org/mattheweppelsheimer/\">Matthew Eppelsheimer</a>, <a href=\"https://profiles.wordpress.org/beatpanda/\">Matthew Gerring</a>, <a href=\"https://profiles.wordpress.org/kittmedia/\">Matthias Kittsteiner</a>, <a href=\"https://profiles.wordpress.org/pfefferle/\">Matthias Pfefferle</a>, <a href=\"https://profiles.wordpress.org/matthieumota/\">Matthieu Mota</a>, <a href=\"https://profiles.wordpress.org/mattyrob/\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/maximeculea/\">Maxime Culea</a>, <a href=\"https://profiles.wordpress.org/maxpertici/\">Maxime Pertici</a>, <a href=\"https://profiles.wordpress.org/maxme/\">maxme</a>, <a href=\"https://profiles.wordpress.org/mayankmajeji/\">Mayank Majeji</a>, <a href=\"https://profiles.wordpress.org/mcshane/\">mcshane</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce-Dwan</a>, <a href=\"https://profiles.wordpress.org/menakas/\">Menaka S.</a>, <a href=\"https://profiles.wordpress.org/mensmaximus/\">mensmaximus</a>, <a href=\"https://profiles.wordpress.org/metalandcoffee/\">metalandcoffee</a>, <a href=\"https://profiles.wordpress.org/lilmike/\">Michael</a>, <a href=\"https://profiles.wordpress.org/michaelarestad/\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/michael-arestad/\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/tw2113/\">Michael Beckwith</a>, <a href=\"https://profiles.wordpress.org/mfields/\">Michael Fields</a>, <a href=\"https://profiles.wordpress.org/mnelson4/\">Michael Nelson</a>, <a href=\"https://profiles.wordpress.org/m_butcher/\">Michele Butcher-Jones</a>, <a href=\"https://profiles.wordpress.org/marktimemedia/\">Michelle</a>, <a href=\"https://profiles.wordpress.org/mcsf/\">Miguel Fonseca</a>, <a href=\"https://profiles.wordpress.org/mihdan/\">mihdan</a>, <a href=\"https://profiles.wordpress.org/miinasikk/\">Miina Sikk</a>, <a href=\"https://profiles.wordpress.org/simison/\">Mikael Korpela</a>, <a href=\"https://profiles.wordpress.org/mikaumoto/\">mikaumoto</a>, <a href=\"https://profiles.wordpress.org/mihai2u/\">Mike Crantea</a>, <a href=\"https://profiles.wordpress.org/mdgl/\">Mike Glendinning</a>, <a href=\"https://profiles.wordpress.org/mike-haydon-swo/\">Mike Haydon</a>, <a href=\"https://profiles.wordpress.org/mikeschinkel/\">Mike Schinkel [WPLib Box project lead]</a>, <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mikeyarce/\">Mikey Arce</a>, <a href=\"https://profiles.wordpress.org/milana_cap/\">Milana Cap</a>, <a href=\"https://profiles.wordpress.org/milindmore22/\">Milind More</a>, <a href=\"https://profiles.wordpress.org/mimitips/\">mimi</a>, <a href=\"https://profiles.wordpress.org/mislavjuric/\">mislavjuric</a>, <a href=\"https://profiles.wordpress.org/batmoo/\">Mohammad Jangda</a>, <a href=\"https://profiles.wordpress.org/opurockey/\">Mohammad Rockeybul Alam</a>, <a href=\"https://profiles.wordpress.org/mohsinrasool/\">Mohsin Rasool</a>, <a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>, <a href=\"https://profiles.wordpress.org/gwendydd/\">Morgan Kay</a>, <a href=\"https://profiles.wordpress.org/mor10/\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/man4toman/\">Morteza Geransayeh</a>, <a href=\"https://profiles.wordpress.org/mt8biz/\">moto hachi ( mt8.biz )</a>, <a href=\"https://profiles.wordpress.org/mrgrt/\">mrgrt</a>, <a href=\"https://profiles.wordpress.org/mrmist/\">mrmist</a>, <a href=\"https://profiles.wordpress.org/mrtall/\">mrTall</a>, <a href=\"https://profiles.wordpress.org/msaggiorato/\">msaggiorato</a>, <a href=\"https://profiles.wordpress.org/musamamasood/\">Muhammad Usama Masood</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/munyagu/\">munyagu</a>, <a href=\"https://profiles.wordpress.org/nabilmoqbel/\">Nabil Moqbel</a>, <a href=\"https://profiles.wordpress.org/assassinateur/\">Nadir Seghir</a>, <a href=\"https://profiles.wordpress.org/nfmohit/\">Nahid Ferdous Mohit</a>, <a href=\"https://profiles.wordpress.org/nalininonstopnewsuk/\">Nalini Thakor</a>, <a href=\"https://profiles.wordpress.org/nao/\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/narwen/\">narwen</a>, <a href=\"https://profiles.wordpress.org/nateinaction/\">Nate Gay</a>, <a href=\"https://profiles.wordpress.org/nathanrice/\">Nathan Rice</a>, <a href=\"https://profiles.wordpress.org/navidos/\">Navid</a>, <a href=\"https://profiles.wordpress.org/neonkowy/\">neonkowy</a>, <a href=\"https://profiles.wordpress.org/krstarica/\">net</a>, <a href=\"https://profiles.wordpress.org/netpassprodsr/\">netpassprodsr</a>, <a href=\"https://profiles.wordpress.org/nextendweb/\">Nextendweb</a>, <a href=\"https://profiles.wordpress.org/calvin_ngan/\">Ngan Tengyuen</a>, <a href=\"https://profiles.wordpress.org/nickdaugherty/\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/nickylimjj/\">Nicky Lim</a>, <a href=\"https://profiles.wordpress.org/vadimnicolai/\">nicolad</a>, <a href=\"https://profiles.wordpress.org/rahe/\">Nicolas Juen</a>, <a href=\"https://profiles.wordpress.org/nicolaskulka/\">NicolasKulka</a>, <a href=\"https://profiles.wordpress.org/jainnidhi/\">Nidhi Jain</a>, <a href=\"https://profiles.wordpress.org/nielsdeblaauw/\">Niels de Blaauw</a>, <a href=\"https://profiles.wordpress.org/nielslange/\">Niels Lange</a>, <a href=\"https://profiles.wordpress.org/nigrosimone/\">nigro.simone</a>, <a href=\"https://profiles.wordpress.org/ntsekouras/\">Nik Tsekouras</a>, <a href=\"https://profiles.wordpress.org/nikhilbhansi/\">Nikhil Bhansi</a>, <a href=\"https://profiles.wordpress.org/nbachiyski/\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/nilovelez/\">Nilo Velez</a>, <a href=\"https://profiles.wordpress.org/niresh12495/\">Niresh</a>, <a href=\"https://profiles.wordpress.org/nmenescardi/\">nmenescardi</a>, <a href=\"https://profiles.wordpress.org/noahtallen/\">Noah Allen</a>, <a href=\"https://profiles.wordpress.org/numidwasnotavailable/\">NumidWasNotAvailable</a>, <a href=\"https://profiles.wordpress.org/oakesjosh/\">oakesjosh</a>, <a href=\"https://profiles.wordpress.org/obliviousharmony/\">obliviousharmony</a>, <a href=\"https://profiles.wordpress.org/ockham/\">ockham</a>, <a href=\"https://profiles.wordpress.org/oglekler/\">Olga Gleckler</a>, <a href=\"https://profiles.wordpress.org/alshakero/\">Omar Alshaker</a>, <a href=\"https://profiles.wordpress.org/omarreiss/\">Omar Reiss</a>, <a href=\"https://profiles.wordpress.org/onokazu/\">onokazu</a>, <a href=\"https://profiles.wordpress.org/optimizingmatters/\">Optimizing Matters</a>, <a href=\"https://profiles.wordpress.org/ov3rfly/\">Ov3rfly</a>, <a href=\"https://profiles.wordpress.org/ovann86/\">ovann86</a>, <a href=\"https://profiles.wordpress.org/overclokk/\">overclokk</a>, <a href=\"https://profiles.wordpress.org/p_enrique/\">p_enrique</a>, <a href=\"https://profiles.wordpress.org/paaljoachim/\">Paal Joachim Romdahl</a>, <a href=\"https://profiles.wordpress.org/pablohoneyhoney/\">Pablo Honey</a>, <a href=\"https://profiles.wordpress.org/paddy/\">Paddy</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">palmiak</a>, <a href=\"https://profiles.wordpress.org/paresh07/\">Paresh Shinde</a>, <a href=\"https://profiles.wordpress.org/parvand/\">Parvand</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/casiepa/\">Pascal Casier</a>, <a href=\"https://profiles.wordpress.org/pbearne/\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/pbiron/\">Paul Biron</a>, <a href=\"https://profiles.wordpress.org/pdfernhout/\">Paul Fernhout</a>, <a href=\"https://profiles.wordpress.org/djpaul/\">Paul Gibbs</a>, <a href=\"https://profiles.wordpress.org/figureone/\">Paul Ryan</a>, <a href=\"https://profiles.wordpress.org/paulschreiber/\">Paul Schreiber</a>, <a href=\"https://profiles.wordpress.org/paulstonier/\">Paul Stonier</a>, <a href=\"https://profiles.wordpress.org/pschrottky/\">Paul Von Schrottky</a>, <a href=\"https://profiles.wordpress.org/pavelevap/\">pavelevap</a>, <a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendon&#231;a</a>, <a href=\"https://profiles.wordpress.org/pentatonicfunk/\">pentatonicfunk</a>, <a href=\"https://profiles.wordpress.org/pputzer/\">pepe</a>, <a href=\"https://profiles.wordpress.org/pessoft/\">Peter \"Pessoft\" Kol&#237;nek</a>, <a href=\"https://profiles.wordpress.org/westi/\">Peter Westwood</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/pderksen/\">Phil Derksen</a>, <a href=\"https://profiles.wordpress.org/johnstonphilip/\">Phil Johnston</a>, <a href=\"https://profiles.wordpress.org/philipmjackson/\">Philip Jackson</a>, <a href=\"https://profiles.wordpress.org/pierlo/\">Pierre Gordon</a>, <a href=\"https://profiles.wordpress.org/pigdog234/\">pigdog234</a>, <a href=\"https://profiles.wordpress.org/pikamander2/\">pikamander2</a>, <a href=\"https://profiles.wordpress.org/pingram3541/\">pingram</a>, <a href=\"https://profiles.wordpress.org/pionect/\">Pionect</a>, <a href=\"https://profiles.wordpress.org/piyushmca/\">Piyush Patel</a>, <a href=\"https://profiles.wordpress.org/pkarjala/\">pkarjala</a>, <a href=\"https://profiles.wordpress.org/pkvillanueva/\">pkvillanueva</a>, <a href=\"https://profiles.wordpress.org/pmbaldha/\">Prashant Baldha</a>, <a href=\"https://profiles.wordpress.org/pratik028/\">pratik028</a>, <a href=\"https://profiles.wordpress.org/pravinparmar2404/\">Pravin Parmar</a>, <a href=\"https://profiles.wordpress.org/presskopp/\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/presslabs/\">Presslabs</a>, <a href=\"https://profiles.wordpress.org/priyankkpatel/\">Priyank Patel</a>, <a href=\"https://profiles.wordpress.org/priyomukul/\">Priyo Mukul</a>, <a href=\"https://profiles.wordpress.org/prografika/\">ProGrafika</a>, <a href=\"https://profiles.wordpress.org/programmin/\">programmin</a>, <a href=\"https://profiles.wordpress.org/puneetsahalot/\">Puneet Sahalot</a>, <a href=\"https://profiles.wordpress.org/pvogel2/\">pvogel2</a>, <a href=\"https://profiles.wordpress.org/r-a-y/\">r-a-y</a>, <a href=\"https://profiles.wordpress.org/raajtram/\">Raaj Trambadia</a>, <a href=\"https://profiles.wordpress.org/larrach/\">Rachel Peter</a>, <a href=\"https://profiles.wordpress.org/raineorshine/\">raine</a>, <a href=\"https://profiles.wordpress.org/rajeshsingh520/\">rajeshsingh520</a>, <a href=\"https://profiles.wordpress.org/superpoincare/\">Ramanan</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/ravanh/\">RavanH</a>, <a href=\"https://profiles.wordpress.org/ravatparmar/\">Ravat Parmar</a>, <a href=\"https://profiles.wordpress.org/ravenswd/\">ravenswd</a>, <a href=\"https://profiles.wordpress.org/rawrly/\">rawrly</a>, <a href=\"https://profiles.wordpress.org/rebasaurus/\">rebasaurus</a>, <a href=\"https://profiles.wordpress.org/redsand/\">Red Sand Media Group</a>, <a href=\"https://profiles.wordpress.org/tabrisrp/\">Remy Perona</a>, <a href=\"https://profiles.wordpress.org/remzicavdar/\">Remzi Cavdar</a>, <a href=\"https://profiles.wordpress.org/renathoc/\">Renatho</a>, <a href=\"https://profiles.wordpress.org/renggo888/\">renggo888</a>, <a href=\"https://profiles.wordpress.org/retlehs/\">retlehs</a>, <a href=\"https://profiles.wordpress.org/retrofox/\">retrofox</a>, <a href=\"https://profiles.wordpress.org/riaanlom/\">riaanlom</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/rianrietveld/\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/riasat/\">riasat</a>, <a href=\"https://profiles.wordpress.org/richtabor/\">Rich Tabor</a>, <a href=\"https://profiles.wordpress.org/ringisha/\">Ringisha</a>, <a href=\"https://profiles.wordpress.org/ritterml/\">ritterml</a>, <a href=\"https://profiles.wordpress.org/rnaby/\">Rnaby</a>, <a href=\"https://profiles.wordpress.org/rcutmore/\">Rob Cutmore</a>, <a href=\"https://profiles.wordpress.org/dhrrob/\">Rob Migchels</a>, <a href=\"https://profiles.wordpress.org/rob006/\">rob006</a>, <a href=\"https://profiles.wordpress.org/noisysocks/\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/miqrogroove/\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/robertpeake/\">Robert Peake</a>, <a href=\"https://profiles.wordpress.org/nullbyte/\">Robert Windisch</a>, <a href=\"https://profiles.wordpress.org/kreppar/\">Rodrigo Arias</a>, <a href=\"https://profiles.wordpress.org/ronalfy/\">Ronald Huereca</a>, <a href=\"https://profiles.wordpress.org/costasovo/\">Rostislav Woln&#253;</a>, <a href=\"https://profiles.wordpress.org/roytanck/\">Roy Tanck</a>, <a href=\"https://profiles.wordpress.org/rtagliento/\">rtagliento</a>, <a href=\"https://profiles.wordpress.org/ruxandra/\">ruxandra</a>, <a href=\"https://profiles.wordpress.org/ryan/\">Ryan Boren</a>, <a href=\"https://profiles.wordpress.org/bookdude13/\">Ryan Fredlund</a>, <a href=\"https://profiles.wordpress.org/ryankienstra/\">Ryan Kienstra</a>, <a href=\"https://profiles.wordpress.org/rmccue/\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/welcher/\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/ryotasakamoto/\">Ryota Sakamoto</a>, <a href=\"https://profiles.wordpress.org/ryotsun/\">ryotsun</a>, <a href=\"https://profiles.wordpress.org/soean/\">S&#246;ren Wrede</a>, <a href=\"https://profiles.wordpress.org/sorenbronsted/\">S&#248;ren Br&#248;nsted</a>, <a href=\"https://profiles.wordpress.org/sachittandukar/\">Sachit Tandukar</a>, <a href=\"https://profiles.wordpress.org/sagarjadhav/\">Sagar Jadhav</a>, <a href=\"https://profiles.wordpress.org/sajjad67/\">Sajjad Hossain Sagor</a>, <a href=\"https://profiles.wordpress.org/salcode/\">Sal Ferrarello</a>, <a href=\"https://profiles.wordpress.org/salvatoreformisano/\">Salvatore Formisano</a>, <a href=\"https://profiles.wordpress.org/salvoaranzulla/\">salvoaranzulla</a>, <a href=\"https://profiles.wordpress.org/samful/\">Sam Fullalove</a>, <a href=\"https://profiles.wordpress.org/sswebster/\">Sam Webster</a>, <a href=\"https://profiles.wordpress.org/solarissmoke/\">Samir Shah</a>, <a href=\"https://profiles.wordpress.org/otto42/\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/samueljseay/\">samueljseay</a>, <a href=\"https://profiles.wordpress.org/pacifika/\">Sander van Dragt</a>, <a href=\"https://profiles.wordpress.org/sanzeeb3/\">Sanjeev Aryal</a>, <a href=\"https://profiles.wordpress.org/progremzion/\">Sanket Mehta</a>, <a href=\"https://profiles.wordpress.org/sarahricker/\">sarahricker</a>, <a href=\"https://profiles.wordpress.org/sathyapulse/\">Sathiyamoorthy V</a>, <a href=\"https://profiles.wordpress.org/sayedwp/\">Sayed Taqui</a>, <a href=\"https://profiles.wordpress.org/scarolan/\">scarolan</a>, <a href=\"https://profiles.wordpress.org/scholdstrom/\">scholdstrom</a>, <a href=\"https://profiles.wordpress.org/sc0ttkclark/\">Scott Kingsley Clark</a>, <a href=\"https://profiles.wordpress.org/coffee2code/\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/scottsmith/\">Scott Smith</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic/\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scribu/\">scribu</a>, <a href=\"https://profiles.wordpress.org/scruffian/\">scruffian</a>, <a href=\"https://profiles.wordpress.org/seanchayes/\">Sean Hayes</a>, <a href=\"https://profiles.wordpress.org/seanpaulrasmussen/\">seanpaulrasmussen</a>, <a href=\"https://profiles.wordpress.org/seayou/\">seayou</a>, <a href=\"https://profiles.wordpress.org/senatorman/\">senatorman</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/vjik/\">Sergey Predvoditelev</a>, <a href=\"https://profiles.wordpress.org/sgr33n/\">Sergio de Falco</a>, <a href=\"https://profiles.wordpress.org/sergiomdgomes/\">sergiomdgomes</a>, <a href=\"https://profiles.wordpress.org/functionalrhyme/\">Shannon Smith</a>, <a href=\"https://profiles.wordpress.org/wpshades/\">Shantanu Desai</a>, <a href=\"https://profiles.wordpress.org/shaunandrews/\">shaunandrews</a>, <a href=\"https://profiles.wordpress.org/shooper/\">Shawn Hooper</a>, <a href=\"https://profiles.wordpress.org/shawnz/\">shawnz</a>, <a href=\"https://profiles.wordpress.org/shital-patel/\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/shulard/\">shulard</a>, <a href=\"https://profiles.wordpress.org/siliconforks/\">siliconforks</a>, <a href=\"https://profiles.wordpress.org/simonwheatley/\">Simon Wheatley</a>, <a href=\"https://profiles.wordpress.org/simonjanin/\">simonjanin</a>, <a href=\"https://profiles.wordpress.org/sinatrateam/\">sinatrateam</a>, <a href=\"https://profiles.wordpress.org/sjmur/\">sjmur</a>, <a href=\"https://profiles.wordpress.org/skarabeq/\">skarabeq</a>, <a href=\"https://profiles.wordpress.org/skorasaurus/\">skorasaurus</a>, <a href=\"https://profiles.wordpress.org/skoskie/\">skoskie</a>, <a href=\"https://profiles.wordpress.org/slushman/\">slushman</a>, <a href=\"https://profiles.wordpress.org/snapfractalpop/\">snapfractalpop</a>, <a href=\"https://profiles.wordpress.org/seth17/\">SpearsMarketing</a>, <a href=\"https://profiles.wordpress.org/sphakka/\">sphakka</a>, <a href=\"https://profiles.wordpress.org/squarecandy/\">squarecandy</a>, <a href=\"https://profiles.wordpress.org/sreedoap/\">sreedoap</a>, <a href=\"https://profiles.wordpress.org/sstoqnov/\">Stanimir Stoyanov</a>, <a href=\"https://profiles.wordpress.org/ryokuhi/\">Stefano Minoia</a>, <a href=\"https://profiles.wordpress.org/hypest/\">Stefanos Togoulidis</a>, <a href=\"https://profiles.wordpress.org/sswells/\">Steph Wells</a>, <a href=\"https://profiles.wordpress.org/sabernhardt/\">Stephen Bernhardt</a>, <a href=\"https://profiles.wordpress.org/stephencronin/\">Stephen Cronin</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/dufresnesteven/\">Steve Dufresne</a>, <a href=\"https://profiles.wordpress.org/stevegibson12/\">stevegibson12</a>, <a href=\"https://profiles.wordpress.org/sterndata/\">Steven Stern (sterndata)</a>, <a href=\"https://profiles.wordpress.org/stevenkword/\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/stevenkussmaul/\">stevenkussmaul</a>, <a href=\"https://profiles.wordpress.org/stevenlinx/\">stevenlinx</a>, <a href=\"https://profiles.wordpress.org/stiofansisland/\">Stiofan</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence/\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/sum1/\">SUM1</a>, <a href=\"https://profiles.wordpress.org/quadthemes/\">Sunny</a>, <a href=\"https://profiles.wordpress.org/sunnyratilal/\">Sunny Ratilal</a>, <a href=\"https://profiles.wordpress.org/sushyant/\">Sushyant Zavarzadeh</a>, <a href=\"https://profiles.wordpress.org/suzylah/\">suzylah</a>, <a href=\"https://profiles.wordpress.org/cybr/\">Sybre Waaijer</a>, <a href=\"https://profiles.wordpress.org/synchro/\">Synchro</a>, <a href=\"https://profiles.wordpress.org/sergioestevao/\">Sérgio Estêvão</a>, <a href=\"https://profiles.wordpress.org/miyauchi/\">Takayuki Miyauchi</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/tangrufus/\">Tang Rufus</a>, <a href=\"https://profiles.wordpress.org/utz119/\">TeBenachi</a>, <a href=\"https://profiles.wordpress.org/tessawatkinsllc/\">Tessa Watkins LLC</a>, <a href=\"https://profiles.wordpress.org/wildworks/\">Tetsuaki Hamano</a>, <a href=\"https://profiles.wordpress.org/themiked/\">theMikeD</a>, <a href=\"https://profiles.wordpress.org/theolg/\">theolg</a>, <a href=\"https://profiles.wordpress.org/tweetythierry/\">Thierry Muller</a>, <a href=\"https://profiles.wordpress.org/thimalw/\">Thimal Wickremage</a>, <a href=\"https://profiles.wordpress.org/webzunft/\">Thomas M</a>, <a href=\"https://profiles.wordpress.org/tfrommen/\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/thrijith/\">Thrijith Thankachan</a>, <a href=\"https://profiles.wordpress.org/tiagohillebrandt/\">Tiago Hillebrandt</a>, <a href=\"https://profiles.wordpress.org/tillkruess/\">Till Kr&#252;ss</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/tkama/\">Tkama</a>, <a href=\"https://profiles.wordpress.org/tmdesigned/\">tmdesigned</a>, <a href=\"https://profiles.wordpress.org/tmoore41/\">tmoore41</a>, <a href=\"https://profiles.wordpress.org/tobiasbg/\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tobifjellner/\">tobifjellner (Tor-Bjorn Fjellner)</a>, <a href=\"https://profiles.wordpress.org/tofandel/\">Tofandel</a>, <a href=\"https://profiles.wordpress.org/tomdude/\">tomdude</a>, <a href=\"https://profiles.wordpress.org/tferry/\">Tommy Ferry</a>, <a href=\"https://profiles.wordpress.org/starbuck/\">Tony G</a>, <a href=\"https://profiles.wordpress.org/toro_unit/\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/torres126/\">torres126</a>, <a href=\"https://profiles.wordpress.org/zodiac1978/\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/toru/\">Toru Miki</a>, <a href=\"https://profiles.wordpress.org/travisnorthcutt/\">Travis Northcutt</a>, <a href=\"https://profiles.wordpress.org/treecutter/\">treecutter</a>, <a href=\"https://profiles.wordpress.org/truongwp/\">truongwp</a>, <a href=\"https://profiles.wordpress.org/tsimmons/\">tsimmons</a>, <a href=\"https://profiles.wordpress.org/dinhtungdu/\">Tung Du</a>, <a href=\"https://profiles.wordpress.org/desaiuditd/\">Udit Desai</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich/\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/vagios/\">Vagios Vlachos</a>, <a href=\"https://profiles.wordpress.org/valchovski/\">valchovski</a>, <a href=\"https://profiles.wordpress.org/valentinbora/\">Valentin Bora</a>, <a href=\"https://profiles.wordpress.org/vayu/\">Vayu Robins</a>, <a href=\"https://profiles.wordpress.org/veromary/\">veromary</a>, <a href=\"https://profiles.wordpress.org/szepeviktor/\">Viktor Sz&#233;pe</a>, <a href=\"https://profiles.wordpress.org/vinkla/\">vinkla</a>, <a href=\"https://profiles.wordpress.org/virginienacci/\">virginienacci</a>, <a href=\"https://profiles.wordpress.org/planvova/\">Vladimir</a>, <a href=\"https://profiles.wordpress.org/vabrashev/\">Vladislav Abrashev</a>, <a href=\"https://profiles.wordpress.org/vortfu/\">vortfu</a>, <a href=\"https://profiles.wordpress.org/voyager131/\">voyager131</a>, <a href=\"https://profiles.wordpress.org/vtieu/\">vtieu</a>, <a href=\"https://profiles.wordpress.org/webaware/\">webaware</a>, <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/williampatton/\">williampatton</a>, <a href=\"https://profiles.wordpress.org/planningwrite/\">Winstina</a>, <a href=\"https://profiles.wordpress.org/wittich/\">wittich</a>, <a href=\"https://profiles.wordpress.org/wpdesk/\">wpdesk</a>, <a href=\"https://profiles.wordpress.org/wpdo5ea/\">WPDO</a>, <a href=\"https://profiles.wordpress.org/alexandreb3/\">WPMarmite</a>, <a href=\"https://profiles.wordpress.org/wppinar/\">wppinar</a>, <a href=\"https://profiles.wordpress.org/yahil/\">Yahil Madakiya</a>, <a href=\"https://profiles.wordpress.org/yashrs/\">yashrs</a>, <a href=\"https://profiles.wordpress.org/yoancutillas/\">yoancutillas</a>, <a href=\"https://profiles.wordpress.org/yoavf/\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/yohannp/\">yohannp</a>, <a href=\"https://profiles.wordpress.org/yuhin/\">yuhin</a>, <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>, <a href=\"https://profiles.wordpress.org/ysalame/\">Yuri Salame</a>, <a href=\"https://profiles.wordpress.org/yvettesonneveld/\">Yvette Sonneveld</a>, <a href=\"https://profiles.wordpress.org/tollmanz/\">Zack Tollman</a>, <a href=\"https://profiles.wordpress.org/zaheerahmad/\">zaheerahmad</a>, <a href=\"https://profiles.wordpress.org/zakkath/\">zakkath</a>, <a href=\"https://profiles.wordpress.org/zebulan/\">Zebulan Stanphill</a>, <a href=\"https://profiles.wordpress.org/zieladam/\">zieladam</a>, and <a href=\"https://profiles.wordpress.org/chesio/\">Česlav Przywara</a>.



<p>&nbsp;</p>



<p>Many thanks to all of the community volunteers who contribute in the&nbsp;<a href=\"https://wordpress.org/support/\">support forums</a>. They answer questions from people across the world, whether they are using WordPress for the first time or since the first release. These releases are more successful for their efforts!</p>



<p>Finally, thanks to all the community translators who worked on WordPress 5.5. Their efforts bring WordPress fully translated to&nbsp;46 languages at release time, with more on the way.</p>



<p>If you want to learn more about volunteering with WordPress, check out&nbsp;<a href=\"https://make.wordpress.org/\">Make WordPress</a>&nbsp;or the&nbsp;<a href=\"https://make.wordpress.org/core/\">core development blog</a>.</p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:2%\"></div>
</div>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8799\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WordPress 5.5 Release Candidate 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2020/08/wordpress-5-5-release-candidate-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2020 19:12:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8764\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:420:\"The second release candidate for WordPress 5.5 is here! WordPress 5.5 is slated for release&#160;on&#160;August 11, 2020, but we need&#160;your&#160;help to get there—if you haven’t tried 5.5 yet,&#160;now is the time! You can test the WordPress 5.5 release candidate in two ways: Try the&#160;WordPress Beta Tester&#160;plugin (choose the “bleeding edge nightlies” option) Or&#160;download the release [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2503:\"
<p>The second release candidate for WordPress 5.5 is here!</p>



<p>WordPress 5.5 is slated for release&nbsp;on&nbsp;<strong>August 11, 2020</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.5 yet,&nbsp;now is the time!</p>



<p>You can test the WordPress 5.5 release candidate in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-RC2.zip\">download the release candidate here (zip)</a>.</li></ul>



<p>Thank you to all of the contributors who tested the&nbsp;Beta releases and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress.</p>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.5 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme file to 5.5. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>,&nbsp;so those can be figured out before the final release.</p>



<p>For a more detailed breakdown of the changes included in WordPress 5.5, check out the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1/\">WordPress 5.5 beta 1 post</a>. The&nbsp;<a href=\"https://make.wordpress.org/core/2020/07/30/wordpress-5-5-field-guide/\">WordPress 5.5 Field Guide</a>&nbsp;is also out! It’s your source for details on all the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;This release also marks the&nbsp;<a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">hard string freeze</a>&nbsp;point of the 5.5 release schedule.</p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">fill one on WordPress Trac</a>, where you can also find&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8764\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"The Month in WordPress: July 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2020/08/the-month-in-wordpress-july-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Aug 2020 13:54:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8755\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:340:\"July was an action-packed month for the WordPress project. The month saw a lot of updates on one of the most anticipated releases &#8211; WordPress 5.5! WordCamp US 2020 was canceled and the WordPress community team started experimenting with different formats for engaging online events, in July. Read on to catch up with all the [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:11539:\"
<p>July was an action-packed month for the WordPress project. The month saw a lot of updates on one of the most anticipated releases &#8211; WordPress 5.5! WordCamp US 2020 was canceled and the WordPress community team started experimenting with different formats for engaging online events, in July. Read on to catch up with all the updates from the WordPress world.</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.5 Updates</h2>



<p>July was full of WordPress 5.5 updates! The WordPress 5.5 <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1\">Beta 1</a> came out on July 7, followed by <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\">Beta 2</a> on July 14, <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\">Beta 3</a> on July 21, and <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-4/\">Beta 4</a> on July 27. Subsequently, the team also published the first <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-release-candidate/\">release candidate</a> of WordPress 5.5 on July 28.&nbsp;</p>



<p>WordPress 5.5, which is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11, 2020</a>, is a major update with features like <a href=\"https://make.wordpress.org/core/tag/feature-autoupdates/\">automatic updates for plugins and themes</a>, a <a href=\"https://make.wordpress.org/plugins/2020/07/22/proposed-block-directory-guidelines/\">block directory</a>, <a href=\"https://make.wordpress.org/core/2020/06/10/merge-announcement-extensible-core-sitemaps/\">XML sitemaps</a>, <a href=\"https://make.wordpress.org/core/2020/07/16/block-patterns-in-wordpress-5-5/\">block patterns</a>, and <a href=\"https://make.wordpress.org/core/2020/07/14/lazy-loading-images-in-5-5/\">lazy-loading images</a>, among others. To learn more about the release, check out its <a href=\"https://make.wordpress.org/core/2020/07/30/wordpress-5-5-field-guide/\">field guide post</a>.</p>



<p>Want to get involved in building WordPress Core? Follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Gutenberg 8.5 and 8.6</h2>



<p>The core team launched Gutenberg <a href=\"https://make.wordpress.org/core/2020/07/08/whats-new-in-gutenberg-8-july/\">8.5</a> and <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>. Version 8.5 &#8211; the last plugin release will be included entirely (without experimental features) in WordPress 5.5, introduced improvements to block drag-and-drop and accessibility, easier updates for external images, and support for the block directory. Version 8.6 comes with features like Cover block video position controls and block pattern updates. For full details on the latest versions on these Gutenberg releases, visit these posts about <a href=\"https://make.wordpress.org/core/2020/07/08/whats-new-in-gutenberg-8-july/\">8.5</a> and <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Reimagining Online WordPress Events</h2>



<p>The Community team made the difficult decision <a href=\"https://make.wordpress.org/community/2020/07/27/in-person-events-in-rest-of-year-2020/\">to suspend in-person WordPress events for the rest of 2020</a> in light of the COVID-19 pandemic. The team has also started working on <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/\">reimagining online events</a>. Based on <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/#comment-28505\">feedback from the community members</a>, the team decided to <a href=\"https://make.wordpress.org/community/2020/07/23/moving-forward-with-online-events/\">make changes to the current online WordCamp format</a>. Key changes include wrapping up financial support for A/V vendors, ending event swag support for newer online WordCamps, and suspending the Global Community Sponsorship program for 2020. The team encourages upcoming online WordCamps to experiment with their events to facilitate an effective learning experience for attendees while avoiding online event fatigue. The team is currently working on a proposal to organize community-supported <a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">recorded workshops and synchronous discussion groups</a> to help community members learn WordPress.<br><br>Want to get involved with the Community team? <a href=\"https://make.wordpress.org/community/\">Follow the Community blog here</a>, or join them in the #community-events channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>. To organize a Meetup or WordCamp, <a href=\"https://make.wordpress.org/community/handbook/virtual-events/welcome/applying-for-a-virtual-event/\">visit the handbook page</a>.&nbsp;</p>



<h2>WordCamp US 2020 is canceled</h2>



<p>The organizers of WordCamp US 2020 have <a href=\"https://2020.us.wordcamp.org/2020/07/30/wcus-2020-an-update/\">canceled the event</a> in light of the continued pandemic and online event fatigue. The flagship event, which was originally scheduled for October 27-29 as an in-person event, had already planned to transition to an online event. Several WCUS Organizers will be working with the WordPress Community team to focus on other formats and ideas for online events, including a 24-hour contributor day, and contributing to the workshops initiative <a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">currently being discussed</a>. Matt Mullenweg’s State of the Word (which typically accompanies WordCamp US) is likely to take place in a different format later in 2020.</p>



<h2>Plugin and theme updates are now available over zip files</h2>



<p>After eleven years, WordPress now allows users to update plugins and themes by <a href=\"https://core.trac.wordpress.org/changeset/48390\">uploading a ZIP file, in WordPress 5.5</a>.&nbsp; The feature, which was merged on July 7, has been one of the most requested features in WordPress. Now, when a user tries to upload a plugin or theme zip file from the WordPress dashboard by clicking the “Install Now” button, WordPress will direct users to a new screen that compares the currently-installed extension with the uploaded versions. Users can then choose between continuing with the installation or canceling. WordPress 5.5 will also offer <a href=\"https://make.wordpress.org/core/tag/feature-autoupdates/\">automatic plugin and theme updates</a>.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The <a href=\"https://make.wordpress.org/plugins/2020/07/22/proposed-block-directory-guidelines/\">Block directory</a> is coming to WordPress with the 5.5 release. Plugin authors can now <a href=\"https://make.wordpress.org/plugins/2020/07/11/you-can-now-add-your-own-plugins-to-the-block-directory/\">submit their Block plugins to the directory</a>.</li><li>The Core team has opened up the <a href=\"https://make.wordpress.org/core/2020/07/31/wordpress-5-6-whats-on-your-wishlist/\">call for features</a> in the WordPress 5.6 release. You can <a href=\"https://make.wordpress.org/core/2020/07/31/wordpress-5-6-whats-on-your-wishlist/\">comment on the post</a> with features that you’d like to be included, current UX pain points, or maintenance tickets that need to be addressed. August 20 is the deadline for feature requests. </li><li>Editor features such as the new Navigation block, the navigation screen, and the widget screen that were originally <a href=\"https://make.wordpress.org/updates/2020/03/06/update-progress-on-goals/\">planned to be merged with WordPress 5.5</a> have been <a href=\"https://make.wordpress.org/core/2020/07/02/editor-features-for-wordpress-5-5-update/\">pushed for the next release</a>. </li><li>The Theme team is inviting proposals on whether to allow themes to <a href=\"https://make.wordpress.org/themes/2020/07/13/proposal-allow-themes-to-add-a-top-level-admin-menu/\">place an additional top-level menu link</a> in the admin.</li><li><a href=\"https://buddypress.org/2020/07/buddypress-6-2-0-beta/\">BuddyPress 6.2 beta </a>is out in the wild, and the team will soon release the stable version. The update includes changes that will make BuddyPress fully compatible with WordPress 5.5.</li><li>WordCamp EU 2021, which was being planned as an in-person event in Porto, Portugal, <a href=\"https://europe.wordcamp.org/2021/wordcamp-europe-2021-will-be-online/\">is moving online</a>. The team is considering an in-person WordCamp EU in 2022. </li><li>The Polyglots team has prepared and finalized a <a href=\"https://make.wordpress.org/polyglots/2020/07/09/translation-editor-locale-manager-vetting-criteria-page-draft/\">Translation Editor &amp; Locale Manager Vetting Criteria</a> to provide more clarity on how global mentors assign PTE/GTE/Locale Managers and to help locale teams set their own guidelines. The document, which was finalized <a href=\"https://make.wordpress.org/polyglots/2020/07/09/translation-editor-locale-manager-vetting-criteria-page-draft/\">after a lot of discussion</a>, is now available in the <a href=\"https://make.wordpress.org/polyglots/handbook/translating/expectations/translation-editor-locale-manager-vetting-criteria/\">Polyglots handbook</a>.</li><li>Members of the Community team <a href=\"https://make.wordpress.org/community/2020/07/03/proposal-recognition-for-event-volunteers-and-attendees-in-wordpress-org-profile/\">are discussing</a> whether WordCamp volunteers, WordCamp attendees, or Meetup attendees should be awarded a WordPress.org profile badge. The ongoing discussion will be open for comments until August 13.</li><li>The <a href=\"https://make.wordpress.org/core/tag/feature-notifications/\">WP Notify project</a>, which aims to create a better way to manage and deliver notifications to the relevant audience, is on to its next steps. The team has finalized the initial requirements, and is <a href=\"https://make.wordpress.org/core/2020/07/09/wp-notify-next-steps/\">kicking off the project build</a>.</li><li>The WordPress documentation team is <a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\" target=\"_blank\">considering a ban on links to commercial websites</a> in a revision to its external linking policy. The policy change does not remove external links to commercial sites from WordPress.org and only applies to documentation sites. The idea is to protect documentation from being abused, and to prevent the WordPress project from being biased. Discussion on this post is still ongoing, and a decision has not yet been made. Feel free to<a href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\"> comment on the discussion posts</a>, if you would like to share your thoughts on the topic. </li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8755\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 5.5 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2020/07/wordpress-5-5-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Jul 2020 19:08:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8732\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:370:\"The first release candidate for WordPress 5.5 is now available! This is an important milestone in the community&#8217;s progress toward the final release of WordPress 5.5. “Release Candidate” means that the new version is ready for release, but with millions of users and thousands of plugins and themes, it’s possible something was missed. WordPress 5.5 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Jb Audras\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2970:\"
<p>The first release candidate for WordPress 5.5 is now available!</p>



<p>This is an important milestone in the community&#8217;s progress toward the final release of WordPress 5.5. </p>



<p>“Release Candidate” means that the new version is ready for release, but with millions of users and thousands of plugins and themes, it’s possible something was missed. WordPress 5.5 is slated for release&nbsp;on&nbsp;<strong>August 11, 2020</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.5 yet,&nbsp;<strong>now is the time</strong>!</p>



<p>You can test the WordPress 5.5 release candidate in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-RC1.zip\">download the release candidate here (zip)</a>.</li></ul>



<p>Thank you to all of the contributors who tested the&nbsp;Beta releases and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress.</p>



<h2>What’s in WordPress 5.5?</h2>



<p>WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;and pay special attention to the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developer notes</a>&nbsp;tag for updates on those and other changes that could affect your products.</p>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.5 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme file to 5.5. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>,&nbsp;so those can be figured out before the final release.</p>



<p>The&nbsp;WordPress 5.5 Field Guide, due very shortly, will give you a more detailed dive into the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;This release also marks the <a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">hard string freeze</a>&nbsp;point of the 5.5 release schedule.</p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">fill one on WordPress Trac</a>, where you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8732\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.5 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2020 20:56:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8719\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:313:\"WordPress 5.5 Beta 4 is now available! This software is still in development, so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version. You can test WordPress 5.5 Beta 4 in two ways: Try the WordPress Beta Tester plugin (choose the [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Baumwald\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3812:\"
<p>WordPress 5.5 Beta 4 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong>This software is still in development,</strong> so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 Beta 4 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.5-beta4.zip\">download the beta here</a> (zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors who tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\">beta 3</a> development release and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress. </p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-3/\">beta 3</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=07%2F22%2F2020..07%2F28%2F2020&amp;milestone=5.5&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">43 bugs</a> have been fixed. Here are a few changes in beta 4:</p>



<ul><li>Add <code>\"loading\"</code> as an allowed kses image attribute (see <a href=\"https://core.trac.wordpress.org/ticket/50731\">#50731</a>).</li><li>Add filter for the plugin/theme auto-update message in the Info tab of Site health (see <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/50663\">#50663</a>).</li><li><code>$_SERVER[\'SERVER_NAME\']</code> not a reliable when generating email host names (see <a href=\"https://core.trac.wordpress.org/ticket/25239\">#25239</a>)</li><li>Several backported fixes from Gutenberg are included in WordPress 5.5 Beta 4 (<a href=\"https://github.com/WordPress/gutenberg/pull/24218\">See PR #24218</a>)</li></ul>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> and pay special attention to the <a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a> for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>, where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8719\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.5 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Jul 2020 17:51:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8706\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:324:\"WordPress 5.5 Beta 3 is now available! This software is still in development,so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version. You can test WordPress 5.5 Beta 3 in two ways: Try the WordPress Beta Tester plugin (choose the “bleeding [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3876:\"
<p>WordPress 5.5 Beta 3 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong>This software is still in development,</strong>so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 Beta 3 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.5-beta3.zip\">download the beta here</a> (zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors who tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\">beta 2</a> development release and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress. </p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-2/\">beta 2</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=07%2F15%2F2020..07%2F21%2F2020&amp;milestone=5.5&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">43 bugs</a> have been fixed. Here are a few changes in beta 3:</p>



<ul><li>Plugin and theme versions are now shared in the emails when automatically updated (see <a href=\"https://core.trac.wordpress.org/ticket/50350\">#50350</a>).</li><li>REST API routes without a <code>permission_callback</code> now trigger a <code>_doing_it_wrong()</code> warning (see <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/50075\">#50075</a>).</li><li>Over 23 Gutenberg changes and updates (see <a href=\"https://github.com/WordPress/gutenberg/pull/24068\">#24068</a> and <a href=\"https://core.trac.wordpress.org/ticket/50712\">#50712</a>).</li><li>A bug with the new import and export database Dashicons has been fixed (see <a href=\"https://core.trac.wordpress.org/ticket/49913\">#49913</a>).</li></ul>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> and pay special attention to the <a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a> for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>, where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8706\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.5 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2020 17:24:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8681\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:358:\"WordPress 5.5 Beta 2 is now available! This software is still in development,&#160;so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version. You can test WordPress 5.5 beta 2 in two ways: Try the&#160;WordPress Beta Tester&#160;plugin (choose the “bleeding edge nightlies” [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4552:\"
<p id=\"block-000046ff-d8e6-40a8-9869-2dd39e50f270\"><br>WordPress 5.5 Beta 2 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong><strong>This software is still in development,</strong>&nbsp;</strong>so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 beta 2 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-beta2.zip\">download the beta here</a>&nbsp;(zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on&nbsp;<a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors that tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1/\">beta 1</a> development release and provided feedback. Testing for bugs is an important part of polishing each release and a great way to contribute to WordPress. Here are some of the changes since beta 1 to pay close attention to while testing.</p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-1/\">beta 1</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=07%2F08%2F2020..07%2F14%2F2020&amp;milestone=5.5&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">48 bugs</a> have been fixed. Here is a summary of a few changes included in beta 2:</p>



<ul><li>19 additional bugs have been fixed in the block editor (see <a href=\"https://github.com/WordPress/gutenberg/pull/23903\">#23903</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/23905\">#23905</a>).</li><li>The Dashicons icon font has been updated (see <a href=\"https://core.trac.wordpress.org/ticket/49913\">#49913</a>).</li><li>Broken widgets stemming from changes in Beta 1 have been fixed (see <a href=\"https://core.trac.wordpress.org/ticket/50609\">#50609</a>).</li><li>Query handling when counting revisions has been improved (see <a href=\"https://core.trac.wordpress.org/ticket/34560\">#34560</a>).</li><li>An alternate, expanded view was added for <code>wp_list_table</code> (see <a href=\"https://core.trac.wordpress.org/ticket/49715\">#49715</a>).</li><li>Some adjustments were made to the handling of default terms for custom taxonomies (see <a href=\"https://core.trac.wordpress.org/ticket/43517\">#43517</a>)</li></ul>



<p>Several updates have been made to the block editor. For details, see <a href=\"https://github.com/WordPress/gutenberg/pull/23903\">#23903</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/23905\">#23905</a>.</p>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;and pay special attention to the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a>&nbsp;for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help us translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>,&nbsp;where you can also find a list of&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8681\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 20 Oct 2020 04:44:00 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Fri, 02 Oct 2020 09:34:04 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20200501142607\";}","no");
INSERT INTO `wp_options` VALUES("133","_transient_timeout_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1603212242","no");
INSERT INTO `wp_options` VALUES("134","_transient_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1603169042","no");
INSERT INTO `wp_options` VALUES("135","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1603212245","no");
INSERT INTO `wp_options` VALUES("136","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: WooCommerce Tests New Instagram Shopping Checkout Feature, Now in Closed Beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106398\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/woocommerce-tests-new-instagram-shopping-checkout-feature-now-in-closed-beta?utm_source=rss&utm_medium=rss&utm_campaign=woocommerce-tests-new-instagram-shopping-checkout-feature-now-in-closed-beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2878:\"<p>Instagram&rsquo;s checkout feature, which allows users to purchase products without leaving the app, has become an even more important part of Facebook&rsquo;s long-term investment in e-commerce now that the pandemic has so heavily skewed consumer behavior towards online shopping. When Instagram <a href=\"https://business.instagram.com/blog/new-to-instagram-shopping-checkout\">introduced</a> checkout in 2019, it reported that 130 million users were tapping to reveal product tags in shopping posts every month.</p>



<img />image credit: Instagram



<p>Business owners who operate an existing store can extend their audience to Instagram by funneling orders from the social network into their own stores, without shoppers having to leave Instagram. Checkout supports integration with several e-commerce platform partners, including Shopify and BigCommerce, and will soon be available for WooCommerce merchants.</p>



<p>WooCommerce is testing a new Instagram Shopping Checkout feature for its <a href=\"https://woocommerce.com/products/facebook/\">Facebook for WooCommerce</a> plugin. The free extension is used on more than 900,000 websites and will provide the bridge for store owners who want to tap into Instagram&rsquo;s market. The checkout capabilities are currently in closed beta. Anyone interested to test the feature can <a href=\"https://docs.google.com/forms/d/e/1FAIpQLSfHwcCJf1UYi_7PGmFSXJXPfhdM8rkVlXAKub1qD5EBT9dFWw/viewform\">sign up</a> for consideration. Businesses registered in the USA that meet certain other requirements may be selected to participate, and the beta is also expanding to other regions soon.</p>



<p>WooCommerce currently supports <a href=\"https://woocommerce.com/posts/instagram-shopping/\">shoppable posts</a>, which are essentially products sourced from a product catalog created on Facebook that are then linked to the live store through an Instagram business account. Instagram&rsquo;s checkout takes it one step further to provide a native checkout experience inside the app. Merchants pay no selling fees&nbsp;until December 31, 2020. After that time, the fee is <a href=\"https://www.facebook.com/business/help/223030991929920?id=533228987210412\">5% per shipment</a> or a flat fee of $0.40 for shipments of $8.00 or less.&nbsp;</p>



<p>On the customer side, shoppers only have to enter their information once and thereafter it is stored for future Instagram purchases. Instagram also pushes shipment and delivery notifications inside the app. Store owners will need to weigh whether the convenience of the in-app checkout experience is worth forking over 5% to Facebook, or if they prefer funneling users over to the live store instead.</p>



<p>Instagram Shopping Checkout is coming to WooCommerce in the near future but the company has not yet announced a launch date, as the feature is just now entering closed beta. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Oct 2020 04:13:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Past Twenty* WordPress Themes To Get New Block Patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106396\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:173:\"https://wptavern.com/past-twenty-wordpress-themes-to-get-new-block-patterns?utm_source=rss&utm_medium=rss&utm_campaign=past-twenty-wordpress-themes-to-get-new-block-patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6608:\"<p class=\"has-drop-cap\">Mel Choyce-Dwan, the Default Theme Design Lead for WordPress 5.6, kick-started 10 tickets around two months ago that would bring new features to the old default WordPress themes. The proposal is to add unique block patterns, a feature added to WordPress 5.5, to all of the previous 10 Twenty* themes. It is a lofty goal that could breathe some new life into old work from the previous decade.</p>



<p>Currently, only the last four themes are marked for an update by the time WordPress 5.6 lands. Previous themes are on the list to receive their block patterns in a future release. For developers and designers interested in getting involved, the following is a list of the Trac tickets for each theme:</p>



<ul><li><a href=\"https://core.trac.wordpress.org/ticket/51098\">Twenty Twenty</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51099\">Twenty Nineteen</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51100\">Twenty Seventeen</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51101\">Twenty Sixteen</a> &ndash; 5.6</li><li><a href=\"https://core.trac.wordpress.org/ticket/51102\">Twenty Fifteen</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51103\">Twenty Fourteen</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51104\">Twenty Thirteen</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51105\">Twenty Twelve</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51106\">Twenty Eleven</a> &ndash; Future release</li><li><a href=\"https://core.trac.wordpress.org/ticket/51107\">Twenty Ten</a> &ndash; Future release</li></ul>



<p>If you are wondering where Twenty Eighteen is in that list, that theme does not actually exist. It is the one missing year the WordPress community has had since the one-default-theme-per-year era began with Twenty Ten. It is easy to forget that we did not get a new theme for the 2017-2018 season. With all that has happened in the world this year, we should count ourselves fortunate to see a <a href=\"https://wptavern.com/first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme\">new default theme land for WordPress</a> this December. WordPress updates and its upcoming default theme are at least one consistency that we have had in an otherwise chaotic time.</p>



<p>More than anything, it is nice to see some work going toward older themes &mdash; not just in terms of bug fixes but feature updates. The older defaults are still a part of the face of WordPress. Twenty Twenty and Twenty Seventeen each have over one million active installs. Twenty Nineteen has over half a million. The other default themes also have significant user bases in the hundreds of thousands &mdash; still some of the most-used themes in the directory. We owe it to those themes&rsquo; users to keep them fresh, at least as long as they maintain such levels of popularity.</p>



<p>This is where the massive theme development community could pitch in. Do some testing of the existing patches. Write some code for missing patterns or introduce new ideas. This is the sort of low-hanging fruit that almost anyone could take some time to help with.</p>



<h2>First Look at the New Patterns</h2>



<p class=\"has-drop-cap\">None of the proposed patterns have landed in trunk, the development version of WordPress, yet. However, several people have created mockups or added patches that could be committed soon.</p>



<p>One of my favorite patterns to emerge thus far is from Beatriz Fialho for the Twenty Nineteen theme. Fialho has created many of the pattern designs proposed thus far, but this one, in particular, stands out the most. It is a simple two-column, two-row pattern with a circular image, heading, and paragraph for each section. Its simplicity fits in well with the more elegant, business-friendly look of the Twenty Nineteen theme.</p>



<img />Services pattern for Twenty Nineteen.



<p>It is also fitting that Twenty Nineteen get a nice refresh with new patterns because it was the default theme to launch with the block editor. Ideally, it would continually be updated to showcase block-related features.</p>



<p>While many people will focus on some of the more recent default themes, perhaps the most interesting one is a bit more dated. Twenty Thirteen was meant to showcase the new post formats feature in WordPress 3.6. According to Joen Asmussen, the theme&rsquo;s primary designer, the original idea was for users to compose a ribbon of alternating colors as each post varied its colors.</p>



<p>&ldquo;The alternating ribbon of colors did not really come to pass because post formats were simply not used enough to create an interesting ribbon,&rdquo; he wrote in the Twenty Thirteen ticket. &ldquo;However, perhaps for block patterns, we have an opportunity to revisit those alternating ribbons of colors. In other words, I&rsquo;d love to see those warm bold colors used in big swathes that take up the whole pattern background.&rdquo;</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>Patterns designed to match post formats.



<p>This could be a fun update for end-users who are still using <s>that feature that shall not be named</s> post formats.</p>



<p>There is a lot to like about many of the pattern mockups so far. I look forward to seeing what lands along with WordPress 5.6 and in future updates.</p>



<h2>Establishing Pattern Category Standard</h2>



<p class=\"has-drop-cap\">With the more recent Twenty Twenty-One theme&rsquo;s block patterns and the new patterns being added to some of the older default themes, it looks like a specific pattern category naming scheme is starting to become a standard. Of the patches thus far, each is creating a new pattern category named after the theme itself.</p>



<p>This makes sense. Allowing users to find all of their theme&rsquo;s patterns in one location means that they can differentiate between them and those from core or other plugins. Third-party theme authors should follow suit and stick with this convention for the same reason.</p>



<p>Developers can also define multiple categories for a single pattern. This allows theme authors to create a category that houses all of their patterns in one location. However, they can also split them into more appropriate context-specific categories for discoverability.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 19 Oct 2020 21:13:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: Using the Web Stories for WordPress Plugin? You Better Play By Google’s Rules\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105848\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://wptavern.com/using-the-web-stories-for-wordpress-plugin-you-better-play-by-googles-rules?utm_source=rss&utm_medium=rss&utm_campaign=using-the-web-stories-for-wordpress-plugin-you-better-play-by-googles-rules\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4080:\"<img />Web Stories dashboard screen in WordPress.



<p class=\"has-drop-cap\">What comes as a surprise to few, Google has updated its <a href=\"https://developers.google.com/search/docs/guides/web-stories-content-policy\">content guidelines</a> for its Web Stories format. For users of its recently-released <a href=\"https://wordpress.org/plugins/web-stories/\">Web Stories for WordPress</a> plugin, they will want to follow the extended rules for their Stories to appear in the &ldquo;richer experiences&rdquo; across Google&rsquo;s services. This includes the grid view on Search, Google Images, and Google Discover&rsquo;s carousel.</p>



<p>Google <a href=\"https://wptavern.com/google-officially-releases-its-web-stories-for-wordpress-plugin\">released its Web Stories plugin</a> in late September to the WordPress community. It is a drag-and-drop editor that allows end-users to create custom Stories from a custom screen in their WordPress admin.</p>



<div class=\"wp-block-image\"><img />Visual Stories on Search.</div>



<p>The plugin does not directly link to Google&rsquo;s content guidelines anywhere. For users who do not do a little digging, they may be caught unaware if their stories are not surfaced in various Google services.</p>



<p>On top of the Discover and Webmaster guidelines, Web Stories have six additional restrictions related to the following:</p>



<ul><li>Copyrighted content</li><li>Text-heavy Web Stories</li><li>Low-quality assets</li><li>Lack of narrative</li><li>Incomplete stories</li><li>Overly commercial</li></ul>



<p>While not using copyrighted content is one of those reasonably-obvious guidelines, the others could trip up some users. Because Stories are meant to represent bite-sized bits of information on each page, they may become ineligible if most pages have more than 180 words of text. Videos should also be limited to fewer than 60 seconds on each page.</p>



<p>Low-quality media could be a flag for Stories too. Google&rsquo;s guidelines point toward &ldquo;stretched out or pixelated&rdquo; media that negatively impacts the reader&rsquo;s experience. They do not offer any specific resolution guidelines, but this should mostly be a non-issue today. The opposite issue is far more likely &mdash; users uploading media that is too large and not optimized for viewing on the web.</p>



<p>The &ldquo;lack of narrative&rdquo; guideline is perhaps the vaguest, and it is unclear how Google will monitor or police <em>narrative</em>. However, the Stories format is about storytelling.</p>



<p>&ldquo;Stories are the key here imo,&rdquo; wrote Jamie Marsland, founder of Pootlepress, in a <a href=\"https://twitter.com/pootlepress/status/1309020235102597122\">Twitter thread</a>. &ldquo;Now we have an open format to tell Stories, and we have an open platform (WordPress) where those Stories can be told easily.&rdquo;</p>



<p>Google specifically states that Stories need a &ldquo;binding theme or narrative structure&rdquo; from one page to the next. Essentially, the company is telling users to use the format for the purpose it was created for. They also do not want users to create incomplete stories where readers must click a link to finish the Story or get information.</p>



<img /><a href=\"https://www.cnn.com/ampstories/entertainment/john-lennon-remembering-the-great-musician\">CNN&rsquo;s Web Story on Remembering John Lennon.</a>



<p>Overly commercial Stories are frowned upon too. While Google will allow affiliate marketing links, they should be restricted to a minor part of the experience.</p>



<p>Closing his Twitter thread, Marsland seemed to hit the point. &ldquo;I&rsquo;ve seen some initial Google Web Stories where the platform is being used as a replacement for a brochure or website,&rdquo; he wrote. &ldquo;In my view that&rsquo;s a huge missed opportunity. If I was advising brands I would say &lsquo;Tell Stories&rsquo; this is a platform for Story Telling.&rdquo;</p>



<p>If users of the plugin follow this advice, their Stories should surface on Google&rsquo;s rich search experiences.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Oct 2020 20:51:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"WPTavern: Stripe Acquires Paystack for $200M+\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106269\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"https://wptavern.com/stripe-acquires-paystack-for-200m?utm_source=rss&utm_medium=rss&utm_campaign=stripe-acquires-paystack-for-200m\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3196:\"<p>The big news in the world of e-commerce today is Stripe&rsquo;s acquisition of <a href=\"https://paystack.com/\">Paystack</a>, a Nigeria-based payments system that is widely used throughout African markets. The company, which became informally known as &ldquo;<a href=\"https://techcrunch.com/2018/08/28/paystack-with-ambitions-to-become-the-stripe-of-africa-raises-8m-from-visa-tencent-and-stripe-itself/\">the Stripe of Africa</a>&rdquo; picked up $8 million in Series A funding in 2018, led by Stripe, Y Combinator, and Tencent. Paystack has grown to power more than 60,000 businesses, including FedEx, UPS, MTN, the Lagos Internal Revenue Service, and AXA Mansar.</p>



<p>Stripe&rsquo;s acquisition of the company is rumored to be more than $200M, a small price to pay for a foothold in emerging African markets. In the company&rsquo;s <a href=\"https://stripe.com/newsroom/news/paystack-joining-stripe\">announcement</a>, Stripe noted that African online commerce is growing 21% year-over-year, 75% faster than the global average. Paystack dominates among payment systems, accounting for more than half of all online transactions in Nigeria.  </p>



<p>&ldquo;In just five years, Paystack has done what many companies could not achieve in decades,&rdquo; Stripe EMEA business lead Matt Henderson said. &ldquo;Their tech-first approach, values, and ambition greatly align with our own. This acquisition will give Paystack resources to develop new products, support more businesses and consolidate the hyper-fragmented African payments market.&rdquo;</p>



<p>Long term, Stripe plans to embed Paystack&rsquo;s capabilities in its Global Payments and Treasury Network (GPTN), the company&rsquo;s programmable infrastructure for global money movement.</p>



<p>&ldquo;Paystack merchants and partners can look forward to more payment channels, more tools, accelerated geographic expansion, and deeper integrations with global platforms,&rdquo; Paystack CEO and co-founder Shola Akinlade said. He also assured customers that there&rsquo;s no need to make any changes to their technical integrations, as Paystack will continue expanding and operating independently in Africa.</p>



<p>Paystack is used as a payment gateway for thousands of WordPress-powered stores through plugins for WooCommerce, Easy Digital Downloads, Paid Membership Pro, Give, Contact Form 7, and an assortment of booking plugins. The company has an official WordPress plugin, <a href=\"https://wordpress.org/plugins/payment-forms-for-paystack/\">Payment Forms for Paystack</a>, which is active on more than 6,000 sites, but most users come through the <a href=\"https://wordpress.org/plugins/woo-paystack/\">Paystack WooCommerce Payment Gateway</a> (20,000+ active installations). </p>



<p>Stripe&rsquo;s acquisition was a bit of positive news during what is currently a turbulent time in Nigeria, as citizens are actively engaged in peaceful protests to end police brutality. Paystack&rsquo;s journey is an encouraging example of the flourishing Nigerian tech ecosystem and the possibilities available for smaller e-commerce companies that are solving problems and removing barriers for businesses in emerging markets. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Oct 2020 22:26:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"WPTavern: Diving Into the Book Review Block Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106273\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:145:\"https://wptavern.com/diving-into-the-book-review-block-plugin?utm_source=rss&utm_medium=rss&utm_campaign=diving-into-the-book-review-block-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6791:\"<p class=\"has-drop-cap\">Created by Donna Peplinskie, a Product Wrangler at Automattic, the <a href=\"https://wordpress.org/plugins/book-review-block\">Book Review Block</a> plugin is nearly three years old. However, it only came to my attention during a recent excursion to find interesting block plugins.</p>



<p>The plugin does pretty much what it says on the cover. It is designed to review books. It generally has all the fields users might need to add to their reviews, such as a title, author, image, rating, and more. The interesting thing is that it can automatically fill in those details with a simple ISBN value. Plus, it supports Schema markup, which may help with SEO.</p>



<p>Rain or shine, sick or well, I read every day. I am currently a month and a half shy of a two-year reading streak. When the mood strikes, I even venture to write a book review. As much as I want to share interesting WordPress projects with the community, I sometimes have personal motives for testing and writing about plugins like Book Review Block. Anything that might help me or other avid readers share our thoughts on the world of literature with others is of interest.</p>



<p>Admittedly, I was excited as I plugged in the ISBN for <em>Rhthym of War</em>, the upcoming fourth book of my favorite fantasy series of all time, <em>The Stormlight Archive</em>. I merely needed to click the &ldquo;Get Book Details&rdquo; button.</p>



<p>Success! The plugin worked its magic and pulled in the necessary information. It had my favorite author&rsquo;s name, the publisher, the upcoming release date, and the page count. It even had a long description, which I could trim down in the editor.</p>



<img />Default output of the Book Review block.



<p>There was a little work to make this happen before the success. To automatically pull in the book details, end-users must have an <a href=\"https://console.developers.google.com/flows/enableapi?apiid=books.googleapis.com&keyType=CLIENT_SIDE&reusekey=true\">API Key</a> from Google. It took me around a minute to set that up and enter it into the field available in the block options sidebar. The great thing about the plugin is that it saves this key so that users do not have to enter each time they want to review a book.</p>



<p>Book Review Block a good starting point. It is straightforward and simple to use. It is not yet at a point where I would call it a <em>great</em> plugin. However, it could be.</p>



<h2>Falling Short</h2>



<p class=\"has-drop-cap\">The plugin&rsquo;s Book Review block should be taking its cues from the core Media &amp; Text block. When you get right down to it, the two are essentially doing the same thing visually. Both are blocks with an image and some content sitting next to each other.</p>



<p>The following is a list of items where it should be following core&rsquo;s lead:</p>



<ul><li>No way to edit alt text (book title is automatically used).</li><li>The image is always aligned left and the content to the right with no way to flip them.</li><li>The media and content are not stackable on mobile views.</li><li>Cannot adjust the size of the image or content columns.</li><li>While inline rich-text controls are supported, users cannot add Heading, List, or Paragraph blocks to the content area and use their associated block options.</li></ul>



<p>That is the shortlist that could offer some quick improvements to the user experience. Ultimately, the problems with the plugin essentially come down to not offering a way to customize the output.</p>



<p>One of the other consistent problems is that the book image the plugin loads is always a bit small. This seems to be more of an issue from the Google Books API than the plugin. Each time I tested a book, I opted to add a larger image &mdash; the plugin does allow you to replace the default.</p>



<p>The color settings are limited. The block only offers a background color option with no way to adjust the text color. A better option for plugin users is to wrap it in a Group block and adjust the background and text colors there.</p>



<img />Book Review block wrapped inside a Group block.



<p>It would also be nice to have wide and full-alignment options, which is an often-overlooked featured from many block plugin authors.</p>



<h2>Using the Media &amp; Text Block to Recreate the Book Review Block</h2>



<p class=\"has-drop-cap\">The Book Review Block plugin has a lot of potential, and I want to see it evolve by providing more flexibility to end-users. Because the Media &amp; Text block is the closest core block to what the plugin offers, I decided to recreate a more visually-appealing design with it.</p>



<img />Book review section created with the Media &amp; Text block.



<p>I made some adjustments on the content side of things. I used the Heading block for the book title, a List block for the book metadata, and a Paragraph block for the description.</p>



<p>The Media &amp; Text block also provided me the freedom to adjust the alignment, stack the image and content on mobile views, and tinker with the size of the image. Plus, it has that all-important field for customizing the image alt attribute.</p>



<p>The Media &amp; Text block gave me much more design mileage.</p>



<p>However, there are limitations to the core block. It does not fully capture some of the features available via the Book Review block. The most obvious are the automatic book details via an ISBN and the Schema markup. Less obvious, there is no easy way to recreate the star rating &mdash; I used emoji stars &mdash; and long description text does not wrap under the image. To recreate that, you would have to opt to use a left-aligned image followed by content.</p>



<p>Overall, the Media &amp; Text block gives me the ability to better style the output, which is what I am more interested in as a user. I want to put my unique spin on things. That is where the Book Review Plugin misfires. It is also the sort of thing that the plugin author can iterate on, offering more flexibility in the future.</p>



<p>This is where many block plugins go wrong, particularly when there is more than one or two bits of data users should enter. Blocks represent freedom in many ways. However, when plugin developers stick to a rigid structure, users can sometimes lose that sense of freedom that they would otherwise have with building their pages.</p>



<p>One of the best blocks, hands down, that preserves that freedom is from the <a href=\"https://wptavern.com/start-a-recipe-blog-with-the-recipe-block-wordpress-plugin\">Recipe Block plugin</a>. It has structured inputs and fields. However, it allows freeform content for end-users to make it their own.</p>



<p>When block authors push beyond this rigidness, users win.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Oct 2020 20:44:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: WooCommerce 4.6 Makes New Home Screen the Default for New and Existing Stores\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106242\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:219:\"https://wptavern.com/woocommerce-4-6-makes-new-home-screen-the-default-for-new-and-existing-stores?utm_source=rss&utm_medium=rss&utm_campaign=woocommerce-4-6-makes-new-home-screen-the-default-for-new-and-existing-stores\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3018:\"<p><a href=\"https://developer.woocommerce.com/2020/10/14/woocommerce-4-6-is-now-available/\">WooCommerce 4.6</a> was released today. The minor release dropped during <a href=\"https://woosesh.com/\">WooSesh</a>, a global, virtual conference dedicated to WooCommerce and e-commerce topics. It features the new home screen as the default for all stores. Previously, the screen was only the default on new stores. Existing store owners had to turn the feature on in the settings.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The updated home screen, originally introduced in version 4.3, helps store admins see activity across the site at a glance and includes an inbox, quick access to store management links, and an overview of stats on sales, orders, and visitors. This redesigned virtual command center arrives not a moment too soon, as anything that makes order management more efficient is a welcome improvement, due to the sheer volume of sales increases that store owners have seen over the past eight months.</p>



<p>In stark contrast to industries like hospitality and entertainment that have proven to be more vulnerable during the pandemic, e-commerce has seen explosive growth. During the State of the Woo address at WooSesh 2020, the WooCommerce team shared that e-commerce is currently estimated to be a $4 trillion market that will grow to $4.5 trillion by 2021. WooCommerce accounts for a sizable chunk of that market with an estimated total payment volume for 2020 projected to reach $20.6 billion, a 74% increase compared to 2019.</p>



<p>The WooCommerce community is on the forefront of that growth and is deeply invested in the products that are driving stores&rsquo; success. The WooCommerce team shared that 75% of people who build extensions also build and maintain stores for merchants, and 70% of those who build stores for merchants also build and maintain extensions or plugins. In 2021, they plan to invest heavily in unlocking more features in more countries and will make WooCommerce Payments the native payment method for the global platform.</p>



<p>A new report from eMarketer shows that <a href=\"https://www.emarketer.com/content/us-ecommerce-growth-jumps-more-than-30-accelerating-online-shopping-shift-by-nearly-2-years\">US e-commerce growth has jumped 32.4%</a>, accelerating the online shopping shift by nearly two years. Experts also predict the top 10 e-commerce players will swallow up more of US retail spending to account for 63.2% of all online sales this year, up from 57.9% in 2019. </p>



<p>The increase in e-commerce spending may not be entirely tied to the pandemic, as some experts believe this historic time will mark permanent changes in consumer spending habits. This is where independent stores, powered by WooCommerce and other technologies, have the opportunity to establish a strong reputation for themselves by providing quality products and reliable service, as well as by being more nimble in the face of pandemic-driven increases in volume.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 15 Oct 2020 03:48:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WPTavern: The Future of Starter Content: WordPress Themes Need a Modern Onboarding and Importing Tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106177\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:245:\"https://wptavern.com/the-future-of-starter-content-wordpress-themes-need-a-modern-onboarding-and-importing-tool?utm_source=rss&utm_medium=rss&utm_campaign=the-future-of-starter-content-wordpress-themes-need-a-modern-onboarding-and-importing-tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7385:\"<img />Image credit: <a href=\"https://www.pexels.com/photo/notebook-beside-the-iphone-on-table-196644/\">picjumbo.com on Pexels</a>.



<p class=\"has-drop-cap\">Starter content. It was a grand idea, one of those big dreams of WordPress. It was the <a href=\"https://make.wordpress.org/core/2016/11/30/starter-content-for-themes-in-4-7/\">new kid on the block in late 2016</a>. Like the introduction of post formats in 2011, the developer community was <em>all in</em> for at least that particular release version. Then, it was on to the next new thing, with the feature dropping off the radar for all but the most ardent evangelists. </p>



<p>Some of us were burned over the years, living and dying by the progress of features that we wanted most.</p>



<p>Released in WordPress 4.7, starter content has since seemed to be going the way of post formats. After four years, only <a href=\"https://wpdirectory.net/search/01EMM14PBRE6K8P1Z08KXQQ76D\">141 themes</a> in the WordPress theme directory support the feature. There has been no movement to push it beyond its initial implementation. And, it never <em>really</em> covered the things that theme authors wanted in the first place. It was a start. But, themers were ultimately left to their own devices, rolling custom solutions for something that never panned out &mdash; fully-featured demo and imported content. Four years is an eternity in the web development world, and there is no sense in waiting around to see if WordPress would push forward.</p>



<p>Until Helen Hou-Sand&iacute; published <a href=\"https://make.wordpress.org/core/2020/10/06/revisiting-starter-content-on-org-and-beyond/\">Revisiting Starter Content</a> last week, most would have likely assumed the feature would be relegated to legacy code used by old-school fans of the feature and those theme authors who consider themselves completionists.</p>



<p>&ldquo;Starter content in 4.7 was always meant to be a step one, not the end goal or even the resting point it&rsquo;s become,&rdquo; wrote Hou-Sand&iacute;. &ldquo;There are still two major things that need to be done: themes should have a unified way of showing users how best to put that theme to use in both the individual site and broader preview contexts, and sites with existing content should also be able to take advantage of these sort of &lsquo;ideal content&rsquo; definitions.&rdquo;</p>



<p>Step two should have been this <a href=\"https://core.trac.wordpress.org/ticket/38624\">four-year-old accompanying ticket</a> to allow users to import starter content into existing, non-<em>fresh</em> sites.</p>



<p>Since the initial feature dropped, the theme landscape has changed. Let&rsquo;s face it. WordPress might simply not be able to compete with theme companies that are pushing the limits, creating experiences that users want at much swifter speeds.</p>



<p>Look at where the Brainstorm Force&rsquo;s <a href=\"https://wordpress.org/plugins/astra-sites/\">Starter Templates</a> plugin for its <a href=\"https://wordpress.org/themes/astra/\">Astra</a> theme is now. Users can click a button and import a full suite of content-filled pages or even individual templates. And, the Astra theme is not alone in this. It has become an increasingly-common standard to offer some sort of onboarding to users. GoDaddy&rsquo;s managed WordPress service <a href=\"https://wptavern.com/inside-look-at-godaddys-onboarding-process-for-managed-wordpress-hosting\">fills a similar need</a> on the hosting end.</p>



<img />Astra&rsquo;s starter templates and content.



<p>As WordPress use becomes more widespread, the more it needs a way to onboard users.</p>



<p>This essentially boils down to the question: <em>how can I make it look like the demo?</em></p>



<p>Ah, the age-old question that theme authors have been trying to solve. Whether it has been limitations in the software or, perhaps, antiquated theme review guidelines related to demo and imported content, this has been a hurdle that has been tough to jump. But, some have sailed over it and moved on. While WordPress has seemingly been twiddling its thumbs for years, Brainstorm Force and other theme companies have solved this and continued to innovate.</p>



<p>This is not necessarily a bad thing. There are plenty of ideas to <s>steal</s> copy and pull into the core platform.</p>



<p>One of the other problems facing the WordPress starter content feature is that it is tied to the customizer. With the direction of the block system, it is easy to ask what the future holds. The customizer &mdash; originally named the <em><strong>theme</strong></em> customizer &mdash; was essentially a project to allow users to make front-end adjustments and watch those customizations happen in real time. However, new features like global styles and full-site editing are happening on their own admin screens. Most theme options will ultimately be relegated to global styles, custom templates, block styles, and block patterns. There may not be much left for the customizer to do.</p>



<p>Right now, there are too many places in WordPress to edit the front-end bits of a WordPress site. My hope is that all of these things are ultimately merged into one less-confusing interface. But, I digress&hellip;</p>



<p>Starter content should be rethought. Whoever takes the reins on this needs a fresh take that adopts modern methods from leading theme companies.</p>



<p>The ultimate goal should be to allow theme authors to create multiple sets of templates/content that end-users can preview and import. It should not be tied to whether it is a new site. Any site owner should be able to import content and have it <em>automagically</em> go live. It should also be extendable to allow themes to support page builders like Elementor, Beaver Builder, and many others.</p>



<p>This seems to be in line with Hou-Sand&iacute;&rsquo;s thoughts. &ldquo;For a future release, we should start exploring what it might look like to opt into importing starter content into existing sites, whether wholesale or piecewise,&rdquo; she wrote. &ldquo;Many of us who work in the WordPress development/consulting space tend not to ever deal in switching between public themes on our sites, but let&rsquo;s not forget that&rsquo;s a significant portion of our user audience and we want to continue to enable them to not just publish but also publish in a way that matches their vision.&rdquo;</p>



<p>Let&rsquo;s do it right this go-round, keep a broad vision, and provide an avenue for theme authors to adopt a standardized core WordPress method instead of having everyone build in-house solutions.</p>



<p>I haven&rsquo;t even touched on the <a href=\"https://meta.trac.wordpress.org/ticket/30#comment:66\">recent call to use starter content</a> for WordPress.org theme previews. It will take more than ideas to excite many theme authors about the possibility. That ticket has sat for seven years with no progress, and most have had it on their wish list for much longer. It is an interesting proposal, one that has been tossed around in various team meetings for years.</p>



<p>Like so many other things, theme authors have either given up hope or moved onto doing their own thing. They need to be brought into the fold, not only as third parties who are building with core WordPress tools but as developers who are contributing to those features.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 14 Oct 2020 20:07:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"WPTavern: Google Podcasts Manager Adds More Data from Search: Impressions, Top-Discovered Episodes, and Search Terms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106191\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:271:\"https://wptavern.com/google-podcasts-manager-adds-more-data-from-search-impressions-top-discovered-episodes-and-search-terms?utm_source=rss&utm_medium=rss&utm_campaign=google-podcasts-manager-adds-more-data-from-search-impressions-top-discovered-episodes-and-search-terms\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2568:\"<p>Google <a href=\"https://twitter.com/googlewmc/status/1316030688508825600\">announced</a> an expansion of listener engagement metrics today for those using its Podcast Manager. Previously, audience insights included data about the types of devices listeners are using, where listeners tune in and drop off during a given episode, total number of listens, and listening duration, but the service lacked analytics regarding how visitors were discovering the podcast.</p>



<p>Google is remedying that today by expanding the dashboard to show impressions, clicks, top-discovered episodes, and search terms that brought listeners to the podcast. This information can help podcasters understand how their content is getting discovered so they can better tailor their episodes to attract more new listeners. </p>



<p>The podcasting industry has seen remarkable growth over the past five years, which previously led experts to project that marketers will spend&nbsp;<a href=\"https://www.searchenginejournal.com/marketers-will-spend-1-billion-on-podcast-advertising-by-2021-report/316499/#close\">over $1 billion in advertising by 2021</a>. After the pandemic hit, podcast listening took a downturn in the U.S. but at the same time, podcast creators have found more time to <a href=\"https://wptavern.com/podcasting-during-the-pandemic-castos-sees-300-growth-in-new-podcasters\">create new shows and episodes</a>. Businesses are turning to the medium to supplement traditional marketing methods that no longer have the same impact now that consumer spending habits heavily favor online products.</p>



<p>Along with the new metrics available inside Google Podcasts Manager, the company also published a <a href=\"https://support.google.com/podcast-publishers/thread/76595315\">guide to optimizing podcasts</a> for Google Search. It highlights four important items for making sure a podcast can be found:</p>



<ul><li>Detailed show and episode metadata</li><li>Ensure the podcast&rsquo;s webpage and RSS data match</li><li>Include cover art</li><li>Ensure Googlebot can access your audio files </li></ul>



<p>A detailed breakdown of your audience&rsquo;s listening habits isn&rsquo;t worth much if you&rsquo;re having trouble getting your podcast discovered. Any podcasting plugin for WordPress should handle these basic optimization recommendations, but if you are still having trouble being found via Google, you can dig deeper into the <a href=\"https://support.google.com/podcast-publishers/answer/9889864\">podcast setup guide</a> for more detailed recommendations. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Oct 2020 22:57:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Are Block-Based Widgets Ready To Land in WordPress 5.6?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106175\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:173:\"https://wptavern.com/are-block-based-widgets-ready-to-land-in-wordpress-5-6?utm_source=rss&utm_medium=rss&utm_campaign=are-block-based-widgets-ready-to-land-in-wordpress-5-6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8214:\"<p class=\"has-drop-cap\">Two weeks ago, the Gutenberg team put out an <a href=\"https://make.wordpress.org/core/2020/09/30/call-for-testing-the-widgets-screen-in-gutenberg-9-1/\">open call for block-based widgets feedback</a>. I had already written a <a href=\"https://wptavern.com/gutenberg-8-9-brings-block-based-widgets-out-of-the-experimental-stage\">lengthy review</a> of the new system earlier in September but was asked by a member of the team to share my thoughts on the most recent iteration. With the upcoming freeze for WordPress 5.6 Beta 1 just a week away, I figured it would not hurt to do another deep dive.</p>



<p>For reference, my latest testing is against version 9.2.0-alpha-172f589 of the Gutenberg plugin, which was a build from earlier today. Gutenberg development moves fast, but everything should be accurate to that point.</p>



<p>Ultimately, many of the problems I pointed out over a month ago still exist. However, the team has cleaned most of the minor issues, such as pointing the open/close arrows for sidebars (block areas) in the correct direction and making it more consistent with the post-editing screen. The UI is much more polished.</p>



<p>Before I dive into all the problems, I want to answer the question I am proposing. Yes, the block-based widget system <em>will be</em> ready for prime time when WordPress 5.6 lands. It is not there yet, but it is at a point where there is a clear finish line that is reachable in the next two months.</p>



<p>I will ignore the failure of block-based widgets in the customizer, which landed in Gutenberg 8.9 and was <a href=\"https://wptavern.com/gutenberg-9-1-adds-patterns-category-dropdown-and-reverts-block-based-widgets-in-the-customizer\">removed in 9.1</a>. I will also look past the recent proposal to <a href=\"https://github.com/WordPress/gutenberg/issues/26012\">reconstruct the widgets screen</a> to use the Customize API, at least for now. There is a boatload of problems that block-based widgets present for the customizer, and those problems are insurmountable for WordPress 5.6. Long term, WordPress needs to have a single place for editing widget/block areas. Users will likely have to live with some inconsistencies for a while.</p>



<p>Assuming the team does not try to throw a last-minute Hail Mary and implement full editing of blocks in the customizer this round, it is safe to say that block-based widgets are well on their way toward a successful WordPress 5.6 debut.</p>



<h2>The User Experience</h2>



<img />Block-based widgets screen.



<p class=\"has-drop-cap\">As a user, I genuinely enjoy using the new Widgets admin screen. The open-ended, free-form block areas create untold possibilities for designing my WordPress sites. Traditional widgets were limited in scope. Users were buckled down to a handful of core widgets, possibly some plugin widgets, and whatever their theme author offered up. However, with blocks, the pool of choices expands to at least triple the out-of-the-box options (I am not counting embed-type blocks individually). Plus, blocks provide a far more extensive set of design options than a traditional widget.</p>



<p>In comparison, traditional widgets are outdated. Blocks are superior in almost every way. However, there are still problems with this new system.</p>



<p>The biggest issue right now is that end-users can exit the Widgets screen without saving their changes. There is no warning to let them know that all their work is about to be lost in the ether. This is one of those <em>OMGBBQ</em>-level items that need to happen before WordPress 5.6 drops.</p>



<p>One nice-to-have-but-not-necessary feature would be the ability to drag blocks from one block area to another. In the old widgets system, users could move widgets from sidebar to sidebar. The current alternative is to copy a widget, paste it in a new block area, and remove the original.</p>



<p>I am also not a fan of not having an option for the top toolbar, which is available on the post-editing screen. One of the reasons for using this toolbar is because I dislike the default popup toolbar on individual blocks. It is distracting and often gets in the way of my work.</p>



<p>Legacy widgets seem to still be a work in progress. The Legacy Widget block did not work at all for me at times. Then, it magically began to work. However, Gutenberg does now automatically add registered third-party widgets to the block inserter just as if they were blocks.</p>



<img />Getting a plugin&rsquo;s widget to work.



<p>This presented its own problems. The only way I managed to make third-party plugin widgets work was to insert the widget, save, and refresh the widgets screen. At that point, the widgets appeared and became editable.</p>



<h2>The Theme Author Experience</h2>



<p class=\"has-drop-cap\">One of my biggest concerns for theme authors right now is that there does not seem to be any documentation in the <a href=\"https://developer.wordpress.org/block-editor/developers/themes/\">block editor handbook</a>. There is plenty of time to make that happen, but there are things theme authors need to be aware of. Having a centralized location, even while the feature is under development, would help them gear up for the 5.6 release.</p>



<p>Some of these questions, which may be answered in various Make blog posts, should exist on a dedicated documentation page:</p>



<ul><li>How can a theme opt out of block-based widgets?</li><li>What are the hooks to add custom styles for the Widgets screen?</li><li>Can themes target specific sidebar styles on the Widgets screen?</li><li>Is it possible to consistently style sections like traditional widgets on the front end?</li><li>Can themes opt into wide and full-alignment within block areas, which could essentially be used similarly to the post content area?</li></ul>



<p>These are some of the questions I would want to be answered as a former theme author. I am no longer in the thick of the theme design game and presume that those who are would have a larger list of questions.</p>



<p>One less-obvious piece of documentation should center on how to handle fallbacks or default <em>widgets</em>. Traditionally, themes that needed to show a default set of widgets would check if the sidebar has widgets and fall back to using <code>the_widget()</code> to output one or more defaults. While theme authors can still do that, we should start to transition them across the board to the block system.</p>



<p>Should theme authors copy/paste block HTML as a fallback? Would the starter content system be better for this, and can starter widget content handle blocks? What is the recommended method for widget fallbacks in WordPress 5.6?</p>



<p>There is still the <a href=\"https://github.com/WordPress/gutenberg/issues/25174\">ongoing issue</a> of how theme authors should handle the traditional widget and widget title wrapper HTML in the new block paradigm. One patch added since the Gutenberg 9.1 release <a href=\"https://github.com/WordPress/gutenberg/pull/25693\">wraps every top-level block</a> with the widget wrapper. If this lands in the 9.2 release, it will likely make the issue worse.</p>



<p>In the traditional system, both the widget title and content are wrapped within a container together. However, if a user adds a Heading block (widget title) and another block (widget content), each block is wrapped separately with the theme&rsquo;s widget wrappers. The only way to rectify the situation as it stands is for end-users to add a Group block for each &ldquo;widget&rdquo; they want, which would require an extensive amount of re-education for WordPress users. It is not an ideal scenario.</p>



<img />Each block is wrapped as an individual section.



<p>Instead of attempting to directly &ldquo;fix&rdquo; this issue, WordPress should instead do nothing to the output. Blocks and traditional widgets are fundamentally different.</p>



<p>Let theme authors take the reins on this one and explore possibilities. However, give them the tools to do so, such as <a href=\"https://wptavern.com/addressing-the-theme-design-problem-with-gutenbergs-new-block-based-widgets-system\">supporting block patterns</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Oct 2020 21:35:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: WordCamp Austin 2020 Finds Success with VR Experience for Sessions and Networking\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=106119\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:227:\"https://wptavern.com/wordcamp-austin-2020-finds-success-with-vr-experience-for-sessions-and-networking?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-austin-2020-finds-success-with-vr-experience-for-sessions-and-networking\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7246:\"<p><a href=\"https://austin.wordcamp.org/2020/\">WordCamp Austin 2020</a> attendees are raving about their experiences attending the virtual event last Friday. It was no secret that the camp&rsquo;s organizers planned to use&nbsp;<a href=\"https://hubs.mozilla.com/\">Hubs Virtual Rooms</a>&nbsp;by Mozilla to create a unique environment, but few could imagine how much more interactive and personalized the experience would be than a purely Zoom-based WordCamp.</p>



<p>After selecting a custom avatar, attendees entered the venue using a VR headset or the browser to check out sessions or network in the hallway track.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Here&rsquo;s a small taste of the experience at <a href=\"https://twitter.com/WordCampATX?ref_src=twsrc%5Etfw\">@WordCampATX</a> today. <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> logos and no sponsor banners on any elevator doors. <a href=\"https://twitter.com/hashtag/WCATX?src=hash&ref_src=twsrc%5Etfw\">#WCATX</a> <a href=\"https://t.co/Nv2p2VchXf\">pic.twitter.com/Nv2p2VchXf</a></p>&mdash; David Bisset (@dimensionmedia) <a href=\"https://twitter.com/dimensionmedia/status/1314643915904086018?ref_src=twsrc%5Etfw\">October 9, 2020</a></blockquote>
</div>



<p>Speaker and Q&amp;A sessions were broadcast through Zoom but organizers can also embed YouTube videos and streams within the standalone VR environment.</p>



<p>&ldquo;The VR experience was the most life-like WordCamp experience I&rsquo;ve had since the start of global lockdowns,&rdquo; attendee and speaker David Vogelpohl said. &ldquo;You could attend sessions in one of two virtual presentation halls depending on what track you wanted to see at that time. The speaker presented on a virtual stage and you could see the other attendees watching the presentation.&rdquo;</p>



<p>Vogelpohl said he enjoyed his experience getting to know others in the Slack and VR venue. Organizers preserved the general vibe of the &ldquo;hallway track&rdquo; to recreate what is arguably one of the most valuable aspects of in-person WordCamps.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">So cool &ndash; checking out the Virtual Space of WordCamp Austin &ndash; love the background noise of people talking, ran into <a href=\"https://twitter.com/ChrisWiegman?ref_src=twsrc%5Etfw\">@ChrisWiegman</a> and <a href=\"https://twitter.com/Josh412?ref_src=twsrc%5Etfw\">@Josh412</a> <a href=\"https://twitter.com/hashtag/WCATX?src=hash&ref_src=twsrc%5Etfw\">#WCATX</a> <a href=\"https://t.co/68EdgDN2Om\">pic.twitter.com/68EdgDN2Om</a></p>&mdash; Birgit Pauli-Haack (@bph) <a href=\"https://twitter.com/bph/status/1314570573792632832?ref_src=twsrc%5Etfw\">October 9, 2020</a></blockquote>
</div>



<p>&ldquo;In the hallway track between the virtual presentation halls was a large foyer where you could meet new people, spot a friend speaking with someone else, and virtually step aside from a group conversation to have a private conversation,&rdquo; Vogelpohl said.</p>



<p>&ldquo;It was great to see folks like Josepha circling around speaking with attendees, Josh Pollock nerding out in a corner with a group of advanced WP developers, and having random friends drop into a conversation I was having with a group of others. While VR WordCamp doesn&rsquo;t wholly&nbsp;replace the value of attending a WordCamp live, a lot of the best parts of meeting and collaborating with others was captured in the VR context.&rdquo;</p>



<p>The live music interludes, which showcased talents from around the community, also provided a way for virtual attendees to stay connected while waiting for the next session. </p>



<h2>Behind the Scenes with Anthony Burchell: Creative Director for WordCamp Austin&rsquo;s Virtual World</h2>



<p>WordPress core contributor Anthony Burchell, who started a <a href=\"https://broken.place/\">company</a> dedicated to creating interactive XR sound and art experiences, was the creative director behind the WordCamp Austin&rsquo;s VR backdrop.</p>



<p>&ldquo;For WordCamp Austin we wanted to give folks something to be excited about outside of the typical webcam and chat networking,&rdquo; Burchell said. &ldquo;I feel that virtual events are not utilizing the networking layer nearly enough to make folks feel like they are really at an event. I&rsquo;ve seen many compelling formats for virtual events utilizing webcams and chat rooms, but in the end, it feels like there&rsquo;s been a missing element of presence; something video games and virtual reality excel at.&rdquo;</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Virtual mission control for <a href=\"https://twitter.com/hashtag/WCATX?src=hash&ref_src=twsrc%5Etfw\">#WCATX</a> <a href=\"https://t.co/WyrFkIsW2Q\">pic.twitter.com/WyrFkIsW2Q</a></p>&mdash; Anthony Burchell (@antpb) <a href=\"https://twitter.com/antpb/status/1314592863569707008?ref_src=twsrc%5Etfw\">October 9, 2020</a></blockquote>
</div>



<p>Setting up the virtual world involves spinning up a self-hosted instance of Hubs Cloud, which Burchell said is very similar to the complexity of making a WordPress site.</p>



<p>&ldquo;The most time consuming part of creating a 3D world for an event is making the 3D assets for the space,&rdquo; Burchell said. &ldquo;In total I streamed 11 hours of video leading up to the event to give a glimpse into the process.&rdquo;</p>



<p>Burchell&rsquo;s YouTube <a href=\"https://www.youtube.com/playlist?list=PLi1xKbv0cklpzJCgXyKi-pp3KANYJLqGk\">playlist</a> documents the incredible amount of work that went into creating the WordCamp&rsquo;s virtual venue for attendees to enjoy. </p>



<p>&ldquo;While it took quite a bit of time to prepare, the code and assets are completely reusable for another event,&rdquo; Burchell said. &ldquo;A lot of the time was spent trying to make the space purpose built for the goals of the camp. Much like a real WordCamp, I found the majority of folks packing into the theater rooms for presentations and dipping out a little early to network with friends in the hallway area. That was very much by design!&rdquo;</p>



<p>Burchell and the other organizers were careful to ensure that the Hubs space was not the primary viewing experience of the camp but rather an extension of the networking activities that attendees could drop in on. The event had nearly identical numbers of attendees joining the virtual space as it did for those joining the video channels. At the end of the afterparty, Burchell turned on flying for all attendees to conclude the successful event:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>&ldquo;With Hubs we were able to give attendees the ability to express themselves within a venue vs within a camera and chat box,&rdquo; Burchell said. &ldquo;It was incredible to see characteristics of folks in the community shine through a virtual avatar! Just the simple act of seeing your WordCamp friends in the hallway joking and chatting just as they would at a real life event was enough to make me feel like I was transported to a real WordCamp.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 12 Oct 2020 22:31:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: Privacy-Conscious WordPress Plugin Caches and Serves Gravatar Images Locally\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105825\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/privacy-conscious-wordpress-plugin-caches-and-serves-gravatar-images-locally?utm_source=rss&utm_medium=rss&utm_campaign=privacy-conscious-wordpress-plugin-caches-and-serves-gravatar-images-locally\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5285:\"<p class=\"has-drop-cap\">Ari Stathopoulos released his new <a href=\"https://wordpress.org/plugins/local-gravatars/\">Local Gravatars</a> plugin last week. The goal of the plugin is to allow site owners to take advantage of the benefits of a global avatar system while mitigating privacy concerns by hosting the images locally.</p>



<p>In essence, it is a caching system that stores the images on the site owner&rsquo;s server. It is an idea that Peter Shaw <a href=\"https://wptavern.com/local-avatars-in-wordpress-yes-please#comment-338262\">proposed in the comments</a> on an earlier Tavern article covering <a href=\"https://wptavern.com/local-avatars-in-wordpress-yes-please\">local avatar upload</a>. It is a middle ground that may satisfy some users&rsquo; issues with how avatars currently work in WordPress.</p>



<p>&ldquo;I am one of the people that blocks analytics, uses private sessions when visiting social sites, I use DuckDuckGo instead of Google, and I don&rsquo;t like the &lsquo;implied&rsquo; consents,&rdquo; said Stathopoulos. &ldquo;I built the plugin for my own use because I don&rsquo;t know what Gravatar does, I don&rsquo;t understand the privacy policies, and I am too lazy to spend two hours analyzing them. It&rsquo;s faster for me to build something that is safe and doesn&rsquo;t leave any room for misunderstandings.&rdquo;</p>



<p>He is referring to Automattic&rsquo;s extensive <a href=\"https://automattic.com/privacy/\">Privacy Policy</a>. He said it looks benign. However, he does not like the idea of any company being able to track what sites he visits without explicit consent.</p>



<p>&ldquo;And when I visit a site that uses Gravatar, some information is exposed to the site that serves them &mdash; including my IP,&rdquo; said Stathopoulos. &ldquo;Even if it&rsquo;s just for analytics purposes, I don&rsquo;t think the company should know that page A on site B got 1,000 visitors today with these IPs from these countries. There is absolutely no reason why any company not related to the page I&rsquo;m actually visiting should have any kind of information about my visit.&rdquo;</p>



<p>The Local Gravatars plugin must still connect to the Gravatar service. However, the connection is made on the server rather than the client. Stathopoulos explained that the only information exposed in this case is the server&rsquo;s IP and nothing from the client, which eliminates any potential privacy concerns.</p>



<h2>The Latest Plugin Update</h2>



<p class=\"has-drop-cap\">Stathopoulos updated the plugin earlier today to address some performance concerns for pages that have hundreds or more Gravatar images. In the version 1.0.1 update, he added a maximum processing time of five seconds and changed the cache cleanup process from daily to weekly. Both of these are filterable via code.</p>



<p>&ldquo;Now, if there are Gravatars missing in a page request, it will get as many as it can, and, after five seconds, it will stop,&rdquo; said Stathopoulos. &ldquo;So if there are 100 Gravatars missing and it gets the first 20, the rest will be blank (can be filtered to use a fallback URL, or even fall back to the remote URL, though that would defeat the privacy improvement). The next page request will get the next 20, and so on. At some point, all will be there, and there will be no more delays.&rdquo;</p>



<p>He did point out that performance could temporarily suffer when installing it on a site that has individual posts with 1,000s of comments and a lot of traffic. However, nothing would crash on the site, and the plugin should eventually lead to a performance boost in this scenario. For such large sites, owners could use the existing filter hooks to tweak the settings.</p>



<p>Right now, the plugin is primarily an itch he wanted to scratch for his own purposes. However, if given enough usage and feedback, he may include a settings screen to allow users to control some of the currently-filterable defaults, such as the cleanup timeframe and the maximum process time allowed.</p>



<h2>The Growing List of Alternatives</h2>



<p class=\"has-drop-cap\">With growing concerns around privacy in the modern world, Local Gravatars is another tool that end-users can employ if they have any concerns around the Gravatar service. For those who are OK with an auto-generated avatar, <a href=\"https://wptavern.com/privacy-first-gravatar-replacement-pixel-avatars-module-released-for-the-toolbelt-wordpress-plugin\">Pixel Avatars</a> may be a solution.</p>



<p>&ldquo;I&rsquo;ve seen some of them, and they are wonderful!&rdquo; Stathopoulos said of alternatives for serving avatars. &ldquo;However, this plugin is slightly different in that the avatars the user already has on Gravatar.com are actually used. They can see the image they have uploaded. The user doesn&rsquo;t need to upload a separate avatar, and an automatic one is not used by default.&rdquo;</p>



<p>He would not mind using an auto-generated avatar when commenting on blogs or news sites at times. However, Stathopoulos prefers Gravatar for community-oriented sites.</p>



<p>&ldquo;My Gravatar is part of my online identity, and when I see, for example, a comment from someone on WordPress.org, I know who they are by their Gravatar,&rdquo; he said.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 12 Oct 2020 21:06:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: WordPress 5.6 to Introduce Application Passwords for REST API Authentication\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105997\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/wordpress-5-6-to-introduce-application-passwords-for-rest-api-authentication?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-6-to-introduce-application-passwords-for-rest-api-authentication\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2604:\"<p>In 2015, WordPress 4.4 introduced a REST API, but one thing that has severely limited its broader use is the lack of  authentication capabilities for third-party applications. After considering the benefits and drawbacks of many different types of authentication systems, George Stephanis published a <a href=\"https://make.wordpress.org/core/2020/09/23/proposal-rest-api-authentication-application-passwords/\">proposal</a> for integrating <a href=\"https://github.com/WP-API/authentication/issues/13\">Application Passwords</a>, into core. </p>



<p>Stephanis highlighted a few of the major benefit that were important factors in the decision to use Application Passwords: the ease of making API requests, ease of revoking credentials, and the ease of requesting API credentials. The project is available as a standalone <a href=\"https://wordpress.org/plugins/application-passwords/\">feature plugin</a>, but Stephanis and his collaborators recommended WordPress merge a <a href=\"https://github.com/WordPress/wordpress-develop/pull/540\">pull request</a> that is based off the feature plugin&rsquo;s codebase.</p>



<p>After WordPress 5.6 core tech lead Helen Hou-Sandi gave the green light for Application Passwords to be merged into core, the developer community responded enthusiastically to the news.</p>



<p>&ldquo;I am/we are 100% in favor of this,&rdquo; Joost deValk commented on the proposal. &ldquo;Opening this up is like opening the dawn of a new era of WordPress based web applications. Suddenly authentication is not something you need to fix when working with the&nbsp;API&nbsp;and you can just build awesome stuff.&rdquo;</p>



<p>Stephanis&rsquo; proposal also mentioned how beneficial a REST API authentication system would be for the <a href=\"https://make.wordpress.org/mobile/\">Mobile teams</a>&lsquo; contributors who are relying on awkward workarounds while integrating Gutenberg support.</p>



<p>&ldquo;This would be a first step to replace the use of XMLRPC in the mobile apps and it would allow us to add more features for self hosted users,&rdquo; Automattic mobile engineer Maxime Biais said.</p>



<p>After the REST API was added to WordPress five years ago, many had the expectation that WordPress-based web applications would start popping up everywhere. Without a reliable authentication system, it wasn&rsquo;t easy for developers to just get inspired and build something quickly. Application Passwords in WordPress 5.6 will open up a lot of possibilities for those who were previously deterred by the lack of core methods for authenticating third-party access.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Oct 2020 23:01:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: WP Agency Summit Begins Its Second Annual Virtual Event October 12\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105160\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:197:\"https://wptavern.com/wp-agency-summit-begins-its-second-annual-virtual-event-october-12?utm_source=rss&utm_medium=rss&utm_campaign=wp-agency-summit-begins-its-second-annual-virtual-event-october-12\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6357:\"<p class=\"has-drop-cap\">Jan Koch, the founder and host of WP Agency Summit, is kicking off his <a href=\"https://wpagencysummit.com/\">second annual event on October 12</a>. The five-day event will feature 37 speakers from a wide range of backgrounds across the WordPress industry. It is a free virtual event that anyone can attend.</p>



<p>&ldquo;The focus for the 2020 WP Agency Summit is showing attendees how to bring back the fun into scaling their agencies,&rdquo; said Koch. &ldquo;It is all about reducing the daily hustle by teaching how to successfully build and manage teams, how to work with enterprises (allowing for fewer customers but bigger projects), how to build sustainable recurring revenue, and how to position your agency to dominate your niche.&rdquo;</p>



<p>This year&rsquo;s event includes three major changes to make the content more accessible to a larger group of people. Each session will be available between October 12 &ndash; 16 instead of the previous 48-hour window that attendees had to find time for in 2019.</p>



<p>After the event has concluded, access to the content will be behind a paywall. Koch reduced the price to $77 for lifetime access for those who purchase pre-launch, which will increase to $127 during the event. Last year&rsquo;s prices ballooned to $497, which meant that it was simply not affordable for many who found it too late.</p>



<p>Some of the proceeds this year are going toward transcribing all the videos so that hearing-impaired users can enjoy the content.</p>



<p>This year&rsquo;s event will also focus on a virtual networking lounge for attendees. &ldquo;I&rsquo;ve seen how well it worked at the WP FeedBack Summit &mdash; we even had BobWP record a podcast episode on the fly in that lounge!&rdquo; said Koch. &ldquo;I&rsquo;ve seen many new friendships develop, people connecting with new suppliers or getting themselves booked on podcasts, and sharing experiences about their businesses.&rdquo;</p>



<p>The lounge will be open during the entirety of the summit, which will allow attendees to jump into the conversation on their own time.</p>



<h2>A More Diverse Speaker Lineup</h2>



<p class=\"has-drop-cap\">Koch received some backlash for the lack of gender diversity last year. <a href=\"https://wptavern.com/wp-agency-summit-kicks-off-december-6\">The 2019 event</a> had over 20 speakers from a diverse male lineup. However, only four women from our industry led sessions.</p>



<p>When asked about this issue in 2019, Koch responded, &ldquo;I recognize this as a problem with my event. The reason I have so much more male than female speakers is quite simple, the current speaker line-up is purely based on connections I had when I started planning for the event. It was a relatively short amount of time for me, so I wasn&rsquo;t able to build relationships with more female WP experts beforehand.&rdquo;</p>



<p>The host said he paid attention to the feedback he received. While not hitting the 50/50 split goal he had for 2020&rsquo;s event, 16 of the 37 speakers are women.</p>



<p>Koch said he strived to get speakers from a wider range of backgrounds. He wanted to bring in both freelancers and multi-million dollar agency owners. He also focused on getting people from multiple countries to represent WordPress agencies.</p>



<p>&ldquo;I did reach out to around 130 people four months before the event to make new connections,&rdquo; he said. &ldquo;The community around the Big Orange Heart (a non-profit for mental well-being) also helped a lot with introducing me to new members of the WP community.&rdquo;</p>



<p>Koch said he learned two valuable lessons when branching out beyond his existing connections for this year&rsquo;s event:</p>



<blockquote class=\"wp-block-quote\"><p>Firstly, don&rsquo;t hesitate to reach out to people you think will never talk to you because they&rsquo;re running such big companies. For example, I immediately got confirmations from Mario Peshev from Devrix, Brad Touesnard from Delicious Brains, or Marieke van de Rakt from Yoast. When first messaging them, I had little hope they&rsquo;d set aside time to jump on an interview with me &ndash; but they were super supportive and accommodating! The WordPress community really is a welcoming environment if you approach people in a humble way.</p><p>Secondly, build connections with sincerity. Do not just focus on what you can get from that connection but how you can help the other person. I know this sounds cheesy and you&rsquo;ve heard this quite often &mdash; but it is true. Once I got the first response from new contacts and explained my goal of connecting fellow WordPress community members virtually, most immediately agreed because they also benefit from new connections and being positioned as a thought-leader in this event.</p></blockquote>



<h2>WP Agency Summit? WP FeedBack Summit?</h2>



<p class=\"has-drop-cap\">For readers who recall the Tavern&rsquo;s coverage of the <a href=\"https://wptavern.com/wp-feedback-kicks-off-free-virtual-summit-for-wordpress-professionals-on-april-27\">WP FeedBack Summit</a> earlier this year, the article specifically stated that the WP FeedBack Summit was a continuation of 2019&rsquo;s WP Agency Summit. The official word at the time from WP FeedBack&rsquo;s public relations team was the following:</p>



<blockquote class=\"wp-block-quote\"><p>Last year&rsquo;s event, the WP Agency Summit has been rebranded under the umbrella of WP FeedBack&rsquo;s brand when Jan Koch the host of last&rsquo;s year WP Agency Summit joined WP FeedBack as CTO.</p></blockquote>



<p>Koch said that it was a standalone event and not directly connected to WP Agency Summit but had the same target audience. However, the WP FeedBack Summit did use the previous WP Agency Summit&rsquo;s stats and data to promote the event.</p>



<p>&ldquo;The WP FeedBack Summit was hosted under the WP FeedBack brand because I joined their team as CTO in March this year,&rdquo; he said. &ldquo;Vito [Peleg] and I had the idea to host a virtual conference around WordPress because of WordCamp Asia being canceled &mdash; we wanted to help connect the community online through our summit.</p>



<p>Koch left WP FeedBack soon after the summit ended and is currently back on his own and has a goal of making WP Agency Summit a yearly event.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Oct 2020 17:01:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Navigation Screen Sidelined for WordPress 5.6, Full-Site Editing Edges Closer to Public Beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105839\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:247:\"https://wptavern.com/navigation-screen-sidelined-for-wordpress-5-6-full-site-editing-edges-closer-to-public-beta?utm_source=rss&utm_medium=rss&utm_campaign=navigation-screen-sidelined-for-wordpress-5-6-full-site-editing-edges-closer-to-public-beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4676:\"<p>The new block-based navigation screen is once again delayed after it was originally <a href=\"https://wptavern.com/new-block-based-navigation-and-widgets-screens-sidelined-for-wordpress-5-5\">slated for WordPress 5.5</a> and then put <a href=\"https://wptavern.com/wordpress-5-6-development-kicks-off-with-all-women-release-squad\">on deck for 5.6</a>. Contributors have confirmed that it will not be landing in WordPress core until 2021 at the earliest.</p>



<p>&ldquo;The Navigation screen is still in experimental state in the&nbsp;Gutenberg&nbsp;plugin, so it hasn&rsquo;t had any significant real-world use and testing yet,&rdquo; Editor Tech Lead&nbsp;Isabel Brison said. She made the call to remove it from the 5.6 lineup after the feature missed the deadline for&nbsp;<a href=\"https://github.com/WordPress/gutenberg/issues/24683\">bringing it out of the experimental state</a>. It still requires a substantial amount of development work and accessibility feedback before moving forward.  </p>



<p>Contributors will focus instead on making sure the Widgets screen gets out the door for 5.6 and plan to pick up again on Navigation towards the end of November. </p>



<p>WordPress 5.6 lead Josepha Haden gave an <a href=\"https://make.wordpress.org/core/2020/10/06/update-wordpress-5-6-release-progress/\">update</a> this week on the progress of all the anticipated features, including the planned public beta for full-site editing (FSE).</p>



<p>&ldquo;I don&rsquo;t expect FSE to be feature complete by the time WP5.6 is released,&rdquo; Haden said. &ldquo;What I expect is that FSE will be functional for simple, routine user flows, which we can start testing and iterating on. That feedback will also help us more confidently design and build our complex user flows.&rdquo;</p>



<p>Frank Klein, an engineer at Human Made, asked in the <a href=\"https://make.wordpress.org/themes/2020/10/07/block-based-themes-and-wordpress-5-6/#comment-44126\">comments</a> of another update why full-site editing is being tied to 5.6 progress in the first place, since it will still only be available in the plugin at the time of release. </p>



<p>&ldquo;The main value is that it provides a good checkpoint along the path of&nbsp;FSE&rsquo;s development,&rdquo; <a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a> said.&nbsp;&ldquo;Full-site editing is very much in progress. It is still experimental, but the general approach is coming into view, and becoming clearer with every plugin release.&rdquo;</p>



<p>Reigstad posted an update on what developers can expect regarding <a href=\"https://make.wordpress.org/themes/2020/10/07/block-based-themes-and-wordpress-5-6/\">block-based theming and the upcoming release,</a> since the topic is closely tied to full-site editing. He emphasized that the infrastructure is already in place and that, despite it still being experimental, future block-based themes should work in a similar way to how they are working now.</p>



<p>&ldquo;The focus is now shifting towards polishing the user experience: using the site editor to create templates, using the query block, iterating on the post and site blocks, and implementing the Global Styles&nbsp;UI,&rdquo; Reigstad said.</p>



<p>&ldquo;The main takeaway is that when 5.6 is released, the full-site editing feature set will look similar to where it is today, with added polish to the UI, and additional features in the Query block.&rdquo;</p>



<p>Theme authors are entering a new time of uncertainty and transition, but Reigstad reassured the community that themes as we know them today are not on track to be phased out in the immediate future.</p>



<p>&ldquo;There is currently no plan to deprecate the way themes are built today,&rdquo; Reigstad said. &ldquo;Your existing themes will continue to work as they always have for the foreseeable future.&rdquo; He also encouraged contributors to get involved in an initiative to&nbsp;<a href=\"https://github.com/WordPress/gutenberg/issues/24803\">help theme authors transition to block-based themes</a>. (This project is not targeted for the 5.6 release.)</p>



<p>Developers can follow important <a href=\"https://github.com/WordPress/gutenberg/issues/24551\">FSE project milestones</a> on GitHub, and subscribe to the weekly&nbsp;<a href=\"https://make.wordpress.org/themes/tags/gutenberg-themes-roundup/\">Gutenberg + Themes updates</a> to track progress on block-based theming. A block-based version of the&nbsp;<a href=\"https://make.wordpress.org/core/2020/09/23/introducing-twenty-twenty-one/\">Twenty Twenty-One theme</a> is in the works and should pick up steam after 5.6 beta 1, expected on October 20.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 22:57:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: EditorPlus 1.9 Adds Animation Builder for the Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105678\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:181:\"https://wptavern.com/editorplus-1-9-adds-animation-builder-for-the-block-editor?utm_source=rss&utm_medium=rss&utm_campaign=editorplus-1-9-adds-animation-builder-for-the-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4535:\"<p class=\"has-drop-cap\">Munir Kamal shows no signs of slowing down. He continues to push forward with new features for his <a href=\"https://wordpress.org/plugins/editorplus/\">EditorPlus plugin</a>, which allows end-users to customize the look of the blocks in their posts and pages. He calls it the &ldquo;no-code style editor for WordPress.&rdquo; </p>



<p><em>The latest addition to his plugin?</em> Animation styles for every core block.</p>



<p>My first thought was that this would bloat the plugin with large amounts of unnecessary CSS and JavaScript for what is essentially a few bells and whistles. However, Kamal pulled it off with minimal custom CSS.</p>



<p>Inspired by features from various website builders, he wanted to bring more and more of those things to the core block editor. The animations feature is just another ticked box on a seemingly never-ending checklist of features. And, so far, it&rsquo;s all still free.</p>



<p>Since we last <a href=\"https://wptavern.com/control-block-design-via-the-editorplus-wordpress-plugin\">covered EditorPlus in June</a>, Kamal has added the ability to insert icons via any rich-text area (e.g., paragraphs, lists, etc.). He has also added shape divider, typography, style copying, and responsive editing options for the core WordPress blocks.</p>



<h2>How Do Animations Work?</h2>



<p class=\"has-drop-cap\">In the version 1.9 release of EditorPlus, Kamal added &ldquo;entrance&rdquo; animations. These types of animations happen when a visitor sees the block for the first time on the screen. For example, users could set the Image block to fade into visibility as a reader views the block.</p>



<p>Currently, the plugin adds seven animations:</p>



<ul><li>Fade</li><li>Slide</li><li>Bounce</li><li>Zoom</li><li>Flip</li><li>Fold</li><li>Roll</li></ul>



<img />Adding a Slide animation for the Cover block text.



<p>Each animation has its own subset of options to control how it behaves on the page. The bounce animation, for example, allows users to select the bounce direction. Other options include duration, delay, speed curve, delay, and repeat. There are enough choices to spend an inordinate amount of time tinkering with the output.</p>



<p>One of the best features of this new feature is that Kamal has included an Animation Player under the block options. By clicking the play button, users can view the animation in action without previewing the post.</p>



<p>Watch a quick video of the Animations feature:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>After testing and using each animation, everything seemed to work well. The one downside &mdash; and this is not limited to animations &mdash; is that applying styles on the block level sometimes does not make sense. In many cases, it would help users to have options to style or animate the items within the block, such as the images in the Gallery block. When I broached the subject with Kamal, he was open to the idea of finding a solution to this in the future.</p>



<h2>What Is Next for EditorPlus?</h2>



<p class=\"has-drop-cap\">At a certain point, too many block options can almost feel like overkill and become unwieldy. EditorPlus does allow users to disable specific features from its settings screen, which can help get rid of some unwanted options. Kamal said he would like to continue making it more modular so that users can use only the features they need.</p>



<p>&ldquo;What I plan is to have micro-level feature control for this extension so that a user can switch off individual styling panels like, Typography, Background, etc.,&rdquo; he said. &ldquo;Even further, I plan to bring these controls based on the user role as well. So an admin can disable these features for the editor, author, etc.&rdquo;</p>



<p>That may be a bit down the road though. For now, he wants to focus on adding new features that he already has planned.</p>



<p>&ldquo;I do plan to add more animation features,&rdquo; said Kamal. &ldquo;I got too many ideas, such as scroll-controlled animation, hover animation, text animation, Lottie animation, background animation, animated shape dividers, and more. But, having said that, I will be careful adding only those features that don&rsquo;t affect page performance much.&rdquo;</p>



<p>Outside of extra styles and animations for existing blocks, he plans to jump on the block-building train in future releases. EditorPlus users could see accordion, toggle, slider, star rating, and other blocks in an upcoming release.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 20:53:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"Donncha: Hide featured image if it’s in the post\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"https://odd.blog/?p=89503242\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://odd.blog/2020/10/08/hide-featured-image-if-its-in-the-post/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3885:\"<p>I&#8217;ve been running a photoblog at <a href=\"https://inphotos.org/\">inphotos.org</a> since 2005 on WordPress. (And thanks to writing this I noticed it&#8217;s <a href=\"https://inphotos.org/2005/10/08/yellow-flower/\">15 years old today</a>!)</p>



<div class=\"wp-block-image\"><img /></div>



<p>In that time WordPress has changed dramatically. At first I used Flickr to host my images, but after a short time I hosted the images myself. (Good thing too since Flickr limited free user accounts to 1000 images, so I wrote <a href=\"https://github.com/donnchawp/bye-bye-flickr\">a script to download</a> the Flickr images I used in posts.)</p>



<div class=\"wp-block-image\"><img /></div>



<p>For quite a long time I used the featured image instead of inserting the image into the post content, but then about two years ago I went back to inserting the photo into the post. Unfortunately that meant the photo was shown twice, once as a featured image, and once in the post content.</p>



<p>The last theme I used supported custom post types, one of which was a photo type that displayed the featured image but hid the post content. It was an ok compromise, but not perfect.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Recently I started using Twenty Twenty, but after 15 years I had a mixture of posts with:</p>



<ul><li>Featured image with no image in the post.</li><li>Featured image with the same image in the post.</li></ul>



<p>I knew I needed something more flexible. I wanted to hide the featured image if it also appeared in the post content. I procrastinated and never got around to it until this evening when I discovered it was actually quite easy. </p>



<img />



<p>Copy the following code into the function.php of your child theme and you&#8217;ll be all set! It relies on you having unique filenames for your images. If you don&#8217;t then remove the call to <code>basename()</code>, and that may help.</p>


<pre class=\"brush: php; auto-links: false; gutter: false; title: ; notranslate\">
function maybe_remove_featured_image( $html ) {
        if ( $html == \'\' ) {
                return \'\';
        }
        $post = get_post();
        $post_thumbnail_id = get_post_thumbnail_id( $post );
        if ( ! $post_thumbnail_id ) {
                return $html;
        }

        $image_url = wp_get_attachment_image_src( $post_thumbnail_id );
        if ( ! $image_url ) {
                return $html;
        }

        $image_filename = basename( parse_url( $image_url[0], PHP_URL_PATH ) );
        if ( strpos( $post-&gt;post_content, $image_filename ) ) {
                return \'\';
        } else {
                return $html;
        }
}
add_filter( \'post_thumbnail_html\', \'maybe_remove_featured_image\' );
</pre>


<p>The <code>post_thumbnail_html</code> filter acts on the html generated to display the featured image. My code above gets the filename of the featured image, checks if it&#8217;s in the current post and if it is returns a blank string. Feedback welcome if you have a better way of doing this!</p>



<div class=\"wp-block-image\"><img /></div>



<p></p>

<p><strong>Related Posts</strong><ul><li> <a href=\"https://odd.blog/2007/07/09/around-ireland-in-80-links-on-july-9th-2007/\" rel=\"bookmark\" title=\"Permanent Link: Around Ireland in 80 links on July 9th 2007\">Around Ireland in 80 links on July 9th 2007</a></li><li> <a href=\"https://odd.blog/2003/12/22/webalizer-hide-the-groups/\" rel=\"bookmark\" title=\"Permanent Link: Webalizer &#8211; hide the groups!\">Webalizer &#8211; hide the groups!</a></li><li> <a href=\"https://odd.blog/2002/11/16/dvdrip-a-full-fe/\" rel=\"bookmark\" title=\"Permanent Link: dvd::rip &#8211; A full featured DVD &#8230;\">dvd::rip &#8211; A full featured DVD &#8230;</a></li></ul></p>
<p><a href=\"https://odd.blog/2020/10/08/hide-featured-image-if-its-in-the-post/\" rel=\"nofollow\">Source</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 20:43:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Donncha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: Cloudflare Launches Automatic Platform Optimization for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105641\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/cloudflare-launches-automatic-platform-optimization-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=cloudflare-launches-automatic-platform-optimization-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6128:\"<p>Just a day after launching its new <a href=\"https://wptavern.com/cloudflare-launches-new-web-analytics-product-focusing-on-privacy\">privacy-first web analytics product</a> last week, Cloudflare announced Automatic Platform Optimization (APO) for WordPress. The new service boasts staggering performance improvements for sites that might otherwise be slowed down by shared hosting, slow database lookups, or sluggish plugins:</p>



<blockquote class=\"wp-block-quote\"><p>Our testing&hellip; showed a 72% reduction in Time to First Byte (TTFB), 23% reduction to&nbsp;<a rel=\"noreferrer noopener\" href=\"https://web.dev/fcp/\" target=\"_blank\">First Contentful Paint</a>, and 13% reduction in&nbsp;<a rel=\"noreferrer noopener\" href=\"https://web.dev/speed-index/\" target=\"_blank\">Speed Index</a>&nbsp;for desktop users at the 90th percentile, by serving nearly all of your website&rsquo;s content from Cloudflare&rsquo;s network.&nbsp;</p></blockquote>



<p>APO uses Cloudflare Workers to cache dynamic content and serve the website from its <a href=\"https://www.cloudflare.com/learning/cdn/glossary/edge-server/\">edge network</a>. In most cases this eliminates origin requests and origin processing time. That means visitors requesting your website will get near instant load times. Cloudflare reports that its testing shows APO delivers consistent load times of under 400ms for HTML Time to First Byte (TTFB).</p>



<p>The effects of using APO are similar to hosting static files on a CDN, but without the need to manage a complicated tech stack. Content creators retain their ability to create dynamic websites without any changes to their workflow for the sake of performance. </p>



<p>Version 3.8 of <a href=\"https://wordpress.org/plugins/cloudflare/\">Cloudflare&rsquo;s official WordPress plugin</a> was recently updated to include support for APO. It detects when users make changes to their content and purges the content stored on Cloudflare&rsquo;s edge.</p>



<p>The new service is available to Cloudflare users with a single click of a button. APO is included at no cost for existing Cloudflare customers on the Professional, Business, and Enterprise plans. Users on the Free plan can add it to their sites for $5/month. The service is a flat fee and is not metered. </p>



<p>Cloudflare&rsquo;s announcement has so far been well-received by WordPress professionals and hosting companies and many have already begun testing it. </p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">So the week after <a href=\"https://twitter.com/Cloudflare?ref_src=twsrc%5Etfw\">@Cloudflare</a> Birthday Week I try and play with as many of the new products as possible. Today was the WordPress APO on my simple demo site. You can see TTFB dropped from ~350ms to ~75ms!  <a href=\"https://t.co/zg976EjrZI\">https://t.co/zg976EjrZI</a> <a href=\"https://t.co/KuaHqtHLom\">pic.twitter.com/KuaHqtHLom</a></p>&mdash; Matt Bullock (@mibullock) <a href=\"https://twitter.com/mibullock/status/1313478984534052865?ref_src=twsrc%5Etfw\">October 6, 2020</a></blockquote>
</div>



<p>WordPress lead developer Mark Jaquith <a href=\"https://twitter.com/markjaquith/status/1312178973372157953\">called</a> APO &ldquo;incredible news for the WordPress world.&rdquo;</p>



<p>&ldquo;On sites I manage this is going to lower hosting complexity and easily save hundreds of dollars a month in hosting costs,&rdquo; Jaquith said.</p>



<p>After running several speed tests from six different locations around the world, early testers at Kinsta got remarkable results using APO:</p>



<blockquote class=\"wp-block-quote\"><p>&ldquo;By caching&nbsp;static HTML&nbsp;on Cloudflare&rsquo;s edge network, we saw a 70-300% performance increase. As expected, the testing locations furthest away from Tokyo saw the biggest reduction in&nbsp;load time.</p><p>&ldquo;If your WordPress site uses a traditional&nbsp;CDN&nbsp;that only caches CSS, JS, and images, upgrading to Cloudflare&rsquo;s WordPress APO is a no-brainer and will help you stay competitive with modern Jamstack and static sites that live on the edge by default.&rdquo;</p></blockquote>



<p>George Liu, a &ldquo;self-confessed page speed addict&rdquo; and Cloudflare Community MVP, performed a series of <a href=\"https://community.centminmod.com/threads/cloudflare-wordpress-plugin-automatic-platform-optimization.20486/\">detailed tests</a> on the new APO product with his blog. After many comparisons, he found that Cloudoflare&rsquo;s WordPress plugin with APO turned on delivers results similar to his heavily optimized WordPress blog that uses a custom Cloudflare Worker caching configuration.</p>



<p>&ldquo;You&rsquo;ll find that Cloudflare WordPress plugin&rsquo;s one click Automatic Platform Optimization button does wonders for page speed for the average WordPress user not well versed in page speed optimizations,&rdquo; Liu said.</p>



<p>&ldquo;Cloudflare&rsquo;s WordPress plugin Automatic Platform Optimization will in theory beat all other WordPress caching solutions other than you rolling out your own Cloudflare Worker based caching like I did. So you get a good bang for your buck at US$5/month for Cloudflare&rsquo;s WordPress plugin APO.&rdquo;</p>



<p>Liu also warned of some speed bumps with the initial rollout, as Cloudflare&rsquo;s APO supports a limited set of WordPress cookies for bypassing the Cloudflare CDN cache, leaving certain use cases unsupported. APO does not seem to work on subdomains and users are also reporting that it&rsquo;s not compatible with other caching plugins. It also disables real visitor IP address detection. </p>



<p>Cloudflare is aware of many of these issues, which have been raised in the comments of the <a href=\"https://blog.cloudflare.com/automatic-platform-optimizations-starting-with-wordpress/\">announcement</a>, and is in the process of adding more cookies to the list to bypass caching. Due to some plugin conflicts, APO may not be as plug-and-play as it sounds for some users right now, but the product is very promising and should improve over time with more feedback.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 08 Oct 2020 04:18:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: Kick off Block-Based WordPress Theme Development With the Theme.json Creator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/kick-off-block-based-wordpress-theme-development-with-the-theme-json-creator?utm_source=rss&utm_medium=rss&utm_campaign=kick-off-block-based-wordpress-theme-development-with-the-theme-json-creator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4674:\"<p class=\"has-drop-cap\">Gutenberg 9.1 made a backward-incompatible change to its <code>theme.json</code> file (<code>experimental-theme.json</code> while full-site editing is under the experimental flag). This is the configuration file that theme developers will need to create as part of their block-based themes. Staying up to date with such changes can be a challenge for theme authors, but Ari Stathopoulos, a Themes Team representative, wrote a <a href=\"https://make.wordpress.org/themes/2020/10/01/gutenberg-9-1-new-json-structure-for-fse-theme-json-files/\">full guide for developers</a>.</p>



<p>Jon Quach, a Principal Designer at Automattic, has also been busy creating a tool to help theme authors transition to block-based themes. He recently built a UI-based project called <a href=\"https://gutenberg-theme.xyz/\">Theme.json Creator</a> that builds out the JSON code for theme authors. Plus, it is up to date with the most recent changes in the Gutenberg plugin.</p>



<p>Tools like these will be what the development community needs as it gets over the inevitable hump of moving away from the traditional theme development paradigm and into a new era where themes are made almost entirely of blocks and a config file.</p>



<p>While plugin development is becoming more complex with the addition of JavaScript, theme development is taking a sharp turn toward its roots of HTML and CSS. We are barreling toward a future in which far more people will be able to create WordPress themes. Even the possibility of sharing pieces of themes (e.g., template parts and patterns) is on the table. This could not only empower theme designers by lowering the barrier to entry, it could also empower some end-users to make the jump into theme building.</p>



<p>However, the <code>theme.json</code> file is one aspect of future theme authorship that is extremely developer-oriented. JSON is a universal format shared between various programming languages. It is meant to be read by machines and is not quite as human-friendly as other formats. As the <code>theme.json</code> file grows to accommodate more configuration options over time, the less friendly it will become to simply typing keys and values in.</p>



<p>It makes sense to build tools to simplify this part of the theme building process.</p>



<p>That is where the Theme.json Creator tool comes in. Theme authors pick and choose the options they want to support and input custom values. Then, the tool spits out everything in properly-formatted JSON.</p>



<img />Using the Theme.json Creator tool.



<p>One big thing the tool does not yet cover is custom CSS variables. This feature is a recent addition to the <code>theme.json</code> specification. It allows theme authors to create any custom property that WordPress will automatically output as CSS. In his announcement post, Stathopoulos covered how to create a typographic scale with custom properties and use those variables for editor features, such as line-height and font-size values.</p>



<p>Currently, Theme.json Creator&rsquo;s primary focus is on global styles. However, Gutenberg allows theme authors to configure default styles on the block level. For example, theme designers can set the color or typography options for the core Heading block to be different from the default global styles. This provides theme authors with fine-tuned control over every block.</p>



<p>Theme.json Creator does not yet support configuration at this level. However, it would be interesting to see if Quach adds it in the future.</p>



<p>The focus on setting up global styles is a good start for now. This is still an experimental feature. The great thing about it is that it can help theme authors begin to see how one piece of the block-based themes puzzle fits in. It is a starting point for an entirely new method of adding theme support for features when most are accustomed to adding multiple <code>add_theme_support()</code> PHP function calls.</p>



<p>With the direction that theme development seems to be heading, it is easy to imagine that it could evolve into a completely UI-based affair at some point down the line. If templates are made up of blocks and patterns, which anyone can already build with the block editor, and if styles will essentially boil down to a config file, there will be little-to-no programming required to build a basic WordPress theme.</p>



<p>If someone is not already at least jotting down notes for a plugin that allows users to create and package a block-based theme, I would be surprised. For now, Theme.json Creator is removing the need to write code for at least one part of the theme design process.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 07 Oct 2020 20:53:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"WPTavern: Jetpack 9.0 Introduces Loom Block, Twitter Threads Feature, and Facebook and Instagram oEmbeds\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105743\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:249:\"https://wptavern.com/jetpack-9-0-introduces-loom-block-twitter-threads-feature-and-facebook-and-instagram-oembeds?utm_source=rss&utm_medium=rss&utm_campaign=jetpack-9-0-introduces-loom-block-twitter-threads-feature-and-facebook-and-instagram-oembeds\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4033:\"<div class=\"wp-block-image\"><img /></div>



<p>Jetpack&rsquo;s highly anticipated <a href=\"https://jetpack.com/2020/10/06/jetpack-9-0-continue-sharing-facebook-and-instagram-posts-on-your-site/\">9.0 release</a> has landed, introducing some of the new features the team has previewed over the past week. Users can now <a href=\"https://wptavern.com/jetpack-9-0-to-introduce-new-feature-for-publishing-wordpress-posts-to-twitter-as-threads\">publish WordPress posts to Twitter as threads</a>. This new feature is available as part of the Publicize module when you have connected a Twitter account. </p>



<p>Posting Twitter threads is a feature that only works with the block editor, as it takes advantage of how content is naturally split into chunks (blocks). </p>



<p>In the comments on his <a href=\"https://pento.net/2020/09/29/more-than-280-characters/\">demo post</a>, Automattic engineer Gary Pendergast gave a more detailed breakdown of the logic Jetpack uses to ensure full sentences aren&rsquo;t broken up in the tweets. </p>



<p>&ldquo;With the mental model now being focused on mapping blocks to tweets, it&rsquo;s much easier to make logical decisions about how to handle each block,&rdquo; Pendergast said. &ldquo;So, a paragraph block is the text of a tweet, if the paragraph is too long for a single tweet, it tries to split the paragraph up by sentences. If a sentence is too long, then it resorts to splitting by words. Then, if there&rsquo;s an embed/image/video/gallery block following that paragraph, we can attach it to the tweet containing that paragraph. There are additional rules for other blocks, but that&rsquo;s the basic process. It then just iterates over all of the supported blocks in the post.&rdquo;</p>



<p>Pendergast <a href=\"https://twitter.com/GaryPendergast/status/1310769596794908674\">published his post as thread</a> to demonstrate the new feature in action. The advantage of posting a thread from your WordPress site is that it doesn&rsquo;t end up getting lost in Twitter&rsquo;s fast-moving timeline. Most important Twitter threads evaporate from public consciousness almost as soon as they are published. Publishing threads from your website ensures they are better indexed and easier to reference in the future.</p>



<h2>Jetpack Adds Loom Block for Embedding Screen Recordings </h2>



<p><a href=\"https://www.loom.com/\">Loom</a> was <a href=\"https://github.com/Automattic/jetpack/pull/17137\">added to Jetpack</a> as a new oEmbed provider three weeks ago. The video recording service allows for recording camera, microphone, and desktop simultaneously. The service is especially popular in educational settings. Jetpack 9.0 introduces a new Loom block for embedding recordings. </p>



<img />



<p>&ldquo;Loom is growing in popularity as it is being recommended more and more to assist in distance learning efforts,&rdquo; Jetpack Director of Innovation Jesse Friedman said. &ldquo;Now more than ever we want to be able to help those working, learning, and teaching from home. The Loom block was a natural addition to join the other Jetpack video blocks which now include YouTube, TikTok, DailyMotion, and Vimeo.&rdquo;</p>



<p>Loom&rsquo;s free tier allows users to record up to 25 videos, but the Pro plan is free for educators. Friedman confirmed that Jetpack does not have any kind of partnership with Loom. The team decided to support the product to assist professionals, educators, and students. Having it available as a block also makes it more convenient for those using <a href=\"https://wordpress.com/p2/\">P2</a> for communication.</p>



<p>As anticipated, Jetpack 9.0 also provides a seamless transition necessary to ensure Instagram and Facebook embeds will continue working after Facebook drops <a href=\"https://developers.facebook.com/docs/plugins/oembed-legacy\">unauthenticated oEmbed support</a> on October 24. The Jetpack team reports that it &ldquo;partnered with Facebook&rdquo; to make sure these embeds continue to work with the WordPress.com REST API.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Oct 2020 23:28:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"Post Status: Joost de Valk on WordPress marketshare\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=79914\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://poststatus.com/joost-de-valk-on-wordpress-marketshare/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1193:\"<p>David Bisset makes his podcast debut for Post Status, as he interviews Joost de Valk, Founder and Chief Product Officer of Yoast, and discusses all things WordPress marketshare related.</p>







<h3 id=\"h-links\">Links</h3>



<ul><li>His blog, <a href=\"https://joost.blog/\">joost.blog</a></li><li><a href=\"https://yoast.com\">Yoast</a></li><li>On Twitter <a href=\"https://twitter.com/jdevalk\">@jdevalk</a></li><li>June 2020 <a href=\"https://joost.blog/cms-market-share-june-2020-analysis/\">CMS marketshare report</a></li></ul>



<h3>Partner:&nbsp;<a href=\"https://jilt.com/?utm_source=Post+Status&utm_medium=banner&utm_campaign=Post+Status+Sponsorship\">Jilt</a></h3>



<p><a href=\"https://jilt.com/?utm_source=Post+Status&utm_medium=banner&utm_campaign=Post+Status+Sponsorship\">Jilt</a> offers powerful email marketing built for eCommerce. From newsletters to highly segmented automations, Jilt is your one-stop show for eCommerce email. Join thousands of stores that have already earned tens of millions of dollars in extra sales using Jilt. <a href=\"https://jilt.com/?utm_source=Post+Status&utm_medium=banner&utm_campaign=Post+Status+Sponsorship\">Try Jilt for free</a></p>



<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Oct 2020 22:28:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: iThemes Buys WPComplete, Complementing Its Recent Restrict Content Pro Acquisition\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105631\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:227:\"https://wptavern.com/ithemes-buys-wpcomplete-complementing-its-recent-restrict-content-pro-acquisition?utm_source=rss&utm_medium=rss&utm_campaign=ithemes-buys-wpcomplete-complementing-its-recent-restrict-content-pro-acquisition\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4395:\"<p class=\"has-drop-cap\">Just one month after publicly announcing its <a href=\"https://wptavern.com/ithemes-enters-the-wordpress-membership-plugin-market-acquires-restrict-content-pro\">acquisition of Restrict Content Pro</a> (RCP), iThemes <a href=\"https://ithemes.com/wpcomplete-joining-ithemes-family/\">purchased WPComplete</a> for an undisclosed amount. The acquisition is for the product, website, and customers only.</p>



<p>Paul Jarvis and Zack Gilbert created the <a href=\"https://wordpress.org/plugins/wpcomplete/\">WPComplete plugin</a> in 2016. However, it has outgrown what the duo could maintain and support alone. After the transition period in which the new owners take over, the two will step away from the project.</p>



<p>In essence, <a href=\"https://wpcomplete.co/\">WPComplete</a> is a &ldquo;course completion&rdquo; plugin. Site owners can create online courses while allowing students/users to mark their work as completed. It also gives students a way to track their progress through courses, which can often boost the potential for them to finish.</p>



<p>&ldquo;Paul and Jack believe a key to their success has been their ability to keep their team small and manageable,&rdquo; wrote Matt Danner, the COO at iThemes, in the announcement. &ldquo;The growth of WPComplete has presented a number of challenges for a team of two people, so the decision was made to start looking towards alternative ownership solutions that could continue to grow WPComplete and provide it with a stable team. iThemes is a perfect fit.&rdquo;</p>



<p>iThemes customers who have a Plugin Suite or Toolkit membership will get automatic access to the pro version of the WPComplete plugin. For current WPComplete users, Danner said everything should be &ldquo;business as usual.&rdquo; However, iThemes has assigned a few of its team members to work on the product and site, so customers should see some new faces.</p>



<p>RCP and WPComplete are obviously complementary products. RCP is a membership plugin that allows site owners to restrict content based on that membership. WPComplete allows site members to mark lessons or coursework as completed. &ldquo;We&rsquo;ll be rolling out a new bundle later this month that combines both RCP and WPComplete for course and membership creators to take advantage of these two plugins,&rdquo; said AJ Morris, the Product Innovation and Marketing Manager at iThemes.</p>



<p>WPComplete is still a young product. The free version of the plugin currently has 2,000+ active installs and a solid 4.7 rating on WordPress.org. If marketed as an extension of the RCP plugin, it automatically puts it in front of the eyes of 1,000s of more potential customers. It should be much easier to grow the plugin as part of a membership bundle.</p>



<p>iThemes is making some bold moves in the membership space. It will be interesting to see if the company makes any other acquisitions that could strengthen its product line and help it become more dominant. There is still a ton of room for growth in the membership segment of the market. There is also the potential for integrations with other major plugins.</p>



<p>&ldquo;Adding WPComplete to the iThemes product lineup also allows us to move more quickly on some plans we have for Restrict Content Pro,&rdquo; said Danner in the initial announcement. He also vaguely mentioned a couple of ideas the team had in the works but did not go into detail.</p>



<p>With a little prodding, Morris provided some insight into what they are planning for the immediate future. The biggest first step is tackling integration with the block editor. Currently, WPComplete uses shortcodes. The team&rsquo;s next step is likely to begin with creating block equivalents for those shortcodes.</p>



<p>&ldquo;After that, we&rsquo;ve touched on a few deeper integrations with Restrict Content Pro, like the possibility to restrict courses to memberships,&rdquo; said Morris.</p>



<p>The iThemes team does not plan to stop with WPComplete as part of its product lineup. One of the goals is to use the plugin for the iThemes website itself.  </p>



<p>&ldquo;We always try to eat our own dogfood when we can,&rdquo; said Morris. &ldquo;You&rsquo;ll see that with RCP and WPComplete early next year as we look to integrate them into our <a href=\"https://training.ithemes.com\">iThemes Training</a> membership.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Oct 2020 20:59:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Exploring Full-Site Editing With the Q WordPress Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105676\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:173:\"https://wptavern.com/exploring-full-site-editing-with-the-q-wordpress-theme?utm_source=rss&utm_medium=rss&utm_campaign=exploring-full-site-editing-with-the-q-wordpress-theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7492:\"<p class=\"has-drop-cap\">I have been eagerly awaiting the moment when I could install a theme and truly test Gutenberg&rsquo;s full-site editing feature. By and large, each time I have tested it over the past few months, the experience has felt utterly broken. This is why I have remained skeptical of seeing the feature land in WordPress 5.6 this December.</p>



<p>The <a href=\"https://github.com/aristath/q\">Q theme</a> by Ari Stathopoulos is the first theme that seems to be a decent working example. Whether that is a stroke of luck with timing or that this particular theme is simply built correctly is hard to tell &mdash; Stathopoulos is a team rep for the Themes Team. <a href=\"https://wptavern.com/gutenberg-9-1-adds-patterns-category-dropdown-and-reverts-block-based-widgets-in-the-customizer\">Gutenberg 9.1</a> dropped last week with continued work toward site editing.</p>



<p>Q is as experimental as it gets. The <a href=\"https://make.wordpress.org/themes/2020/03/01/call-for-experimental-themes/\">Themes Team put out an open call</a> for experimental, block-based themes as far back as March this year. However, not many have taken the team up on this offer. If approved, Q stands to be the first block-based theme to go live in the official WordPress directory. It still has to work its way through the standard <a href=\"https://themes.trac.wordpress.org/ticket/90263\">review process</a>, awaiting its turn in the coming weeks.</p>



<p>On the whole, full-site editing remains a frustrating and confusing experience. I still remain skeptical about its readiness, even in beta form, to show off to the world in WordPress 5.6.</p>



<p>However, Q is an interesting theme to explore at this point for both end-users and theme developers. Users can install it and start tinkering with the site editing screen via the Gutenberg plugin. Developers can learn how global styles, templates, and template parts fit together from a working theme.</p>



<h2>Using the Site Editor</h2>



<img />Editing a single post in the site editor.



<p class=\"has-drop-cap\">The Q theme requires the Gutenberg plugin and its full-site editing mode to be enabled. Generally, requiring a plugin is not allowed for themes in the directory. However, experimental Gutenberg themes are allowed to bypass this guideline.</p>



<p>Stathopoulos pointed out that the theme is highly experimental and should not be used on a production site. However, he is hopeful that it will get more eyes focused on full-site editing.</p>



<p>He mentioned that several items are broken, such as category archives not showing the correct posts. This is a current limitation of the Query block in Gutenberg. However, one of the best ways to find and recognize these types of issues is to have a theme that stays up with the pace of development.</p>



<p>Currently, the site editor feels like it is biting off more than it can chew. Not only can users edit the layout and design of the page, but they can also directly edit existing post content &mdash; don&rsquo;t try this at home unless you are willing for your post titles to get switched to the hyphenated slug. Should the site editor be handling the double-duty of design and content editing? If so, should design and content editing be handled in separate locations in the long term or be merged into one feature?</p>



<p>It feels raw. It is not geared toward users at this point.</p>



<p>The bright spot with the site editor is the current progress on template parts in the editor. Template parts are essentially &ldquo;modules&rdquo; that handle one part of the page. For example, the typical theme will have a header and footer template part. Currently, end-users can insert custom template parts or switch one template part for another. This opens a world of possibilities, such as users choosing between multiple header designs (template parts) for their sites.</p>



<img />Switching the header template part.



<p>The downside to the entire template system is that it seems so divorced from the site editor that it is hard to believe the average user would understand what is going on. Templates and template parts reside under the Appearance menu in the admin. The Site Editor is a separate, top-level menu item. Without any preexisting knowledge of how these pieces work together, it can be confusing.</p>



<p>Template parts worked for me in the site editor from the outset. However, they did not work on the front end at first. I continually received the &ldquo;template part not found&rdquo; message for hours. Then, at some point &mdash; whether through magic or a random save that pulled everything together &mdash; the feature began to output the previously-<em>missing</em> header and footer template parts.</p>



<h2>Glimpse Into the Future of Theme Development</h2>



<p class=\"has-drop-cap is-style-default\">The Q theme has a scant few style rules, which it loads directly in the <code>&lt;head&gt;</code> section of the site in lieu of adding an extra stylesheet. It relies on the stock Gutenberg block styles on the front end with a few minor overrides. Most other custom styles are handled via the global styles system, which pulls from the theme&rsquo;s <code>experimental-theme.json</code> config file (will be <code>theme.json</code> in the future).</p>



<p>It begs the question of whether themes will necessarily need much in the way of CSS when full-site editing lands.</p>



<p>If WordPress allows users to configure most styles via block options and global styles overrides, themes may not need much more than their config files. After that, it would come down to registering custom block styles and patterns.</p>



<p>If this is the future that we are headed toward, anyone could essentially create a WordPress theme. And, those pieces, such as template parts and patterns, could all be shared between any site. In that future, themes may simply not matter anymore.</p>



<p>Last year, Mike Schinkel proposed <a href=\"https://mikeschinkel.me/2019/wordpress-should-deprecate-themes/\">deprecating the theme system</a> altogether and replacing it with web components.</p>



<p>&ldquo;Rather than look for a theme that has all the features one needs &mdash; which I have found always limits the choices to zero &mdash; a site owner could look for the components and modules they need and then assemble their site from those modules,&rdquo; he said. &ldquo;They could pick a header, a footer, a home-page hero, a set of article cards, a pricing module, and so on.&rdquo;</p>



<p>The more I tinker with full-site editing, the more it feels like that is the lane that it will ultimately merge into. Imagine a future where end-users could pick and choose the pieces they wanted and simply have it look right on the front end.</p>



<p>It is exciting to think about that possibility. Both Schinkel and I have more of a background in programming than we do in design. It makes sense from that sort of analytical mindset to put everything into neat, reusable <em>boxes</em> because reuse is a cornerstone of smart programming.</p>



<p>However, I worry about the state of design in such a system with so many replaceable parts. Will designers be able to take holistic approaches to theme development, creating truly intricate pieces of art? Will that system essentially create a web of cookie-cutter sites? Or, will designers simply find ways to think outside the box  while within the constraints of the block system?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Oct 2020 21:21:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"WPTavern: Virtual Jamstack Conf to Feature Fireside Chat with Matt Mullenweg and Matt Biilmann, October 6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105680\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:253:\"https://wptavern.com/virtual-jamstack-conf-to-feature-fireside-chat-with-matt-mullenweg-and-matt-biilmann-october-6?utm_source=rss&utm_medium=rss&utm_campaign=virtual-jamstack-conf-to-feature-fireside-chat-with-matt-mullenweg-and-matt-biilmann-october-6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2618:\"<div class=\"wp-block-image\"><img />image credit: <a href=\"https://jamstackconf.com/\">Jamstack Conf</a></div>



<p>The greater Jamstack community is coming together on October 6-7, 2020, for a <a href=\"https://jamstackconf.com/virtual/\">virtual conference</a>. Organizers expect more than 15,000 attendees from around the globe over a two-day span that includes keynotes, sessions, interactive topic tables, workshops, speaker Q&amp;As, and networking opportunities. </p>



<p>Matt Mullenweg will be joining Netlify CEO Matt Biilmann on <a href=\"https://jamstackconfvirtual2020.sched.com/event/eqVI\">day 1 at 12PM PDT</a> for a fireside chat moderated by<a href=\"https://css-tricks.com/\"> CSS-Tricks</a> Creator Chris Coyier. The chat will go deeper on recent topics of contention, including developer sentiment, complexity, security, and performance. Coyier also plans to discuss how the Jamstack and WordPress communities intersect through headless implementations of the CMS.</p>



<p>A provocative post from <a href=\"https://thenewstack.io/wordpress-co-founder-matt-mullenweg-is-not-a-fan-of-jamstack/\">TheNewStack</a> at the end of August quoted Mullenweg as saying that &ldquo;JAMstack is a regression for the vast majority of the people adopting it.&rdquo; This sparked multiple heated exchanges across blogs and social media. Biilimann, who originally coined the term &ldquo;Jamstack,&rdquo; wrote a <a href=\"https://www.netlify.com/blog/2020/09/15/on-mullenweg-and-the-jamstack-regression-or-future/\">response</a> to Mullenweg&rsquo;s remarks, hailing &ldquo;the end of the WordPress era.&rdquo; </p>



<p>Live conversations tend to be more cordial than shots fired across the blogosphere. It will be interesting to see if Biilimann cares to join <a href=\"https://www.stackbit.com/\">Stackbit</a> CEO Ohad Eder-Pressman in his wager that Jamstack will become the <a href=\"https://wptavern.com/matt-mullenweg-and-jamstack-community-square-off-making-long-term-bets-on-the-predominant-architecture-for-the-web\">predominant architecture for the web by 2025</a>. The fireside chat should be recorded, in case you cannot catch the live session. Recordings of talks from the previous virtual Jamstack event held in May are <a href=\"https://www.youtube.com/playlist?list=PL58Wk5g77lF8jzqp_1cViDf-WilJsAvqT\">available on YouTube</a>.</p>



<p>Today is the last call for registration. Many of the workshops have already sold out, but tickets to the regular sessions on October 6 are still available. <a href=\"https://ti.to/netlify/jamstack_virtual_oct\">Sign up</a> on the event website to get your free ticket. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Oct 2020 20:12:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"WPTavern: Gutenberg 9.1 Adds Patterns Category Dropdown and Reverts Block-Based Widgets in the Customizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105629\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:255:\"https://wptavern.com/gutenberg-9-1-adds-patterns-category-dropdown-and-reverts-block-based-widgets-in-the-customizer?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-9-1-adds-patterns-category-dropdown-and-reverts-block-based-widgets-in-the-customizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5615:\"<p class=\"has-drop-cap\">Gutenberg 9.1 was released to the public on Wednesday. The team announced over 200 commits from 77 contributors in its <a href=\"https://make.wordpress.org/core/2020/10/01/whats-new-in-gutenberg-30-september/\">release post</a> yesterday. One of the biggest changes to the interface was the addition of a new dropdown selector for block pattern categories. The team also reverted the block-based widgets section in the customizer and added an image size control to the Media &amp; Text block.</p>



<p>One of the main focuses of this release was improving the block-based widgets editor. The feature was taken out of the experimental stage in Gutenberg 8.9 and continues to improve. The widgets screen now uses the <a href=\"https://github.com/WordPress/gutenberg/pull/25681\">same inserter UI</a> as the post-editing screen. However, users can currently only insert regular blocks. Patterns and reusable blocks are still not included.</p>



<p>Theme authors can now <a href=\"https://github.com/WordPress/gutenberg/issues/20588\">control aspects of the block editor</a> via a custom <code>theme.json</code> file. This is part of the ongoing Global Styles project, which will allow theme authors to configure features for their users.</p>



<p>The development team has also added an <a href=\"https://github.com/WordPress/gutenberg/pull/25115\">explicit box-sizing style rule</a> to the Cover and Group blocks. This is to avoid any potential issues with the new padding/spacing options. Theme authors who rely on the block editor styles should test their themes to make sure this change does not break anything.</p>



<h2>Better Pattern Organization</h2>



<img />New block patterns UI in the inserter.



<p class=\"has-drop-cap\">I have been calling for the return of the tabbed pattern categories since <a href=\"https://wptavern.com/gutenberg-8-0-merges-block-and-pattern-inserter-adds-inline-formats-and-updates-code-editor\">Gutenberg 8.0</a>, which was a regression from previous versions. For 11 versions, users have had to scroll and scroll and scroll through every block pattern just to find the one they wanted. The development team has sought to address this issue by using a <a href=\"https://github.com/WordPress/gutenberg/pull/24954\">category dropdown selector</a>. When selecting a specific category, its patterns will appear.</p>



<p>At first, I was unsure about this method over the old tabbed method. However, after some use, it feels like the right direction.</p>



<p>As more and more theme and plugin authors add block pattern categories to users&rsquo; sites, the dropdown is a more sensible route. Even tabs could become unwieldy over time. The dropdown better organizes the list of categories and makes the UI cleaner. More than anything, I am enjoying the experience and look forward to this eventually landing in WordPress 5.6 later this year.</p>



<h2>Customizer Widgets Reverted</h2>



<img />Reverted widgets panel in the customizer.



<p class=\"has-drop-cap\">On the subject of WordPress 5.6, one of its flagship features has been hitting some roadblocks. Block-based widgets are expected to land in core with the December release, but the team just reverted part of the feature. They had to remove the widgets block editor from the customizer they added just two major releases ago.</p>



<p>It was for the best. The customizer&rsquo;s block-based widgets editor was <a href=\"https://wptavern.com/gutenberg-8-9-brings-block-based-widgets-out-of-the-experimental-stage\">fundamentally broken</a>. It was not ready for primetime and should have remained in the experimental stage until it was somewhat usable.</p>



<p>&ldquo;I will approve this since the current state of the customizer in the Gutenberg plugin is broken, and there is no clear path forward about how to fix that,&rdquo; wrote Andrei Draganescu in the <a href=\"https://github.com/WordPress/gutenberg/pull/25626\">reversion ticket</a>. &ldquo;With this patch, the normal widgets can still be edited in the customizer and the block ones don&rsquo;t break it anymore. This is NOT to mean that we won&rsquo;t proceed with fixing the block editor in the customizer, that is still an ongoing discussion.&rdquo;</p>



<p>The current state of editing widgets via the customizer is at least workable with this change. If end-users add a block via the admin-side widgets editor, it will merely appear as an uneditable, <em>faux</em> widget named &ldquo;Block&rdquo; in the customizer. They will need to edit blocks via the normal widgets screen.</p>



<p>There is no way that WordPress can ship the current solution when 5.6 rolls out. However, we are still two months out. This leaves plenty of time for a fix, but Draganescu&rsquo;s note that &ldquo;there is no clear path forward&rdquo; may make some people a bit uneasy at this stage of development.</p>



<h2>Control Image Size for Media &amp; Text</h2>



<img />Image size dropdown selector for the Media &amp; Text block.



<p class=\"has-drop-cap\">One of the bright spots in this update is the addition of an <a href=\"https://github.com/WordPress/gutenberg/pull/24795\">image size control</a> to the Media &amp; Text block. Like the normal Image block, end-users can choose from any registered image size created for their uploaded image.</p>



<p>This is a feature I have been looking forward to in particular. Previously, using the full-sized image often made the page weight a bit heftier than necessary. It is also nice to go along with themes that register sizes for both landscape and portrait orientations, giving users more options.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Oct 2020 20:56:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WordPress.org blog: The Month in WordPress: September 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=9026\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wordpress.org/news/2020/10/the-month-in-wordpress-september-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8711:\"<p>This month was characterized by some exciting announcements from the WordPress core team! Read on to catch up with all the WordPress news and updates from September.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.5.1 Launch</h2>



<p>On September 1, the&nbsp; Core team released <a href=\"https://wordpress.org/news/2020/09/wordpress-5-5-1-maintenance-release/\">WordPress 5.5.1</a>. This maintenance release included several bug fixes for both core and the editor, and many other enhancements. You can update to the latest version directly from your WordPress dashboard or <a href=\"https://wordpress.org/download/\">download</a> it directly from WordPress.org. The next major release will be <a href=\"https://make.wordpress.org/core/5-6/\">version 5.6</a>.</p>



<p>Want to be involved in the next release?&nbsp; You can help to build WordPress Core by following<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>, and joining the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Gutenberg 9.1, 9.0, and 8.9 are out</h2>



<p>The core team launched <a href=\"https://make.wordpress.org/core/2020/09/16/whats-new-in-gutenberg-16-september/\">version 9.0</a> of the Gutenberg plugin on September 16, and <a href=\"https://make.wordpress.org/core/2020/10/01/whats-new-in-gutenberg-30-september/\">version 9.1</a> on September 30. <a href=\"https://make.wordpress.org/core/2020/09/16/whats-new-in-gutenberg-16-september/\">Version 9.0</a> features some useful enhancements — like a new look for the navigation screen (with drag and drop support in the list view) and modifications to the query block (including search, filtering by author, and support for tags). <a href=\"https://make.wordpress.org/core/2020/10/01/whats-new-in-gutenberg-30-september/\">Version 9.1</a> adds improvements to global styles, along with improvements for the UI and several blocks. <a href=\"https://make.wordpress.org/core/2020/09/03/whats-new-in-gutenberg-2-september/\">Version 8.9</a> of Gutenberg, which came out earlier in September, enables the block-based widgets feature (also known as block areas, and was previously available in the experiments section) by default — replacing the default WordPress widgets to the plugin. You can find out more about the Gutenberg roadmap in the <a href=\"https://make.wordpress.org/core/2020/09/03/whats-next-in-gutenberg-september/\">What’s next in Gutenberg blog post</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Twenty Twenty One is the WordPress 5.6 default theme</h2>



<p><a href=\"https://make.wordpress.org/core/2020/09/23/introducing-twenty-twenty-one/\">Twenty Twenty One</a>, the brand new default theme for <a href=\"https://make.wordpress.org/core/5-6/\">WordPress 5.6</a>, has been announced! Twenty Twenty One is designed to be a blank canvas for the block editor, and will adopt a straightforward, yet refined, design. The theme has a limited color palette: a pastel green background color, two shades of dark grey for text, and a native set of system fonts. Twenty Twenty One will use a modified version of the <a href=\"https://wordpress.org/themes/seedlet/\">Seedlet theme</a> as its base. It will have a comprehensive system of nested CSS variables to make child theming easier, a native support for global styles, and full site editing.&nbsp;</p>



<p>Follow the <a href=\"https://make.wordpress.org/core/\">Make/Core</a> blog if you wish to contribute to Twenty Twenty One. There will be weekly meetings every Monday at 15:00 UTC and triage sessions every Friday at 15:00 UTC in the #core-themes Slack channel. Theme development will happen <a href=\"https://github.com/wordpress/twentytwentyone.\">on GitHub</a>. </p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>WordPress plugin authors can now <a href=\"https://meta.trac.wordpress.org/changeset/10255\">opt into confirming plugin updates via email</a>. This feature will allow plugin authors to approve any plugin updates over email before release.</li><li>September was the busiest month for online WordCamps so far, with seven events taking place: <a href=\"https://ogijima.wordcamp.org/2020/\">WordCamp Ogijima Online</a>, <a href=\"https://colombia.wordcamp.org/2020/\">WordCamp Colombia Online</a>, <a href=\"https://2020.asheville.wordcamp.org/2020/\">WordCamp Asheville, NC USA</a>, <a href=\"https://saopaulo.wordcamp.org/2020/\">WordCamp São Paulo, Brazil</a>, <a href=\"https://2020.virginiabeach.wordcamp.org/\">WordCamp Virginia Beach</a>, <a href=\"https://2020.lima.wordcamp.org/\">WordCamp Lima Peru</a>, and <a href=\"https://philadelphia.wordcamp.org/2020/\">WordCamp Philadelphia, PA, USA</a>. You can find live stream recaps of these events on their websites. The camps are also in the process of uploading their videos to <a href=\"https://wordpress.tv/\">WordPress.tv</a>. Check out the <a href=\"https://central.wordcamp.org/schedule/\">WordCamp Schedule</a> to follow upcoming online WordCamps!</li><li>The Themes team has added a <a href=\"https://meta.trac.wordpress.org/changeset/10240\">delist feature</a> to the themes directory. The feature will allow a theme to be temporarily hidden from search, while still making it available. The team may delist themes if they violate the <a href=\"https://make.wordpress.org/themes/handbook/review/required/\">Theme Directory guidelines</a>. </li><li>The Themes Team has also released its <a href=\"https://make.wordpress.org/themes/2020/09/25/new-package-to-allow-locally-hosting-webfonts/\">new web fonts Loader project</a>. The webfonts loader will allow theme developers to load web fonts from the user’s site, rather than through a third-party CDN. The project lives in the team’s <a href=\"https://github.com/WPTT/webfont-loader\">GitHub repository</a>.</li><li>The Support team is discussing<a href=\"https://make.wordpress.org/support/2020/09/talking-point-allowing-self-archival-of-topics/\"> the level of control users should have</a> over their support forum topics. The team is thinking of allowing users to archive their topics and lengthen time-to-edit to remove any semi-sensitive data. In a separate, but related, post, Support team members have started discussing <a href=\"https://make.wordpress.org/support/2020/09/talking-point-handling-support-for-commercial-users-on-the-wordpress-forums/\">how to curb support requests for commercial products</a>.</li><li>The Mobile team <a href=\"https://make.wordpress.org/core/2020/09/21/proposal-dual-licensing-gutenberg-under-gpl-v2-0-and-mpl-v2-0/\">came up with a proposal for dual licensing Gutenberg</a> under GPL 2.0 and MPL (Mozilla Public License) 2.0, so that non-WordPress software developers can potentially use it for their projects.  </li><li>Since Facebook and Instagram are deprecating oEmbeds, the Core Team <a href=\"https://make.wordpress.org/core/2020/09/22/facebook-and-instagram-embeds-to-be-deprecated-october-24th/\">will be removing Facebook and Instagram’s oEmbed endpoints</a> from WordPress core code. </li><li>Following extensive discussion, the Documentation team <a href=\"https://make.wordpress.org/docs/2020/09/14/external-linking-policy-meeting-notes-august-25th/\">has tentatively decided to allow external and commercial links in the WordPress documentation</a>. The team aims to publish a formal proposal that will be left open for feedback before finalizing it.</li><li>Members of the Polyglots and Marketing teams are celebrating the <a href=\"https://make.wordpress.org/polyglots/2020/09/09/lets-celebrate-international-translation-day-together/\">International Translation Day</a> for WordPress over the week of September 28 &#8211; October 4! Community members can join or organize translation events, or contribute to WordPress core, theme, or plugin translations during this period. </li><li><a href=\"https://wpaccessibilityday.org/\">WP Accessibility day</a> — a 24-hour global online event dedicated to addressing website accessibility in WordPress, is being held on October 2. The event is open for all and has <a href=\"https://wpaccessibilityday.org/#talk-time\">experts from all over the world as speakers</a>.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Oct 2020 09:34:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: Cloudflare Launches New Web Analytics Product Focusing on Privacy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105446\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/cloudflare-launches-new-web-analytics-product-focusing-on-privacy?utm_source=rss&utm_medium=rss&utm_campaign=cloudflare-launches-new-web-analytics-product-focusing-on-privacy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2448:\"<p>In pursuit of &ldquo;<a href=\"https://www.cloudflare.com/web-analytics/\">democratizing web analytics</a>,&rdquo; Cloudflare announced it is launching privacy-first analytics as a new standalone product. The company is entering a market that has been <a href=\"https://www.datanyze.com/market-share/web-analytics--1/Alexa%20top%201M\">dominated by Google Analytics</a> for years but with a major differentiating feature &ndash; it will not track individual users by a cookie or IP address to show unique visits.</p>



<p>Cloudflare Web Analytics defines a visit as &ldquo;a successful page view that has an&nbsp;<a rel=\"noreferrer noopener\" href=\"https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer\" target=\"_blank\">HTTP referer</a>&nbsp;that doesn&rsquo;t match the hostname of the request.&rdquo; It&rsquo;s not the same as Google&rsquo;s &ldquo;unique&rdquo; metric, and Cloudflare says it may differ from other reporting tools. Weeding out bots from the total traffic numbers is a nascent feature that Cloudflare is improving as part of its&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.cloudflare.com/products/bot-management/\" target=\"_blank\">Bot Management product</a>.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Cloudflare Web Analytics is launching with features that are largely similar to Google Analytics but with some unique ways of zooming into different traffic segments and time ranges to see where traffic is originating from. </p>



<p>&ldquo;The most popular analytics services available were built to help ad-supported sites sell more ads,&rdquo; Cloudflare product manager Jon Levine said. &ldquo;But, a lot of websites don&rsquo;t have ads. So if you use those services, you&rsquo;re giving up the privacy of your users in order to understand how what you&rsquo;ve put online is performing.</p>



<p>&ldquo;Cloudflare&rsquo;s business has never been built around tracking users or selling advertising. We don&rsquo;t want to know what you do on the Internet &mdash; it&rsquo;s not our business.&rdquo;</p>



<p>Paying customers on the Pro, Biz, and Enterprise plans can access their analytics from their dashboards immediately. Cloudflare is also offering the product for free as JavaScript-based analytics for users who are not currently customers. Those who want access to the free plan can sign up for the <a href=\"https://www.cloudflare.com/web-analytics/\">waitlist</a>. </p>



<p> </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Oct 2020 04:03:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: Virtual WordPress Page Builder Summit Kicks Off October 5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105570\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:179:\"https://wptavern.com/virtual-wordpress-page-builder-summit-kicks-off-october-5?utm_source=rss&utm_medium=rss&utm_campaign=virtual-wordpress-page-builder-summit-kicks-off-october-5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6348:\"<p class=\"has-drop-cap\">From October 5 through October 9, the first <a href=\"https://summit.camp/\">Page Builder Summit</a> will open its virtual doors to all attendees for free. Nathan Wrigley, the podcaster behind WP Builds, and Anchen le Roux, the founder and lead developer of Simply Digital Design, are hosting the five-day online event that focuses on the vast ecosystem of page builders for WordPress.</p>



<p>The summit will include 35 sessions spread out over the <a href=\"https://summit.camp/schedule/\">event schedule</a>. Each session will last around 30 minutes, so it will be easy to pop in and watch one in your downtime. Sessions will cover a range of builders, including the default WordPress block editor, Elementor, Beaver Builder, Oxygen, Brizy, and Divi.</p>



<p>&ldquo;It&rsquo;s an event specifically for users of WordPress page builders, or those curious about what they can do,&rdquo; said Wrigley. &ldquo;I feel like a page builder style interface for creating websites is the future for our industry. WordPress itself is moving in this direction with the block editor (a.k.a. Gutenberg). With that in mind, it seemed like a good idea to create a dedicated event to share knowledge about this side of WordPress. We&rsquo;ve tried to include presentations from as many page builders as we could.&rdquo;</p>



<p>Wrigley made sure to point out that it is not all geared toward developers, discussing the inner-workings of builders. Some of the sessions focus on marketing, optimization, and conversion, which provides a wider range of topics for potential attendees.</p>



<p>The summit hosts created an <a href=\"https://summit.camp/page-builder-quiz/\">online quiz</a> for those who are unsure about which sessions to watch.</p>



<p>There is a small catch. The sessions will be freely available only from the time they begin and the following 24 hours. After that, accessing the videos will come at a premium. Attendees can gain lifetime access to the PowerPack for $47 if they purchase within 15 minutes of signing up. Then, prices will rise to $97 until the event kicks off on October 5. Beyond, the price jumps to $147. The lifetime access includes access to the presentations, transcripts, a workbook, and other bonuses from the speakers.</p>



<p>For those unsure about forking over the cash, they can still watch the sessions during the 24-hour window.</p>



<p>The proceeds from the event will go out to paying affiliate commissions to speakers and partners. Some of it will go into planning and investing in a second summit down the road.</p>



<p>&ldquo;Both myself and Nathan have specific charities that we want to donate to after the event,&rdquo; said le Roux. &ldquo;It was part of our goals to be able to do this, but we didn&rsquo;t want to make this an <em>official contribution</em>.&rdquo;</p>



<h2>Why a Page Builder Summit?</h2>



<p class=\"has-drop-cap\">Both Wrigley and le Roux have their preferred builders. But, the goal of the summit is to offer a wide look at the tools available and help freelancers and agencies better streamline their businesses and create happier clients.</p>



<p>&ldquo;I&rsquo;ve been a user of page builders for many years, but only at the point where they truly showed in the editing interface something that almost perfectly reflected what the end-user would see did I get really immersed,&rdquo; said Wrigley. &ldquo;Having come from a background in which I built entire websites from a collection of text files (HTML, CSS, PHP, etc.), I was fascinated that we&rsquo;d reached a point where the learning curve for building a good website was significantly reduced.&rdquo;</p>



<p>He pointed out that it is not always so simple though. While the same level of coding skills may not be necessary, people must figure out how to navigate their preferred page builder, which can come with its own learning curve.</p>



<p>&ldquo;You need to learn their way of doing things and how to achieve your design choices,&rdquo; he said. &ldquo;It&rsquo;s always going to work out better if you know the code, but the WordPress mission of democratizing publishing certainly seems to align quite nicely with the adoption of tools, like page builders, which mean that once-difficult tasks are now easier.&rdquo;</p>



<p>For le Roux, her interest in hosting the Page Builder Summit falls back to her design studio.</p>



<p>&ldquo;As a developer, my main reason for switching to page builders was around streamlining and creating more efficient but quality websites in the shortest amount of time,&rdquo; she said. &ldquo;Especially now that we focus on day rates, creating the best possible website that clients would love fast would not have been possible without page builders.&rdquo;</p>



<h2>The Hosts&rsquo; Go-To Builders</h2>



<p>&ldquo;We prefer using Beaver Builder with Themer at Simply Digital Design,&rdquo; said le Roux. &ldquo;We use Gutenberg for blog posts or where possible with custom post types or LMS software. However, we&rsquo;ve also taken on a few Elementor projects where that&rsquo;s the client&rsquo;s preferred option.&rdquo;</p>



<p>Wrigley uses some of the same tools. His main work is on the WP Builds website where he hosts podcasts.</p>



<p>&ldquo;I have used Beaver Builder&rsquo;s Themer to create templates for specific layouts, but for content creation within those layouts I&rsquo;m using the block editor,&rdquo; said Wrigley. &ldquo;My content is mainly text and the WordPress editor is utterly remarkable in this situation. I kept the classic editor installed for a few months after WordPress 5.0 came about, but I soon realized that this was folly and that the editing interface of Gutenberg is superior. The ability to insert and move text, buttons, etc. is such a joy to work with, and the iterations that have been made in the last two years make it, in my opinion, the best text editing experience on the web.&rdquo;</p>



<p>Wrigley sees a future in which the WordPress block editor takes over much of the work that page builders are currently handling. However, that future is &ldquo;still over the horizon.&rdquo;</p>



<p>&ldquo;I&rsquo;m excited about this future though, and we&rsquo;ve got a few crystal ball-gazing presentations; trying to work out what that future might look like,&rdquo; he said.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Oct 2020 20:31:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"WPTavern: Jetpack 9.0 to Introduce New Feature for Publishing WordPress Posts to Twitter as Threads\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105448\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:243:\"https://wptavern.com/jetpack-9-0-to-introduce-new-feature-for-publishing-wordpress-posts-to-twitter-as-threads?utm_source=rss&utm_medium=rss&utm_campaign=jetpack-9-0-to-introduce-new-feature-for-publishing-wordpress-posts-to-twitter-as-threads\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3318:\"<p>Jetpack 9.0, coming on October 6, will debut a new feature that allows users to <a href=\"https://github.com/Automattic/jetpack/pull/16699\">share blog posts as Twitter threads</a> in multiples tweets. A recent version of Jetpack introduced the ability to import and <a href=\"https://wptavern.com/jetpack-8-7-adds-new-tweetstorm-unroll-feature-improves-search-customization\">unroll tweetstorms for publishing inside a post</a>. The 9.0 release will run it back the other way so the content originates in WordPress, yet still reaps all the same benefits of circulation on Twitter as a thread. </p>



<p>The new Twitter threads feature is being added as part of Jetpack&rsquo;s Publicize module under the Twitter settings.  After linking up a Twitter account, the Jetpack sidebar options for Publicize allow users to publish to Twitter as a link to the blog or a set of threaded tweets. It&rsquo;s not just limited to text content &ndash; the threads feature will also upload and attach any images and videos included in the post. </p>



<img />



<p>When first introduced to the idea of publishing a Twitter thread from WordPress, I wondered if threads might lose their trademark pithy punch, since users aren&rsquo;t forced to keep each segment to the standard length of a tweet. Would each tweet be separated in an odd, unreadable way? The Jetpack team anticipated this, so the thread option adds more information to the block editor to show where the paragraphs will be split into multiple tweets.</p>



<p>&ldquo;Threads are wildly underused on Twitter,&rdquo; Gary Pendergast said in a <a href=\"https://pento.net/2020/09/29/more-than-280-characters/\">post</a> introducing the feature. &ldquo;I think a big part of that is the UI for writing threads: while it&rsquo;s suited to writing a thread as a series of related tweet-sized chunks, it doesn&rsquo;t lend itself to writing, revising, and editing anything more complex.&rdquo; The tool Pendergast has been working on for Jetpack gives users the best of both worlds.</p>



<p>In response to a comment requesting Automattic &ldquo;concentrate on tools to get people off social media,&rdquo; Pendergast said, &ldquo;If we&rsquo;re also able to improve the quality of conversations on social media, I think it&rsquo;d be remiss of us to not do so.&rdquo; He also credits IndieWeb discussions on&nbsp;<a href=\"https://indieweb.org/tweetstorm\">Tweetstorms</a>&nbsp;and&nbsp;<a href=\"https://indieweb.org/POSSE\">POSSE</a> (Publish (on your) Own Site,&nbsp;Syndicate&nbsp;Elsewhere) as inspirations for the feature.</p>



<p>For years, blogging advocates have tried to convince those who post lengthy tweetstorms to switch to a publishing medium that is more suitable to the length of their thoughts. The problem is that Twitter users lose so much of the immediate feedback and momentum that their thoughts would have generated when composed as a tweetstorm.</p>



<p>Instead of lecturing people about how they should really be blogging instead of tweetstorming, Jetpack is taking a fresh approach by enabling full content ownership with effortless social syndication. You can test out the experience for yourself by adding the <a href=\"https://jetpack.com/download-jetpack-beta/\">Jetpack Beta Testers</a> plugin and running the 9.0 RC version on your site.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Oct 2020 02:56:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Ask the Bartender: How To WordPress in a Block World?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105491\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:167:\"https://wptavern.com/ask-the-bartender-how-to-wordpress-in-a-block-world?utm_source=rss&utm_medium=rss&utm_campaign=ask-the-bartender-how-to-wordpress-in-a-block-world\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9755:\"<blockquote class=\"wp-block-quote\"><p>I love your articles. And now, in the middle of the WordPress revolution, I realized I&rsquo;m constantly searching for an answer regarding WP these days.</p><p>So many things are being said, so many previsions of the future, problems, etc., but, right now, I think I, as a designer, just want to understand one thing that seemed answered already but it&rsquo;s never clear:</p><p>Is WordPress a good choice to build a client&rsquo;s template where he just has to insert the info that will show in the frontend where I want to? And he doesn&rsquo;t have to worry about formatting blocks? I love blocks, don&rsquo;t get me wrong, but will normal templating end?</p><p>I just think that having a super CMS, HTML, CSS, and being able to play with a database with ACF is so powerful, that I&rsquo;m wondering if it&rsquo;s lost. After so much reading, I still don&rsquo;t understand if this paradigm is going to disappear.</p><p>Right now, I don&rsquo;t know if it&rsquo;s best to stop making websites as I used to and adopt block patterns instead.</p><cite>Ricardo</cite></blockquote>



<p class=\"has-drop-cap\">WordPress is definitely changing. Over the past two years, we have seen much of it reshaped into something different from the previous decade and more. However, this is not new. WordPress has always been a constantly-changing platform. It just feels far too different this time around, almost foreign to many. The platform had to make a leap. Otherwise, it would have started falling behind.</p>



<p>And, it is a big <em>ask</em> of the existing community to come along with it, to take that leap together.</p>



<p>It can be scary as a developer whose livelihood has depended on things working a certain way or who has built tools and systems around pre-block WordPress. Many freelancers and agencies had their world turned upside down with the launch of the block editor. It is perfectly OK to feel a bit lost.</p>



<p>Now, it is time for a little tough love. It has been two years. As a professional, you need to have a plan in place already. Whether that is an educational plan for yourself or a transitional plan for your clients, you should already be tackling projects that leverage the block editor. If you are at a point where you have not been building with blocks, you are now behind. However, you can still catch up and continue advancing in your WordPress career.</p>



<p>There are so many changes coming down the pipeline that anyone who plans to develop for WordPress will be in continual education mode for years to come.</p>



<p>When building for clients, the biggest thing to remember is that it is not about you. It is about getting something into the hands of your clients that addresses their specific needs. Freelancers and agencies need to often be the Jacks and Jills of all trades. Sometimes, this even means having a backup CMS or two that you can use that are not named WordPress. It helps to be well-rounded enough to jump around when needed, especially if you are not at a point in your career where you can demand specific work and pass on jobs that would put food on the table.</p>



<p>It is also easy to look at every job as a nail and WordPress as the hammer. Or, even specific plugins as the tool that will always get the job done. I have seen developers in the past rely on tools like ACF, CMB2, or Meta Box but could not code a custom metadata solution when necessary to save their life.  Sometimes a bigger toolbox is necessary.</p>



<p>Every WordPress developer needs a solid, foundational understanding of the languages that WordPress uses. Gone are the days of skating by on HTML, CSS, and PHP knowledge. You need to learn JavaScript deeply. Matt Mullenweg, the co-founder of WordPress, was not joking around when he <a href=\"https://wptavern.com/state-of-the-word-2015-javascript-and-api-driven-interfaces-are-the-future-of-wordpress\">said this back in 2015</a>. It holds true more and more each day. In another five years, it will tough to be a developer in the WordPress world without knowing JavaScript, at least for backend work.</p>



<p>It also depends on what types of sites you are building. If you are primarily handling front-end design, you will likely be able to get by with a lower skill level. You will just need to know the &ldquo;WordPress way&rdquo; of building themes.</p>



<p>Within the next year, you should be able to build just about any theme design with decent CSS and HTML knowledge along with an understanding of how the block system works. Full-site editing and block-based themes will change how we build the front end of the web. It is going to be a challenging transition at first, especially for those of us who are steeped in traditional theme development, but client sites will often be far easier to build.  I highly recommend the twice-monthly <a href=\"https://make.wordpress.org/themes/\">block-based themes meetings</a> if your focus is on the front end.</p>



<h2>Block Templates</h2>



<p class=\"has-drop-cap\">Based on your question, I am going to make some assumptions. You have a history of essentially building out meta boxes via ACF where the client just pops in their data. Then, you format that data on the front end. You are likely mixing this with custom post types (CPTs). This is a fairly common scenario.</p>



<p>One of the great things about the block system is that you can lock the post editor for individual CPTs. WordPress already has you covered with its <a href=\"https://developer.wordpress.org/block-editor/developers/block-api/block-templates/\">block templates feature</a>, which allows you to define just what a post should look like. You can set up which blocks you want to appear and have the client drop their content in. At the moment, this feature is limited to the post type level. However, it should grow more robust over time, particularly when it works alongside the traditional &ldquo;page templates&rdquo; system.</p>



<p>Block templates are a powerful tool in the ol&rsquo; toolbox that will come in handy when building client sites.</p>



<h2>Block Patterns</h2>



<p class=\"has-drop-cap\">You do not have to stop making websites as you are accustomed to at the moment. However, you should start leveraging new block features as they become available and make sense for a specific project. I am a fanatic when it comes to <a href=\"https://wptavern.com/block-patterns-will-change-everything\">block patterns</a>, so my bias will definitely show.</p>



<p>The biggest thing with block patterns and clients is education. For the uninitiated, you will need to spend some time teaching them how to insert a pattern and how it can be used to their advantage. That is the hurdle you must jump.</p>



<p>For many of the users that I have seen introduced to well-designed patterns, they have fallen in love with the feature. Even many who were reluctant to switch to the block editor became far more comfortable working with it after learning how patterns worked. This is not the case for every user or client, but it has been a good introduction point to the block editor for many.</p>



<p>To answer your question regarding patterns: yes, you should absolutely begin to adopt them.</p>



<h2>ACF Is Evolving</h2>



<p class=\"has-drop-cap\">Because you are accustomed to ACF, you should be aware that the framework is evolving to keep up with the block editor. <a href=\"https://wptavern.com/advanced-custom-fields-5-8-0-introduces-acf-blocks-a-php-framework-for-creating-gutenberg-blocks\">Version 5.8.0</a> introduced a PHP framework for creating custom blocks over a year ago. And, it has been improving ever since. There are even projects like <a href=\"https://wptavern.com/acf-blocks-provides-assortment-of-blocks-built-from-advanced-custom-fields-pro\">ACF Blocks</a>, which will provide even more tools for your arsenal.</p>



<p>It is important to learn from what some of the larger agencies are doing. Read up on how <a href=\"https://webdevstudios.com/2020/09/08/gutenberg-first/\">WebDevStudios is tackling block development</a>. The company also has an open-source <a href=\"https://github.com/WebDevStudios/wds-acf-blocks\">block library</a> for ACF.</p>



<h2>Solving Problems</h2>



<p class=\"has-drop-cap\">Your job as a developer is to be a problem solver. Whatever system you are building with is merely a part of your toolset. You need to be able to solve issues regardless of what tool you are using. At the end of the day, it is just code. If you can learn HTML, you can learn CSS. If you can learn those, you can learn PHP. And, if you can manage PHP, you can certainly pick up JavaScript.</p>



<p>A decade or two from now, you will need to learn something else to stay relevant in your career. Web technology changes. You must change with it. Always consider yourself a student and continue your education. Surround yourself and learn from those who are more advanced than you. Emulate, borrow, and steal good ideas. Use what you have learned to make them great.</p>



<p>There is no answer I can give that will be perfect for every scenario. Each client is unique, and you will need to decide the best direction for each.</p>



<p>However, yes, you should already be on the path to building with a block-first mindset if you plan to continue working with WordPress for the long haul. Immerse yourself in the system. Read, study, and build something any chance you get.</p>



<p class=\"has-white-color has-blue-700-background-color has-text-color has-background text-white bg-blue-700\">This is the first post in the Ask the Bartender series.  Have a question of your own? <a href=\"https://wptavern.com/contact-me/ask-the-bartender\">Shoot it over</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 30 Sep 2020 20:35:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: Supercharge the Default WordPress Theme With Twentig, a Toolbox for Twenty Twenty\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105344\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:225:\"https://wptavern.com/supercharge-the-default-wordpress-theme-with-twentig-a-toolbox-for-twenty-twenty?utm_source=rss&utm_medium=rss&utm_campaign=supercharge-the-default-wordpress-theme-with-twentig-a-toolbox-for-twenty-twenty\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6455:\"<img />Custom page pattern from the Twentig plugin.



<p class=\"has-drop-cap\">I am often on the hunt for those hidden gems when it comes to block-related plugins. I like to see the interesting places that plugin authors venture. That is why it came as a surprise when <a href=\"https://twitter.com/Gtarafdarr/status/1310240580140556290\">someone recommended</a> I check out the <a href=\"https://wordpress.org/plugins/twentig/\">Twentig plugin</a> a few days ago. Somehow, it has flown under my radar for months. And, it has managed to do this while being one of the more interesting plugins for WordPress I have seen in the past year.</p>



<p>Twentig is a plugin that essentially gives superpowers to the default Twenty Twenty theme.  Diane and Yann Collet are the sibling co-founders and brains behind the plugin.</p>



<p>While I have been generally a fan of Twenty Twenty since it was <a href=\"https://wptavern.com/twenty-twenty-bundled-in-core-beta-features-overview\">first bundled in core</a>, it was almost a bit of a letdown in some ways. It was supposed to be the theme that truly showcased what the block editor could do &mdash; and it does a fine job of styling the default blocks &mdash; but there was a lot of potential left on the table. The Twentig plugin turns Twenty Twenty into something worthier of a showcase for the block editor. It is that missing piece, that extra mile in which WordPress should be marching its default themes.</p>



<p>While the new <a href=\"https://wptavern.com/first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme\">Twenty Twenty-One</a> default theme is just around the corner, Twentig is breathing new life into the past year&rsquo;s theme. The developers behind the plugin are still fixing bugs and bringing new features users.</p>



<p>Of its 34 reviews on WordPress.org, Twentig has earned a solid five-star rating. That is a nice score for a plugin with only 4,000 active installations. As I said, it has flown under the radar a bit, but the users who have found it have obviously discovered something that adds those extra touches to their sites they need.</p>



<h2>What Does Twentig Do?</h2>



<p class=\"has-drop-cap\">It is a toolbox for Twenty Twenty. The headline feature is its block editor features, such as custom patterns and page layouts. It also offers a slew of customizer options that allow end-users to put their own design spin on the default theme. However, my interest is primarily in how it extends the block editor. </p>



<p>Let&rsquo;s get this out of the way up front. Twentig&rsquo;s one downside is that it adds a significant amount of additional CSS on top of the already-heavy Twenty Twenty and block editor styles. I will blame the current lack of a full design system from WordPress on most of this. Styling for the block editor can easily bloat a stylesheet. Adding an extra 100+ kb per page load might be a blocker for some who would like to try the plugin. Users will need to weigh the trade-offs between the additional features and the added page size.</p>



<p>The thing that makes Twentig special is its extensive patterns and pages library, which offers one-click access to hundreds of layouts specifically catered to the Twenty Twenty theme.</p>



<img />Inserting one of the hero patterns.



<p>It took me a few minutes to figure out how to access the patterns &mdash; mainly because I did not read the manual. I expected to find them mixed in with the core patterns inserter. However, the plugin adds a new sidebar panel to the editor, which users can access by clicking the &ldquo;tw&rdquo; icon. After seeing the list of options, I can understand why they probably would not fit into WordPress&rsquo;s limited block and patterns inserter UI.</p>



<p>It would be easier to list what the plugin does not have than to go through each of the custom patterns and pages.</p>



<p>The one thing that truly sets this plugin apart from the dozens of other block-library types of plugins is that there are no hiccups with the design. Almost every similar plugin or tool I have tested has had CSS conflicts with themes because they are trying to be a tool for every user. Twentig specifically targets the Twenty Twenty theme, which means it does not have to worry about whether it looks good with the other thousands of themes out there. It has one job, which is to extend its preferred theme, and it does it with well-designed block output.</p>



<p>The other aspect of this is that it does not introduce new blocks. Every pattern and page layout option uses the core WordPress blocks, which includes everything from hero sections to testimonials to pricing tables to event listings.  And more.</p>



<p>Twentig does not stop adding features to the block editor with custom patterns. The useful and sometimes fun bits are on the individual block level, and I have yet to explore everything. I continue to discover new settings each time I open my editor.</p>



<p>Whether it is custom pullquote styles, a photo image frame, or an inner border tweak to the Cover block (shown below), the plugin adds little extras that push what users can do with their content.</p>



<img />Inner border style for the Cover block.



<p>Each block also gets some basic top and bottom margin options, which comes in handy when laying out a page. At this point, I am simply looking forward to discovering features I have yet to find.</p>



<h2>Areas Themes Should Explore</h2>



<p class=\"has-drop-cap\">One of the things I dislike about many of these features being within the Twentig plugin is that I would like to see them within the Twenty Twenty theme instead. Obviously not every feature belongs in the theme &mdash; some features firmly land in plugin territory. The default WordPress themes should also leave some room for plugin authors to explore. But, shipping some of the more prominent patterns and styles with Twenty Twenty would make a more robust experience for the average end-user looking to get the most out of blocks.</p>



<p>Block patterns were not a core WordPress feature when Twenty Twenty landed. However, for the upcoming Twenty Twenty-One theme, which is expected to bundle some unique patterns, the design team should explore what the Twentig plugin has brought to the current default. That is the direction that theme development should be heading, and theme developers can learn a lot by <s>stealing</s> borrowing from this plugin.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 29 Sep 2020 22:00:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"WPTavern: Coming in Jetpack 9.0: Shortcode Embeds Module Updated to Handle Facebook and Instagram oEmbeds\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105381\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:253:\"https://wptavern.com/coming-in-jetpack-9-0-shortcode-embeds-module-updated-to-handle-facebook-and-instagram-oembeds?utm_source=rss&utm_medium=rss&utm_campaign=coming-in-jetpack-9-0-shortcode-embeds-module-updated-to-handle-facebook-and-instagram-oembeds\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2938:\"<p>Facebook and Instagram are&nbsp;<a href=\"https://wptavern.com/upcoming-api-change-will-break-facebook-and-instagram-oembed-links-across-the-web-beginning-october-24\">dropping unauthenticated oEmbed support</a>&nbsp;on October&nbsp;24. WordPress will be removing both Facebook and Instagram as oEmbed providers in an upcoming release. After evaluating third-party solutions, WordPress VIP is <a href=\"https://lobby.vip.wordpress.com/2020/09/28/updates-and-recommendations-facebook-and-instagram-changing-oembed-to-require-authentication/\">recommending</a> its partners enable Jetpack&rsquo;s <a href=\"https://jetpack.com/support/shortcode-embeds/\">Shortcode Embeds</a> module. Jetpack will be shipping the update in its <a href=\"https://github.com/Automattic/jetpack/milestone/166\">9.0 release</a>, which is anticipated to land prior to the October 24th deadline.</p>



<p>The module is being <a href=\"https://github.com/Automattic/jetpack/pull/16814\">updated</a> to provide a seamless transition for users who might otherwise be negatively impacted by Facebook&rsquo;s upcoming API change. WordPress contributors have run some simulations but are not yet sure what will happen to the display for previously embedded content.</p>



<p>&ldquo;It is possible that they change the contents of the JS file to manipulate cached embeds, perhaps to display a warning that the site is using an old method to embed content or that the request is not properly authenticated,&rdquo; Jonathan Desrosiers commented on the trac <a href=\"https://core.trac.wordpress.org/ticket/50861#comment:35\">ticket</a> for removing the oEmbed providers.</p>



<p>WordPress.com VIP roughly outlined what users can expect if they do not enable a solution to begin authenticating oEmbeds:</p>



<blockquote class=\"wp-block-quote\"><p>By default, WordPress caches oEmbed contents in post metadata. These embeds will continue to display in previously-published content.&nbsp;If you edit older posts in the Block Editor, regardless of whether you update the post by saving changes, the embeds in the post will no longer be cached and will stop displaying.&nbsp;If you view these older posts using the Classic Editor, so long as the post is not re-saved, the embeds will continue to function and display properly. If you update the post content, the embed will cease functioning unless you have a mitigation installed.</p></blockquote>



<p>Although WordPress VIP recommends using the Jetpack module as the best solution, self-hosted WordPress users may want to investigate other options if they are not already using Jetpack. <a href=\"https://wordpress.org/plugins/oembed-plus/\">oEmbed Plus</a> is a free plugin created specifically for solving the problem of WordPress dropping Facebook and Instagram as oEmbed providers but it is more work to set up and configure. It requires users to register as a Facebook developer and create an app to get API credentials.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 29 Sep 2020 21:18:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WPTavern: W3C Selects Craft CMS for Redesign Project\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105265\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://wptavern.com/w3c-selects-craft-cms-for-redesign-project?utm_source=rss&utm_medium=rss&utm_campaign=w3c-selects-craft-cms-for-redesign-project\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9407:\"<p>W3C has <a href=\"https://w3c.studio24.net/docs/cms-selection-report/\">selected Craft CMS</a> over Statamic for its redesign project, after <a href=\"https://wptavern.com/w3c-drops-wordpress-from-consideration-for-redesign-narrows-cms-shortlist-to-statamic-and-craft\">dropping WordPress from consideration</a> in an earlier round of elimination: </p>



<blockquote class=\"wp-block-quote\"><p>In the end, our decision mostly came down to available resources. Craft had already committed to reach AA compliance in Craft 4 (it is currently on version 3.5, the release of version 4 is planned for April 2021). They had also arranged for an external agency to provide them with accessibility issues to tackle weekly. In the end, they decided instead to hire an in-house accessibility specialist to perform assessments and assist the development team in adopting accessibility patterns in the long run.</p><cite><a href=\"https://w3c.studio24.net/docs/cms-selection-report/\">W3C CMS Selection Report</a></cite></blockquote>



<p>Last week we published a <a href=\"https://wptavern.com/w3c-drops-wordpress-from-consideration-for-redesign-narrows-cms-shortlist-to-statamic-and-craft\">post</a> urging W3C to revisit Gutenberg for a fair shake against the proprietary CMS&rsquo;s or consider adopting another open source option. During the selection process, Studio 24, the agency contracted for the redesign, cited its extensive experience with WordPress as the reason for not performing any accessibility testing on more recent versions of Gutenberg. </p>



<p>When asked if the  team contacted anyone from WordPress&rsquo; Accessibility Team during the process or put Gutenberg through the same tests as the proprietary CMS&rsquo;s, Studio 24 founder Simon Jones <a href=\"https://twitter.com/simonrjones/status/1309817109636157440\">confirmed</a> they had not. </p>



<p>&ldquo;No, we only reached out to the two shortlisted CMS&rsquo;s&rdquo; Jones said. &ldquo;I&rsquo;m afraid we didn&rsquo;t have time to do more. We did test GB a few months ago based on editing content &ndash; though it wasn&rsquo;t the only factor in our choice. As an agency we do plan to keep reviewing GB in the future.&rdquo; </p>



<p>In response to our concerns regarding licensing, Jones penned an update titled &ldquo;<a href=\"https://w3c.studio24.net/updates/on-not-choosing-wordpress/\">On not choosing WordPress,</a>&rdquo; which further elaborated on the reasons why the agency was not inclined towards using or evaluating the new editor:</p>



<blockquote class=\"wp-block-quote\"><p>From a business perspective I also believe Gutenberg creates a complexity issue that makes it challenging for use by many agencies who create custom websites for clients; where we have a need to create lots of bespoke blocks and page elements for individual client projects.</p><p>The use of React complicates front-end build. We have very talented front-end developers, however, they are not React experts &ndash; nor should they need to be. I believe front-end should be built as standards-compliant HTML/CSS with JavaScript used to enrich functionality where necessary and appropriate.</p><p>As of yet, we have not found a satisfactory (and profitable) way to build custom Gutenberg blocks for commercial projects.&nbsp;</p></blockquote>



<p>The CMS selection report also stated that W3C needs the CMS to be &ldquo;usable by non-sighted users&rdquo; by the launch date, since some members of the staff who contribute to the website are non-sighted. </p>



<p>Since the most recent version of WordPress was not tested in comparison with the proprietary CMS&rsquo;s, it&rsquo;s unclear how much better they handle accessibility. Ultimately, W3C and Studio 24 were more comfortable moving forward with a proprietary vendor that was able to make certain assurances about the future accessibility of its authoring tool, despite having a smaller pool of contributors.</p>



<p>&ldquo;[I&rsquo;m] also deeply curious since the cursory notes on accessibility for both of the reviewed CMSes seem to highlight a ton of issues like &lsquo;Buttons and Checkboxes are built using div elements&rsquo; or most inputs lacking clear focus styles,&rdquo; Gutenberg technical lead Mat&iacute;as Ventura said. &ldquo;An element like the&nbsp;<em>Calendar</em>&nbsp;for choosing a post date seems entirely inoperable with keyboard on Craft, for example, while WordPress&rsquo; has had significant effort and rounds of feedback poured into that element alone to make it fully operable.&rdquo;</p>



<p>WordPress developer Anthony Burchell commented on how using a relatively new proprietary CMS seemed counter to W3C&rsquo;s stated goal to select an option on the basis of longevity. Craft CMS&rsquo;s continued success is contingent upon its business model and the company&rsquo;s ability to remain profitable. </p>



<p>&ldquo;FOSS have the same opportunity of direct access to developers,&rdquo; Burchell <a href=\"https://twitter.com/antpb/status/1309883204728430593?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1309883204728430593%7Ctwgr%5Eshare_3&ref_url=https%3A%2F%2Fwptavern.com%2Fwp-admin%2Fpost.php%3Fpost%3D105265action%3Dedit\">said</a>. &ldquo;I recognize there are many accessibility shortcomings in popular software, but I think it&rsquo;s more constructive to rally behind and contribute, not use a proprietary CMS that boasts beer budget in their guidelines.&rdquo; </p>



<p>On the other side of the issue, accessibility advocates took the W3C&rsquo;s decision as a referendum on Gutenberg&rsquo;s continued struggles to meet WCAG AA standards. WordPress accessibility specialist Amanda Rush <a href=\"https://www.customerservant.com/w3c-is-prioritizing-accessibility-over-its-open-source-licensing-preferences-why-is-that-a-bad-thing-again/\">said</a> it was &ldquo;nice to see the W3C flip tables over this.&rdquo;</p>



<p>&ldquo;Gutenberg is not mature software,&rdquo; accessibility consultant and WordPress contributor Joe Dolson said in a <a href=\"https://www.joedolson.com/2020/09/the-w3c-drops-wordpress-from-consideration/\">post</a> elaborating on his comments at WPCampus 2020 Online. He emphasized the lack of stability in the project that Studio 24 alluded to when documenting the reasons against using WordPress.</p>



<p>&ldquo;It is still undergoing rapid changes, and has grand goals to add a full-site editing experience for WordPress that almost guarantees that it will continue to undergo rapid changes for the next few years,&rdquo; Dolson said. &ldquo;Why would any organization that is investing a large amount into a site that they presumably hope will last another 10 years want to invest in something this uncertain?&rdquo;</p>



<p>Dolson also said the accessibility improvements he referenced regarding the audit were only a small part of the whole picture.  </p>



<p>&ldquo;They only encompass issues that existed in the spring of 2019,&rdquo; he said. &ldquo;Since then, many features have been added and changed, and those features both resolve issues and have created new ones. The accessibility team is constantly playing catch up to try and provide enough support to improve Gutenberg. And even now, while it is more or less accessible, there are critical features that are not yet implemented. There are entirely new interface patterns introduced on a regular basis that break prior accessibility expectations.&rdquo;</p>



<p>WordPress is also being used by millions of people who are constantly reporting issues to fuel the software&rsquo;s continued refinement, which increases the <a href=\"https://github.com/WordPress/gutenberg/labels/Accessibility%20%28a11y%29\">backlog of issues</a>. Unfortunately, Studio 24 did not properly evaluate Gutenberg against the proprietary CMS&rsquo;s in order to determine if these software projects are in any better shape. </p>



<p>Instead, they decided that Craft CMS&rsquo;s community was more receptive to collaborating on issues without reaching out to WordPress. Given the W3C&rsquo;s stated preference for open source software, WordPress, as the only CMS under consideration with an <a href=\"https://opensource.org/licenses\">OSD-compliant license</a>, should have received the same accessibility evaluation.</p>



<p>&ldquo;I can&rsquo;t make any statements that would be meaningful about the other content management systems under consideration; but if WordPress wants to be taken seriously in environments where accessibility is a legal, ethical, and mission imperative, there&rsquo;s still a lot of work to be done,&rdquo; Dolson said.</p>



<p>Studio 24&rsquo;s evaluation may not have been equitable to the only open source CMS under consideration, but the situation serves to highlight a unique quandary: when using open source software becomes the impractical choice for organizations requiring a high level of accessibility in their authoring tools.</p>



<p>&ldquo;Studio 24 ultimately determined that working with a CMS to make it better was more possible with a smaller, proprietary vendor than with a large open-source project,&rdquo; accessibility advocate Brian DeConinck said. &ldquo;Project leadership would be more receptive, and the smaller community means changes can be made more quickly. That should prompt a lot of soul-searching for&hellip;well, everyone. What does that say about the future of open source?&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 29 Sep 2020 04:56:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Gary: More than 280 characters\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"https://pento.net/?p=5405\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://pento.net/2020/09/29/more-than-280-characters/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5187:\"<p>It&#8217;s hard to be nuanced in 280 characters.</p>



<p>The Twitter character limit is a major factor of what can make it so much fun to use: you can read, publish, and interact, in extremely short, digestible chunks. But, it doesn&#8217;t fit every topic, ever time. Sometimes you want to talk about complex topics, having honest, thoughtful discussions. In an environment that encourages hot takes, however, it&#8217;s often easier to just avoid having those discussions. I can&#8217;t blame people for doing that, either: I find myself taking extended breaks from Twitter, as it can easily become overwhelming.</p>



<p>For me, the exception is Twitter threads.</p>



<h2>Twitter threads encourage nuance and creativity.</h2>



<p>Creative masterpieces like this Choose Your Own Adventure are not just possible, they rely on Twitter threads being the way they are.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Being Beyoncé’s assistant for the day: DONT GET FIRED THREAD <a href=\"https://t.co/26ix05Hkhp\">pic.twitter.com/26ix05Hkhp</a></p>&mdash; green chyna (@CORNYASSBITCH) <a href=\"https://twitter.com/CORNYASSBITCH/status/1142591156884127744?ref_src=twsrc%5Etfw\">June 23, 2019</a></blockquote>
</div>



<p>Publishing a short essay about your experiences in your job can bring attention to inequality.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">DOWNTOWN BROOKLYN: I\'m working arraignments tonight, representing poor New Yorkers who were arrested yesterday on Thanksgiving. <br /><br />It was the coldest Thanksgiving in more than a century. Tonight\'s also bitterly cold, even in the courtroom. I\'m wearing my scarf &amp; coat.</p>&mdash; Rebecca Kavanagh (@DrRJKavanagh) <a href=\"https://twitter.com/DrRJKavanagh/status/1066144860619636736?ref_src=twsrc%5Etfw\">November 24, 2018</a></blockquote>
</div>



<p>And Tumblr screenshot threads are always fun to read, even when they take a turn for the epic (over 4000 tweets in this thread, and it isn&#8217;t slowing down!)</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Tumblr textposts thread, probably?</p>&mdash; we are a family forged in bureaucracy (@ex_aItiora) <a href=\"https://twitter.com/ex_aItiora/status/1165987806621184002?ref_src=twsrc%5Etfw\">August 26, 2019</a></blockquote>
</div>



<p>Everyone can think of threads that they&#8217;ve loved reading.</p>



<p>My point is, threads are wildly underused on Twitter. I think I big part of that is the UI for writing threads: while it&#8217;s suited to writing a thread as a series of related tweet-sized chunks, it doesn&#8217;t lend itself to writing, revising, and editing anything more complex.</p>



<p>To help make this easier, I&#8217;ve been working on a tool that will help you publish an entire post to Twitter from your WordPress site, as a thread. It takes care of transforming your post into Twitter-friendly content, you can just&#8230; write. <img src=\"https://s.w.org/images/core/emoji/13.0.0/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>



<p>It doesn&#8217;t just handle the tweet embeds from earlier in the thread: it handles handle uploading and attaching any images and videos you&#8217;ve included in your post.</p>



<ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><img width=\"3264\" height=\"2448\" src=\"https://pento.net/wp-content/uploads/2018/12/mvimg_20181231_0910291833340677198697139.jpg\" alt=\"A selfie of me feeding a giraffe.\" class=\"wp-image-3608\" /></li><li class=\"blocks-gallery-item\"><img width=\"4000\" height=\"3000\" src=\"https://pento.net/wp-content/uploads/2018/12/GOPR0365.jpg\" alt=\"A selfie of me on an iceberg south of the Antarctic circle.\" class=\"wp-image-3591\" /></li><li class=\"blocks-gallery-item\"><img width=\"3264\" height=\"2448\" src=\"https://pento.net/wp-content/uploads/2018/12/00006IMG_00006_BURST20181002212033_COVER.jpg\" alt=\"A selfie of me with a fire breathing dragon at the Harry Potter themed amusement park in Orlando, Florida.\" class=\"wp-image-3604\" /></li><li class=\"blocks-gallery-item\"><img width=\"1793\" height=\"469\" src=\"https://pento.net/wp-content/uploads/2018/12/48944769_986954175890_2085904447019417600_o.jpg\" alt=\"A panoramic view of sunset over Nairobi National Park.\" class=\"wp-image-3554\" /></li></ul>



<p>All sorts of embeds work, too. <img src=\"https://s.w.org/images/core/emoji/13.0.0/72x72/1f609.png\" alt=\"😉\" class=\"wp-smiley\" /></p>



<div class=\"wp-block-embed__wrapper\">
<div class=\"jetpack-video-wrapper\"></div>
</div>



<p>It&#8217;ll be coming in Jetpack 9.0 (due out October 6), but you can try it now in <a href=\"https://jetpack.com/download-jetpack-beta/\">the latest Jetpack Beta</a>! Check it out and tell me what you think. <img src=\"https://s.w.org/images/core/emoji/13.0.0/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>



<p>This might not fix all of Twitter&#8217;s problems, but I hope it&#8217;ll help you enjoy reading and writing on Twitter a little more. <img src=\"https://s.w.org/images/core/emoji/13.0.0/72x72/1f496.png\" alt=\"💖\" class=\"wp-smiley\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 29 Sep 2020 02:33:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Gary\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"WPTavern: Themes Team Releases a Web Fonts Loader, Likely To Prohibit Hotlinking Any Off-Site Assets\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105363\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:243:\"https://wptavern.com/themes-team-releases-a-web-fonts-loader-likely-to-prohibit-hotlinking-any-off-site-assets?utm_source=rss&utm_medium=rss&utm_campaign=themes-team-releases-a-web-fonts-loader-likely-to-prohibit-hotlinking-any-off-site-assets\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5815:\"<p class=\"has-drop-cap\">Last Friday, the WordPress Themes Team <a href=\"https://make.wordpress.org/themes/2020/09/25/new-package-to-allow-locally-hosting-webfonts/\">announced the release</a> of its new <a href=\"https://github.com/WPTT/webfont-loader\">Webfonts Loader project</a>. It is a drop-in script that allows theme authors to load web fonts from the user&rsquo;s site instead of a third-party CDN. The secondary message included in the team&rsquo;s announcement is that it no longer plans to allow themes to hotlink Google Fonts in the future.</p>



<p>Throughout most of the team&rsquo;s history, it has not allowed themes to hotlink or use CDNs for hosting theme assets, such as CSS, JavaScript, and fonts. The one <a href=\"https://make.wordpress.org/themes/handbook/review/required/#stylesheets-and-scripts\">exception to this rule</a> was the use of Google Fonts. This allowed themes to have richer typography options at their disposal from what the team has generally declared a reliable source.</p>



<p>&ldquo;The exception was made because there was no practical way to not have the exception at the time,&rdquo; said Aria Stathopoulos, a Themes Team representative and developer behind the Webfonts Loader project. &ldquo;The exception for Google Fonts was made out of necessity. Now that there is another way, the exception will not be necessary.&rdquo;</p>



<p>In effect, disallowing the Google Fonts CDN would not be a new ban. It would be a removal of an exception to the existing ban.</p>



<p>Google Fonts has become so embedded into the theme developer toolset over the years, there was no way the team could simply pull the plug and prohibit the use of the CDN overnight. If the Themes Team members wanted to focus more on privacy, they would need to build a tool that made it dead simple for theme authors to use.</p>



<p>There is no hard deadline for when the team will remove the exception for Google Fonts, and it is not set in stone at this point. Stathopoulos said removing it has been the goal from the beginning, disallowing all CDNs. However, it took a while to find an efficient way to handle this. With a viable alternative in place, they can discuss moving forward.</p>



<h2>Webfonts Loader for Themes</h2>



<p class=\"has-drop-cap\">The Webfonts Loader project keeps it simple for theme authors. It introduces a new <code>wptt_get_webfont_styles()</code> function that developers can plug in a stylesheet URL. Once a page is loaded with that function call, it will download the fonts locally to a <code>/fonts</code> folder in the user&rsquo;s <code>/wp-content</code> directory. This way, fonts will always be served from the user&rsquo;s site.</p>



<p>The system is not limited to Google Fonts either. Any URL that serves CSS with an <code>@font-face {}</code> rule will work. It does not currently include authentication for CDNs that require API keys, such as Adobe Fonts. However, that is something the team might add in the future.</p>



<p>&ldquo;For end-users, moving away from CDNs and locally hosting web fonts will improve performance (fewer handshake roundtrips for SSL), and is the privacy-conscious choice,&rdquo; said Stathopoulos. &ldquo;The only &lsquo;valid privacy concern&rsquo; is that the web fonts&rsquo; CDN does not disclose information that is fundamental to the GDPR: what information gets logged, for how long these logs remain, how they are processed, if there is any cross-referencing with all the other wealth of information the company has from users, etc. The concern is a lack of disclosure and information. If a site owner doesn&rsquo;t know what kind of information a third-party logs for its visitors, then they should ethically not enforce that on their visitors. With this package, the CDN is removed from the equation and the font still gets served fast &mdash; if not faster.&rdquo;</p>



<h2>A Path to Core WordPress</h2>



<p class=\"has-drop-cap\">Today, there is now a broader focus on privacy concerns related to third-party resources, particularly with tech giants like Google. Such concerns extend to whether third parties are tracking users or collecting data. Additional concerns are around whether sites are disclosing the use of third-party resources, which may be required in some jurisdictions. Site owners who are often unable to work through the web of potential issues are stuck in the middle.</p>



<p>Jono Alderson opened a ticket to <a href=\"https://core.trac.wordpress.org/ticket/46370\">create an API</a> for loading web fonts locally in core WordPress in February 2019. It is a lengthy and detailed proposal, but it has yet to see much buy-in outside of a handful of developers.</p>



<p>&ldquo;If such a script is standardized and included in WordPress core, one of the main benefits would be more respect for the end-user&rsquo;s privacy,&rdquo; said Stathopoulos. &ldquo;In the end, that&rsquo;s all privacy is about: respecting users.&rdquo;</p>



<p>A standard API like Alderson proposes could solve some issues. Namely, it would virtually eliminate any privacy concerns. However, loading fonts locally could allow WordPress to optimize font loading and would create a shared system where plugins and themes do not load duplicate assets because of the current limitations of the enqueuing system. A standard API would also put the responsibility of efficiently loading fonts on WordPress&rsquo;s shoulders instead of theme and plugin developers.</p>



<p>The Themes Team&rsquo;s new project is a solid start and strengthens the current proposal.</p>



<p>&ldquo;If we&rsquo;re serious about WordPress becoming a fast, privacy-friendly platform, we can&rsquo;t rely on theme developers to add and manage fonts without providing a framework to support them,&rdquo; wrote Alderson in the ticket.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 28 Sep 2020 20:58:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: Fuxia Scholz First to Pass 100K Reputation Points on WordPress Stack Exchange\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105282\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:219:\"https://wptavern.com/fuxia-scholz-first-to-pass-100k-reputation-points-on-wordpress-stack-exchange?utm_source=rss&utm_medium=rss&utm_campaign=fuxia-scholz-first-to-pass-100k-reputation-points-on-wordpress-stack-exchange\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5096:\"<p><a href=\"https://stackexchange.com/users/113787/fuxia\">Fuxia Scholz</a>, a prolific <a href=\"https://wordpress.stackexchange.com/\">WordPress Stack Exchange</a> (WPSE) contributor, is the first member to reach 100,000 reputation points. The popular Q&amp;A community site rewards expert advice by floating the highest quality answers to the top, allowing users to earn reputation points. The gamified help community has proven to be more motivating for developers than many traditional forums, since the upvotes communicate how useful their answers are to others.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Scholz started on Stack Overflow a few months before WordPress had its own site. She wrote around 50 answers and made connections with other WordPress developers ahead of the site&rsquo;s <a href=\"https://area51.stackexchange.com/proposals/1500/wordpress-development\">beta phase in June 2010</a>. Once the site graduated and got its own logo and design, Scholz started writing more.</p>



<p>&ldquo;One core idea for all Stack Exchange sites is gamification: You earn reputation, and you get access to <a href=\"https://wordpress.stackexchange.com/help/privileges\">certain privileges</a>,&rdquo; Scholz said.</p>



<p>&ldquo;You can say I got a bit addicted. My favorite questions were about problems for which I didn&rsquo;t know the answer, and couldn&rsquo;t find one with a search engine, because no one else had solved that before. I used my answers to teach myself, and I learned a lot this way! In May 2011 <a href=\"https://stackexchange.com/users/113787/fuxia?tab=reputation\">my reputation on WPSE was already higher than on Stack Overflow</a>, and for the next years it went up in a steep curve.&rdquo; Ten years after WPSE launched, Scholz has become the first to reach 100,000 reputation points.</p>



<p>&ldquo;What reputation and karma do is send a message that this is a community with norms, it&rsquo;s not just a place to type words onto the internet. (That would be 4chan.)&rdquo; Stack Overflow co-creator Joel Spolsky <a href=\"https://www.joelonsoftware.com/2018/04/13/gamification/\">said</a>. &ldquo;We don&rsquo;t really exist for the purpose of letting you exercise your freedom of speech. You can get your freedom of speech somewhere else. Our goal is to get the best answers to questions. All the voting makes it clear that we have standards, that some posts are better than others, and that the community itself has some norms about what&rsquo;s good and bad that they express through the vote.&rdquo;</p>



<p>The reputation points were originally inspired by Reddit Karma. Spolsky admits that the points not a perfect system but they do tend to &ldquo;drive a tremendous amount of good behavior.&rdquo; Gamification can shape and encourage certain behaviors but Spolsky said it&rsquo;s a weak force that cannot motivate people to do things they are not already interested in doing. For Scholz, it was the community aspect and an earned sense of ownership and responsibility that kept her hooked.</p>



<p>&ldquo;In 2012, the community elected me as a moderator, and that changed a lot,&rdquo; she said. &ldquo;Now it wasn&rsquo;t just a game anymore, it was a duty. I felt responsible for the site. I still do. I also found some friends on there. We met at WordCamps and in private, and worked together on different projects.&rdquo;</p>



<p>Scholz no longer works in development and said she doesn&rsquo;t care about WordPress anymore, but she is still a regular contributor on the WPSE.</p>



<p>&ldquo;I switched careers and work as a writer, translator, and community manager for <a rel=\"noreferrer noopener\" href=\"https://t.co/mIhjlVjPv4?amp=1\" target=\"_blank\">Chess24.com</a> now,&rdquo; she said. &ldquo;But I still care about the site WordPress Stack Exchange! I keep an eye on new tags, handle flagged posts and comments, try to make every new user feel welcome, and I search for people who are abusing the system &mdash; vote fraud and spam. And, very rarely, I even write an answer, because I still know all this stuff. </p>



<p>&ldquo;Checking the site has become a part of my daily routine, like feeding the cat.&rdquo; </p>



<p>This daily habit has snowballed into Scholz racking up more than 2,000 answers. She is getting upvotes on many of her old answers nearly every day, which is what pushed her over the 100k milestone.</p>



<p>&ldquo;There is a lot to say about the way our site developed over the years,&rdquo; Scholz said. &ldquo;I&rsquo;m not happy about some things. The enthusiasm of the early days is gone. We don&rsquo;t have enough regulars, there is no discussion about the site on <a href=\"https://t.co/tlRekl6sOt?amp=1\">WordPress Development Meta Stack Exchange</a>, and our chat, once very active, funny, and friendly, is now almost dead. </p>



<p>&ldquo;Maybe that&rsquo;s normal, I don&rsquo;t know. But it&rsquo;s still &lsquo;my&rsquo; site. Reputation and badges don&rsquo;t really mean anything for a long time now, but keeping the site working, useful and friendly is more important.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 26 Sep 2020 15:27:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: PhotoPress Plugin Seeks to Revolutionize Photography for WordPress Users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=104770\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:209:\"https://wptavern.com/photopress-plugin-seeks-to-revolutionize-photography-for-wordpress-users?utm_source=rss&utm_medium=rss&utm_campaign=photopress-plugin-seeks-to-revolutionize-photography-for-wordpress-users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5638:\"<p class=\"has-drop-cap\">Peter Adams, the owner of the <a href=\"https://wordpress.org/plugins/photopress/\">PhotoPress plugin</a>, announced a couple of weeks ago that <a href=\"https://www.photopressdev.com/its-time-for-photopress/\">now is the time for his project</a> to take center stage. &ldquo;It&rsquo;s Time for PhotoPress,&rdquo; read the title of his post in which he laid out a four-phase plan for the future of his project.</p>



<p>Adams is no stranger to manipulating WordPress to suit the needs of photographers. He described photography as his first love and second career. He initially found the art of taking photos in high school and set off to college to become a professional photographer in the early &rsquo;90s.</p>



<p>As his university graduation loomed, he was recruited to run web development for an internet ad agency that built websites for Netscape, Bill Clinton&rsquo;s White House, and dozens of Fortune 500 companies. He spent the next 15 years starting or running tech companies before returning to his roots as a photographer.</p>



<p>Today, he photographs for various magazines and companies. And, that&rsquo;s where his PhotoPress project comes in.</p>



<p>&ldquo;As far as WordPress has come, it is at risk of losing an entire generation of photographers to photo website services such as Photoshelter, SmugMug, Squarespace, and PhotoFolio,&rdquo; he said. Adams wants to change that, making WordPress the go-to platform for photographers around the world.</p>



<h2>The Jetpack of Photography Plugins</h2>



<p class=\"has-drop-cap\">If you dig into the history of the PhotoPress plugin on WordPress.org, it seems to have a 15-year history. However, this is not the same plugin that was published a decade and a half ago by a different developer. The original plugin is now defunct, and Adams took over when the name was freed up on the directory.</p>



<p>Adams wrote in his announcement post that WordPress has done a great job of delivering several media features over the years. &ldquo;Yet despite that, there are still many rough edges and missing features that keep WordPress from being the first choice for a photographer that needs to publish a beautiful portfolio of their work, put their image catalog/archive online, or showcase a photo editorial/project.&rdquo;</p>



<p>He outlined a list of 10 specific problem areas that he wants to address in a &ldquo;Jetpack-like&rdquo; plugin for photographers. This is the bread and butter of the first of the planned four phases, which he said is about 80% finished. He had originally planned to develop PhotoPress as a series of separate plugins, each addressing a specific problem. Now, it is a single plugin with modules than can be enabled or disabled.</p>



<p>When asked why the &ldquo;right time&rdquo; is now, Adams explained it is because the Gutenberg (block editor) project is a giant leap forward in usability in terms of creating photography blogs.</p>



<img />PhotoPress Gallery block in the editor.



<p>&ldquo;Photogs are a rare breed of non-technical users with high design sense,&rdquo; he said. &ldquo;Things that I used to have to teach photographers to do using shortcode syntax and custom CSS can now be simple controls with live feedback inside a Gutenberg block. It&rsquo;s really a game-changer for getting people comfortable with customizing things like gallery styling &mdash; which is the number one thing photographers need to do.&rdquo;</p>



<p>The primary piece of the PhotoPress plugin is its custom PhotoPress Gallery block. It allows users to choose between a range of gallery styles, such as columns, masonry, justified, and mosaic. Each style has its own options. Images can also be launched into a slideshow when one is clicked.</p>



<p>Based on some quick tests, the block&rsquo;s front-end output will go farther with some themes than others. This is mainly because of conflicting CSS and issues which can be solved by testing against more themes.</p>



<p>Aside from the block, the plugin can automatically extract image metadata and group that data through custom taxonomies, such as cameras, lenses, locations, keywords, and more. WordPress stores this information out of the box, but it is hidden away as post meta. The plugin uses the taxonomy system to make it manageable for end-users.</p>



<p>Ultimately, Adams set out to create a photography plugin that fits in with the WordPress admin user interface and experience, which he has accomplished.</p>



<h2>The Future of PhotoPress</h2>



<p class=\"has-drop-cap\">The project is still a work in progress. Adams is still moving through Phase I of the four-phase plan. Once it is complete, he can move on to the next steps in the process.</p>



<p>Phase II is to create themes that are designed specifically to work with the PhotoPress plugin. He has three planned thus far. One for handling portfolio sites. Another for creating a stock photo archive. And the last for photojournalism and exhibits. Each will be built on top of his <a href=\"https://github.com/photopress-dev/frame\">photography theme framework</a>.</p>



<p>The themes in Phase II will likely be commercial products. Adams said he needs a way to fund the next phases of the project. He hopes to have this step underway by the end of the year.</p>



<p>For 2021, he wants to begin tackling Phases III and IV. The former will be a website-as-a-service (WaaS) similar to WordPress.com but for photographers. It will begin as a paid project but could have some free options for emerging photographers and students. The final phase is to build an onboarding system.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Sep 2020 19:08:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Google Officially Releases Its Web Stories for WordPress Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105227\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:191:\"https://wptavern.com/google-officially-releases-its-web-stories-for-wordpress-plugin?utm_source=rss&utm_medium=rss&utm_campaign=google-officially-releases-its-web-stories-for-wordpress-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5593:\"<img />Web Stories for WordPress dashboard.



<p class=\"has-drop-cap\">Two and a half months after the <a href=\"https://wptavern.com/google-launches-beta-of-amp-powered-web-stories-plugin-for-wordpress\">launch of its public beta</a>, Google <a href=\"https://blog.google/web-creators/create-compelling-web-stories-wordpress/\">released its Web Stories</a> for WordPress plugin. So far, the plugin has over 10,000 active installations and has garnered a solid five-star rating from four reviews.</p>



<p>Google created the Web Stories format through its AMP Project to allow publishers to create visually-rich stories. It is primarily geared toward mobile site visitors, allowing them to quickly jump through story pages with small chunks of content.</p>



<p>The <a href=\"https://wordpress.org/plugins/web-stories/\">Web Stories plugin</a> creates a visual interface within WordPress for creating Stories. It breaks away from the traditional WordPress interface and introduces users to an almost Photoshop-like experience for building out individual Stories. The Stories editor is completely drag-and-drop.</p>



<p>The plugin also offers eight predesigned templates out of the box that cover a small range of niches. However, according to Google&rsquo;s announcement, the company plans to add more templates in future updates.</p>



<h2>Web Stories Are for Storytelling</h2>



<p>&ldquo;Firstly&hellip;the power of Stories,&rdquo; wrote Jamie Marsland, founder of Pootlepress, in a <a href=\"https://twitter.com/pootlepress/status/1309020235102597122\">Twitter thread</a>. &ldquo;Stories are how we (humans) see the world and share our experiences. Up to now the platforms that we have to tell stories have been limited to books/films/tv/websites/blogs/instagram stories etc.&rdquo;</p>



<p>&ldquo;Websites are ok for telling stories but in many ways the format doesn&rsquo;t really fit the linear arc of storytelling. When Marshall McLuhan said &lsquo;the medium is the message&rsquo; in 1964 he was talking about how the medium itself has a social impact, and change the communication itself&hellip;and the possibilities for what is communicated and how it is perceived. But we should keep coming back to Stories. Stories are the key here imo. Now we have an open format to tell Stories, and we have an open platform (WordPress) where those Stories can be told easily.&rdquo;</p>



<p>Marsland finished his thread by saying that using Stories as a replacement for a brochure or website is a missed opportunity. He said that it was a platform for storytelling and should be used as such.</p>



<p>It is far too early to tell if Web Stories will simply be a fad or still in wide use years from now. The technology certainly lends itself well to telling stories, particularly in mobile format, but I doubt we have seen the best of what is possible on the web. The format feels too limited to be the end-all-be-all of storytelling. It is merely one medium that will live and die by its popularity with users.</p>



<p>With the right design skills, some people will craft beautiful Web Stories. And, that is just what Marsland has done with the <a href=\"https://jamiemarsland.staging.wpengine.com/web-stories/wilson-and-pootle/\">first Story he shared</a>:</p>



<img />Page from the Wilson and Pootle Web Story by Jamie Marsland.



<p>I agree with his conclusion. Web Stories should be about storytelling. When you move outside of that zone, the technology feels out of place.</p>



<p>Where I disagree is that websites are not ideal for storytelling. Ultimately, the WordPress block editor will allow artistic end-users to craft intricate stories, mixing content and design in ways that we have not seen. We are just now scratching the surface. I expect our community of developers to build more intricate tools than what the Web Stories plugin currently allows, and we can do so in a way that revolutionizes storytelling on the web.</p>



<h2>New Features</h2>



<img />Story editor with Unsplash photo integration.



<p class=\"has-drop-cap\">The Web Stories plugin now adds support for Unsplash images and Coverr videos out of the box. The plugin adds a new tab with a &ldquo;media&rdquo; icon. For users of the first beta version of the plugin, this may be a bit confusing. The previous media icon was for a tab that displayed the user&rsquo;s media. Now, the user&rsquo;s media is under the tab with the &ldquo;upload&rdquo; icon.</p>



<p>It is also not immediately clear that the Unsplash images and Coverr videos are not hosted on the site itself. There is a &ldquo;powered by&rdquo; notice at the bottom of the tab, but it can be easy to miss because it blends in with the media in the background.</p>



<p>Media from Unsplash and Coverr is hosted off-site and not downloaded to the user&rsquo;s WordPress media library. I could find no mention of this in the plugin&rsquo;s documentation. Such hotlinking was a <a href=\"https://wptavern.com/unsplash-responds-to-image-licensing-concerns-clarifies-reasons-for-hotlinking-and-tracking\">cause for debate</a> over the recent official release of the Unsplash plugin.</p>



<p>Google also announced it planned to add more &ldquo;stock media integrations&rdquo; in the near future. According to a <a href=\"https://docs.google.com/document/d/1q8rkYYMKZh3R2eqkpwgGkx6QX0oSXoLYtIO6ml1BFD0/edit#heading=h.xqcejitqohdk\">document</a> shared via a GitHub <a href=\"https://github.com/google/web-stories-wp/issues/3909#issuecomment-674053068\">ticket</a>, such future integrations may include Google Photos and GIF-sharing site Tenor.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Sep 2020 21:13:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: W3C Drops WordPress from Consideration for Redesign, Narrows CMS Shortlist to Statamic and Craft\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105108\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:255:\"https://wptavern.com/w3c-drops-wordpress-from-consideration-for-redesign-narrows-cms-shortlist-to-statamic-and-craft?utm_source=rss&utm_medium=rss&utm_campaign=w3c-drops-wordpress-from-consideration-for-redesign-narrows-cms-shortlist-to-statamic-and-craft\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11563:\"<p>The <a href=\"https://www.w3.org/\">World Wide Web Consortium</a> (<em>W3C</em>), the international standards organization for the web,&nbsp;is redesigning its website and will soon be selecting a new CMS. Although WordPress is&nbsp;already used to manage W3C&rsquo;s <a href=\"https://www.w3.org/blog/\">blog</a> and <a href=\"https://www.w3.org/blog/news/\">news</a> sections of the website, the organization is open to adopting a new CMS to meet its list of preferences and <a href=\"https://w3c.studio24.net/docs/cms-strategy-and-requirements/\">requirements</a>. </p>



<p>Studio 24, the digital agency selected for the redesign project, narrowed their consideration to three CMS candidates:</p>



<ol><li><a href=\"https://w3c.studio24.net/docs/w3c-cms-selection-process-update/#statamic\">Statamic</a></li><li><a href=\"https://w3c.studio24.net/docs/w3c-cms-selection-process-update/#craft-cms\">Craft CMS</a></li><li><a href=\"https://w3c.studio24.net/docs/w3c-cms-selection-process-update/#wordpress\">WordPress</a></li></ol>



<p>Studio 24 was aiming to finalize their recommendations in July but found that none of them complied with the W3C&rsquo;s authoring tool <a href=\"https://www.w3.org/WAI/standards-guidelines/atag/\">accessibility guidelines</a>. The CMS&rsquo;s that were better at compliance with the guidelines were not as well suited to the other project requirements.</p>



<p>In the most recent project <a href=\"https://w3c.studio24.net/updates/weeknotes-11-sept/\">update</a> posted to the site, Studio 24 reported they have&nbsp;shortlisted two CMS platforms. Coralie Mercier, Head of Marketing and Communications at W3C, confirmed that these include Statamic and Craft CMS.</p>



<p>WordPress was not submitted to the same review process as the Studio 24 team claims to have extensive experience working with it. In the summary of their concerns, Studio 24 cited Gutenberg, accessibility issues, and the fact that the Classic Editor plugin will <a href=\"https://make.wordpress.org/core/2018/11/07/classic-editor-plugin-support-window/\">stop being officially maintained on December 31st, 2021</a>:</p>



<blockquote class=\"wp-block-quote\"><p>First of all, we have concerns about the longevity of WordPress&nbsp;<strong>as we use it</strong>. WordPress released a new version of their editor in 2018: Gutenberg. We have already rejected the use of Gutenberg in the context of this project due to accessibility issues.</p><p>If we choose to do away with Gutenberg now, we cannot go back to it at a later date. This would amount to starting from scratch with the whole CMS setup and theming.</p><p>Gutenberg is the future of WordPress. The WordPress core development team keeps pushing it forward and wants to roll it out to all areas of the content management system (navigation, sidebar, options etc.) as opposed to limiting its use to the main content editor as is currently the case.</p><p>This means that if we want to use WordPress long term, we will need to circumvent Gutenberg and keep circumventing it for a long time and in more areas of the CMS as time goes by.&nbsp;</p></blockquote>



<p>Another major factor in the decision to remove WordPress from consideration was that they found &ldquo;no elegant solution to content localization and translation.&rdquo;</p>



<p>Studio 24 also expressed concerns that tools like ACF, Fewbricks, and other plugins might not being maintained for the Classic Editor experience &ldquo;in the context of a widespread adoption of Gutenberg by users and developers.&rdquo;</p>



<p>&ldquo;More generally, we think this push to expand Gutenberg is an indication of WordPress focusing on the requirements of their non-technical user base as opposed to their audience of web developers building custom solutions for their clients.&rdquo;</p>



<p>It seems that the digital agency W3C selected for the project is less optimistic about the future of Gutenberg and may not have reviewed recent improvements to the overall editing experience since 2018, including those related to accessibility. </p>



<p>Accessibility consultant and WordPress contributor Joe Dolson recently gave an <a href=\"https://www.youtube.com/watch?v=EKZulmYKYJg\">update on Gutenberg accessibility audit</a> at WPCampus 2020 Online. He reported that while there are still challenges remaining, many issues raised in the audit have been addressed across the whole interface and 2/3 of them have been solved. &ldquo;Overall accessibility of Gutenberg is vastly improved today over what it was at release,&rdquo; Dolson said.</p>



<p>Unfortunately, Studio 24 didn&rsquo;t put WordPress through the same content creation and accessibility tests that it used for Statamic and Craft CMS. This may be because they had already planned to use a Classic Editor implementation and didn&rsquo;t see the necessity of putting Gutenberg through the paces. </p>



<p>These <a href=\"https://w3c.studio24.net/docs/w3c-cms-selection-process-update/#the-review-process\">tests</a> involved creating pages with &ldquo;flexible components&rdquo; which they referred to as &ldquo;blocks of layout,&rdquo; for things like titles, WYSIWYG text input, and videos. It also involved creating a template for news items where all the content input by the user would be displayed (without formatting). </p>



<p>Gutenberg would lend itself well to these uses cases but was not formally tested with the other candidates, due to the team citing their &ldquo;extensive experience&rdquo; with WordPress. I would like to see the W3C team revisit Gutenberg for a fair shake against the proprietary CMS&rsquo;s. </p>



<h2>W3C Is Prioritizing Accessibility Over Its Open Source Licensing Preferences</h2>



<p>The document outlining the CMS requirements for the project states that &ldquo;W3C has a strong preference for an open-source license for the CMS platform&rdquo; as well as &ldquo;a CMS that is long-lived and easy to maintain.&rdquo; This preference may be due to the economic benefits of using a stable, widely adopted CMS, or it may be inspired by the undeniable symbiosis between open source and open standards.</p>



<blockquote class=\"wp-block-quote\"><p>&ldquo;The industry has learned by experience that the only software-related standards to fully achieve [their] goals are those which not only permit but encourage open source implementations. Open source implementations are a quality and honesty check for any open standard that might be implemented in software&hellip;&rdquo;</p><cite><a href=\"https://opensource.org/osr-rationale\">Open Source Initiative</a></cite></blockquote>



<p>WordPress is the only one of the three original candidates to be distributed under an&nbsp;<a href=\"https://opensource.org/licenses\">OSD-compliant license</a>.&nbsp;(CMS code available on GitHub isn&rsquo;t the same.)</p>



<p>Using proprietary software to publish the open standards that underpin the web isn&rsquo;t a good look. While proprietary software makers are certainly capable of implementing open standards, regardless of licensing, there are a myriad of benefits for open standards in the context of open source usage: </p>



<blockquote class=\"wp-block-quote\"><p>&ldquo;The community of participants working with OSS may promote open debate resulting in an increased recognition of the benefits of various solutions and such debate may accelerate the adoption of solutions that are popular among the OSS participants. These characteristics of OSS support evolution of robust solutions are often a significant boost to the market adoption of open standards, in addition to the customer-driven incentives for interoperability and open standards.&rdquo;</p><cite><a href=\"http://airccse.org/journal/ijsea/papers/0111ijsea01.pdf\">International Journal of Software Engineering &amp; Applications</a></cite></blockquote>



<p>Although both Craft CMS and Statamic have their code bases available on GitHub, they share similarly restrictive licensing models. The Craft CMS <a href=\"https://github.com/craftcms/cms/blob/develop/CONTRIBUTING.md\">contributing document</a> states:</p>



<blockquote class=\"wp-block-quote\"><p><strong>Craft isn&rsquo;t FOSS</strong><br />Let&rsquo;s get one thing out of the way: Craft CMS is <strong>proprietary software</strong>. Everything in this repo, including community-contributed code, is the property of Pixel &amp; Tonic.</p><p>That comes with some limitations on what you can do with the code:</p><p>&ndash; You can&rsquo;t change anything related to licensing, purchasing, edition/feature-targeting, or anything else that could mess with our alcohol budget.<br />&ndash; You can&rsquo;t publicly maintain a long-term fork of Craft. There is only One True Craft.</p></blockquote>



<p>Statamic&rsquo;s contributing docs have similar restrictions:</p>



<blockquote class=\"wp-block-quote\"><p>Statamic is not Free Open Source Software. It is <strong>proprietary</strong>. Everything in this and our other repos on Github &mdash; including community-contributed code &mdash; is the property of Wilderborn. For that reason there are a few limitations on how you can use the code:</p></blockquote>



<p>Projects with this kind of restrictive licensing often fail to attract much contribution or adoption, because the freedoms are not clear. </p>



<p>In a GitHub issue <a href=\"https://github.com/craftcms/cms/issues/842\">requesting Craft CMS go open source</a>, Craft founder and CEO Brandon Kelly said, &ldquo;Craft isn&rsquo;t closed&nbsp;<em>source</em>&nbsp;&ndash;&nbsp;all the source code is right here on GitHub,&rdquo; and claims the license is relatively unrestrictive as far as proprietary software goes, that contributing functions in a similar way to FOSS projects.  This rationale is not convincing enough for some developers commenting on the thread.</p>



<p>&ldquo;I am a little hesitant to recommend Craft with a custom open source license,&rdquo; Frank Anderson said. &ldquo;Even if this was a MIT+ license that added the license and payment, much like React used to have. I am hesitant because the standard open source licenses have been tested.&rdquo;</p>



<p>When asked about the licensing concerns of Studio 24 narrowing its candidates to two proprietary software options, Coralie Mercier told me, &ldquo;we are prioritizing accessibility.&rdquo; A recent project <a href=\"https://w3c.studio24.net/updates/weeknotes-11-sept/\">update</a> also reports that both CMS suppliers W3C is reviewing &ldquo;have engaged positively with authoring tool accessibility needs and have made progress in this area.&rdquo;</p>



<p>Even if you have cooperative teams at proprietary CMS&rsquo;s that are working on accessibility improvements as the result of this high profile client, it cannot compare to the massive community of contributors that OSD-compliant licensing enables. </p>



<p>It&rsquo;s unfortunate that the state of open source CMS accessibility has forced the organization to narrow its selections to proprietary software options for its first redesign in more than a decade. </p>



<p>Open standards go hand in hand with open source. There is a mutually beneficial connection between the two that has caused the web to flourish. I don&rsquo;t see using a proprietary CMS as an extension of W3C values, and it&rsquo;s not clear how much more benefit to accessibility the proprietary options offer in comparison. W3C may be neutral on licensing debates, but in the spirit of openness, I think the organization should adopt an open source CMS, even if it is not WordPress.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Sep 2020 20:13:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: First Look at Twenty Twenty-One, WordPress’s Upcoming Default Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105166\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme?utm_source=rss&utm_medium=rss&utm_campaign=first-look-at-twenty-twenty-one-wordpresss-upcoming-default-theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6907:\"<blockquote class=\"wp-block-quote\"><p>Fashion is ephemeral. Art is eternal. Indeed what is a fashion really? A fashion is merely a form of ugliness so absolutely unbearable that we have to alter it every six months!</p></blockquote>



<p>Thus wrote Oscar Wilde on Victorian-era fashion in an article titled &ldquo;The Philosophy of Dress&rdquo; for the <em>New-York Tribune</em> in 1885.</p>



<p>In many ways, WordPress theming is the same as the ever-changing landscape of fashion. Rounded corners are in one day and out the next. Box shadows are in one year after being frowned up just months earlier. Perhaps web design is so intolerable that we must change it every six months. Or, at least freshen it up every year in the case of WordPress.</p>



<p>If art is eternal, there are only two default, Twenty* themes that I can truly recall from past years: Twenty Ten and Twenty Fourteen &mdash; yes, Twenty Twenty is memorable, but it is also still the current default. Twenty Ten was a classic that paid homage to WordPress&rsquo;s past. Twenty Fourteen was such a leap away from tradition that it is hard to forget. Everything else has seemed to fade to varying degrees.</p>



<p>With WordPress 5.6 and the end of the year looming, it is time to look forward to the latest trend. As Mel Choyce-Dwan noted in the <a href=\"https://make.wordpress.org/core/2020/09/23/introducing-twenty-twenty-one/\">announcement of Twenty Twenty-One</a>, the next default theme, &ldquo;<a href=\"https://www.garnishstudios.com/\">Pastels</a> and <a href=\"https://www.designbyparker.com/\">muted</a> <a href=\"https://westportcondos.ca/\">colors</a> are <a href=\"https://arisacoba.com/\">pretty</a> <a href=\"https://www.collaborativechange.global/\">in</a> <a href=\"https://paradigmacreation.com/\">right</a> <a href=\"https://taregrocery.com/\">now</a>.&rdquo;</p>



<p>She is not wrong. The colors are a refreshing change of pace. Now that we are into the second day of autumn, I am getting <em>the good kind of vibes</em> from some of the more earthy-tones from a couple of the color palettes expected to ship with the theme.</p>



<img />Potential color palette options for Twenty Twenty-One.



<p>Whether Twenty Twenty-One will be a fashionable theme for the year or art that we can remember a decade from now, only history will be able to judge. For now, let&rsquo;s enjoy the creation and take a look at what we should expect from the next default WordPress theme.</p>



<h2>The Current Twenty Twenty-One</h2>



<p class=\"has-drop-cap\">The new default theme is a fork of <a href=\"https://wordpress.org/themes/seedlet/\">Automattic&rsquo;s Seedlet</a>, a project in which I lauded as the <a href=\"https://wptavern.com/exploring-seedlet-automattics-block-first-wordpress-theme\">next step in the evolution of theming</a>. It is a theme that is focused on WordPress&rsquo;s future of being completely comprised of blocks. It gives us an ideal insight into where theme development is heading. It makes sense as the foundation for the new default. Few other themes would make for a good starting point right now. With WordPress theme development in flux, Seedlet is simply ahead of the pack in terms of foundational elements.</p>



<img />Seedlet WordPress theme screenshot.



<p>&ldquo;This provides us with a thorough system of nested CSS variables to make child theming easier, and to help integrate with the global styles functionality that&rsquo;s under development for full-site editing,&rdquo; wrote Choyce-Dwan of using Seedlet as a starting point.</p>



<p>There are no plans to spin up a Google Web Font for this theme. The design team is going native and sticking with the default system font stack. Choyce-Dwan listed several reasons for the choice, such as keeping a neutral font that allows broad use, speed, and customizability via a child theme.</p>



<p>Despite the neutral font, the default pastel green is a fairly opinionated design decision. It will not be used broadly across industries. However, the team plans to create multiple color palettes that will give it more range. Presumably, these palettes can also be overwritten.</p>



<img />Pastel green color scheme on single post view.



<p>Other than the colors, the design is relatively simple. Choyce-Dwan said that the theme&rsquo;s block patterns support is where it will be truly unique.</p>



<p>I was initially <a href=\"https://wptavern.com/decision-time-what-block-patterns-should-ship-with-wordpress-5-5\">unhappy with the patterns</a> that were going to ship with WordPress 5.5. However, an 11th-hour <a href=\"https://wptavern.com/gutenberg-8-7-adds-minor-changes-updates-block-pattern-designs-and-continues-full-site-editing-work\">update improved the situation</a> so that they did not feel entirely experimental. The foundational Seedlet theme for Twenty Twenty-One has some unique patterns that begin to scratch the surface of what&rsquo;s possible with this WordPress feature. My hope is that the new default theme steps it up a notch.</p>



<p>Currently, the theme does not register any custom patterns. However, it has a placeholder file and a note that they are a work in progress. Choyce-Dwan shared some patterns the team has already designed in the announcement.</p>



<img />Currently-designed block patterns.



<p>&ldquo;We&rsquo;ll be relying on our talented community designers for more ideas,&rdquo; she wrote. The team has also created a GitHub template for anyone to <a href=\"https://github.com/WordPress/twentytwentyone/issues\">contribute pattern design ideas</a>.</p>



<p>Currently, the theme does not support the upcoming full-site editing feature of WordPress. After the Beta 1 release of WordPress 5.6, the team plans to begin exploring the addition of this support. WordPress is expected to ship a public beta of full-site editing in its <a href=\"https://make.wordpress.org/core/2020/08/13/wordpress-5-6-release-planning/\">next major release</a>, but it is unclear whether it will be far enough along to be a headline feature for the Twenty Twenty-One theme.</p>



<p>The team and volunteers have less than a month before the October 20th deadline for committing the new theme to trunk, the core WordPress development branch. At that stage, the theme should be nearly complete and ready for production. Of course, there will be several rounds of patches, bug fixes, and updates before WordPress 5.6 lands in December. Right now is the best time for anyone who wants to get involved with Twenty Twenty-One to do so.</p>



<p>Useful links with more information:</p>



<ul><li><a href=\"https://github.com/WordPress/twentytwentyone\">GitHub Repository</a></li><li><a href=\"https://www.figma.com/file/Fv7BODXobfo2prksqRDySy/Introducing-Twenty-Twenty-One?node-id=0%3A1\">Theme Mockups via Figma</a></li><li><a href=\"https://www.pinterest.com/melchoyce/tt1/\">Twenty Twenty-One Idea Pinterest Board</a></li></ul>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Sep 2020 20:01:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"HeroPress: Hello World – Hevo Nyika\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=3308\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:176:\"https://heropress.com/essays/hello-world-discovering-the-world-through-wordpress/#utm_source=rss&utm_medium=rss&utm_campaign=hello-world-discovering-the-world-through-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14438:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2021/09/092220-min.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Find your purpose, pursue it relentlessly\" /><p><a href=\"https://heropress.com/feed/#shona\"><span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\">Unokwanisa kuverenga rondedzero iyi muChiShona</span></a></p>
<p>So I chose a career in Web Development!!</p>
<p>To be honest it&#8217;s kind of funny when I think about it and quite surreal to be here talking about my story. It has been a journey and I would like to share my story with you.</p>
<p>I have been lucky in the Dad department. My Dad encouraged me to work hard and dream big from a very young age. I remember occasionally having ‘when I grow up’ talks.</p>
<p>For quite some time I wanted to be a Judge, however awesome this dream sounds it was not very inspired. After binge-watching Judge Judy for a whole weekend, I started calling myself Judge Thelma. Though I don&#8217;t remember much of this my sister says that I used to say I would arrest all the men in the World if I ever became a Judge. HAHAHA! (clearly I didn&#8217;t understand how the World works)</p>
<p>I did not understand what being a Judge meant or what was required for me to start banging that gavel to my heart&#8217;s desire. Eventually, I learnt that I had to become a lawyer first then magistrate before I could be nominated to be a Judge and let us just say that is how I sentenced that dream to a lifetime down the drain.</p>
<p>See what I did there? hahaha!</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2021/09/tandd-min.jpg\"><img /></a>With Daddy Dearest
<p>A few years later, I was in High School and that is when I decided to pursue a career in Computer Science. I did not know what I would be doing or how I would get there but I just knew that I was going to pursue a career in ICT. I wrote my first line of code when I was 16 years old.</p>
<p>This was after I had joined the school&#8217;s computer class, initially, I thought I would be learning about Excel Sheets and Word Documents until I was assigned to write my first program in C (talk about a double-take!!). It was not easy but it was very exciting, l remember writing up simple code for a Video Club &#8211; a simple check-in/out for VHS tapes and CDs. Dear World, thus began my fascination with computers.</p>
<p>Seven years later, I was now in university studying ICT as I had always wanted. I was doing a Bachelors in Business Management &amp; Information Technology. In my third year, I was interning at a local Webdesign and hosting company. This was never my plan, I only took on that job after I had failed to get a job with local banks or telecommunications companies. Before I was introduced to Website Design I envisioned myself suiting up and working in IT Audit or offering IT support. Even though things did not go as I had planned, I am glad they did not exactly go my way in that aspect. So in 2017, I was designing websites using HTML, CSS, PHP, JavaScripts and Joomla which was the prefered content management system at that company. I knew about WordPress but I was not using it for anything. People have this misconception that WordPress is not for real developers and it is not secure and at that time I was one of those people.</p>
<h3>Finding my tribe</h3>
<p>One day when I was working at the front desk <a href=\"https://heropress.com/essays/wordpress-opened-whole-new-world/\">Thabo Tswana</a> came to give a colleague of mine a purple WooCommerce pen. I did not know what WooCommerce was at that time but I was taken by the purple shirt and pen he was carrying. I asked him about it and he explained what WooCommerce was and that what he was carrying was called &#8216;swag&#8217;. So the love of freebies led me to the WordCamp Harare website, instead of buying a ticket I applied to volunteer. I learnt more about WordPress, I was a volunteer, without any knowledge on WordPress.org or WordPress.com. I only started using WordPress because of the awesome people that l had met at that Wordcamp.</p>
<p>Everyone was so welcoming, a week later with help from Thabo I designed my first ever WP website.</p>
<p>Soon after I was part of the community and a bit more involved in the meetups. We had our first-ever Women Who WordPress meetup in 2018. So many ladies came on board bloggers and developers alike. We were free to talk and discuss a lot of things. We had more time to discuss the difference between WordPress.com and WordPress.org we shared views on how to handle discrimination at work, how to promote your website and a whole lot of other things.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2021/09/20180324_105352-min.jpg\"><img /></a></p>
<h3>Establishing roots</h3>
<p>In 2018, Harare had its first-ever female Lead Organiser <a href=\"https://tapiwanashe.com/\">Tapiwanashe Manhobo</a> whoop whoop! I was also part of the organising team that year, I was assigned to handle Harare’s first Kids Camp. The planning process was stressful because the economic crisis in Zimbabwe was getting worse, luckily we had over 8 months to plan and with help from sponsors, we managed to pull through. In the end, everything turned out great. I wrote an article about the <a href=\"https://thelmachido.wordpress.com/2019/11/21/wordpress-juniours-first-edition/\">Kids Camp here</a>.</p>
<p>After the first Kids Camp, we had several WordPressors that were enthusiasts about encouraging kids to embrace ICT. In 2019 we had not planned to have a Kids Camp because of financial constraints but to our surprise, we had some anonymous donations and we managed to have a WordPress Community outreach to a youth centre a week after our WordCamp. We had the outreach at the <a href=\"https://cttzim.org/\">Centre for Total Transformation</a> which is a non-formal school that caters for underprivileged and vulnerable children. We taught them about WordPress, Computer Hardware and Software.</p>
<p>Here is a small video I took with Ellen when we were about to leave. Did l mention that I am terrible on camera? hahaha!</p>
<div class=\"wp-video\"><a href=\"https://thelmachido.me/vid.mp4\">https://thelmachido.me/vid.mp4</a></div>
<p><a href=\"https://thelmachido.wordpress.com/2020/09/18/kids-camp-2019-centre-for-total-transformation/\">Kids Camp 2019 &#8211; Centre for Total&nbsp;Transformation</a></p>
<p>I have fallen deeply for WordPress because of the Community, I enjoy attending WordCamps, meeting new people and just learning new stuff. I have a huge list of WordCamps I need to attend before l kick the bucket, hopefully. Last year I managed to cross WordCamp</p>
<p>Johannesburg off my bucket list. This year I was going to attend WordCamp Capetown but unfortunately, 2020 had other plans for the whole world. Anyway when everything is back to normal my plan to travel to WordCamps will proceed. (fingers crossed)</p>
<h3>Reaping Fruits</h3>
<p>Meanwhile, my plan to improve my developing skills has not been on hold. Even though I can still cook up code in C and Java, for now, I have also included WordPress PHP functions to the mix. It was not easy to get to this point, daring myself got me to this slightly better stage. My IQ is not way up there, however, I try to do my best where I can and I am happy to say it has paid off so far.</p>
<p>Around November last year, I was designing as a freelancer while job hunting. Out of the blue l got a call for a job offer from <a href=\"https://zw.linkedin.com/in/trust-nhokovedzo\">Trust Nhokovenzo</a> who is big on <a href=\"https://afrodigital.org/\">Digital marketing</a> and also part of the WordPress Community. He had asked someone in the community about developers and my name happened to come up. So since February, I have been part of his team at <a href=\"https://calmlock.co.zw/\">Calmlock Digital Marketing Agency</a>.</p>
<p>There is so much more in the world of WordPress that l am yet to tap into so even though I am ending my write up here, for now, my story is going to continue &#8230;</p>
<p>Until next time&#8230;</p>
<h1 id=\"shona\">Hevo Nyika</h1>
<p>Saka ini ndakasarudza kugadzira mawebhusayiti.</p>
<p>Ndakaita rombo rakanaka pana baba vandakapihwa naMwari. Baba vangu vaindikurudzira kuti ndishande nesimba. Ndinoyeuka pano neapo tichiita hurukuro dzedu dzekuti ‘kana ndakura ndoda kuveyi’.</p>
<p>Kwenguva yakati rebei ndaida kuve Mutongi. Kunyangwe ini ndisingazvirangariri mukoma wangu anotaura kuti ndaiti ndaizosunga varume vese vari pasi rino kana ndikangoita mutongi HAHAHA zveshuwa handaiziva kuti mitemo yenyika inofambiswa seyi.<br />
Ndanga ndisinga nzwisisi kuti kuva mutongi kwairevei kana zvaidikanwa kwandiri kuti nditange kurova iro ghavheu kuchishuwo chemoyo wangu. Pakupedzisira, ndakadzidza kuti ndaifanirwa kuzoita gweta ipapo magistrate ndisati ndasarudzwa kuita Mutongi naizvozvo ndokupera kwakaita chiroto chekuva Mutongi.</p>
<a href=\"https://s20094.pcdn.co/wp-content/uploads/2021/09/tandd-min-1.jpg\"><img /></a>Na Baba Vangu
<p>Gare gare papfura makore mashoma pandakanga ndave kuHigh School ndakanga ndakuda kuita basa rema kombiyuta. Ndakanyora mutsara wekutanga wekodhi pandaive nemakore gumi nematanhatu. Izvi zvakaitika mushure mekunge ndapinda mukirasi yemakombiyuta, pakutanga ndaifunga kuti ndinenge ndichidzidza nezveExcel Sheets neWord zvisineyi ndakaona ndakunyora kodhi yangu yekutanga muC. Zvaisave nyore kunyora kodhi asi zvainakidza kwazvo, ndorangarira ndichinyora kodhi yeVhidhiyo Kirabhu.</p>
<p>Makore manomwe apfura, ndakanga ndava kuyunivhesiti ndichidzidza ICT zvandakagara ndakaronga. Ndaiita Bachelors muBusiness Management &amp; Information Technology. Mugore rangu rechitatu ndainge ndave kushanda kune imwe kambani yaita zvekugadzira mawebhusaiti. Ndakawana basa iri mushure mekunge ndatadza kuwana basa kumabhanga. Kunyangwe hazvo zvinhu zvisina kuenda sezvandaive ndakaronga, ndinofara kuti hazvina kunyatso enda nenzira yangu. Saka muna 2017 ndaigadzira mawebhusaiti ndichishandisa HTML, CSS, PHP, JavaScript uye Joomla iyo yaive iyo inokurudzirwa kukambani kwandaive. Panguva iyi ndaiziva nezve WordPress asi ndakanga ndisingaishandisi.</p>
<h3>Kuwanana neWordPress</h3>
<p>Rimwe zuva pandakanga ndichishanda ndakaona <a href=\"https://heropress.com/essays/wordpress-opened-whole-new-world/\">Thabo Tswana</a> akauya kuzopa mumwe mukomana wandayishanda naye chinyoreso cheWooCommerce. Ndakanga ndisingazive kuti WooCommerce yaive chii asi ndakafarira chinyoreso nehembe ye WooCommerce yaanga akapfeka. Ndakamubvunza nezvazvo akatsanangura kuti WooCommerce yaive chii. Saka nekudawo zvakanaka, zvemahara ndakaenda pawebhusaiti yeWordCamp Harare ndikabata zvimbo zvegore iroro. Ndakazvipira kubatsirawo vamwe vekuWordPress kuWordCamp Harare. Nerubatsiro kubva kunaThabo ndakagadzira webhusaiti yangu yekutanga yeWordPress vhiki rakatevera .</p>
<p>Mushure mekunge ndaitawo chipato cheavo vanoshandisa WordPress ndakanga ndakuenda kumisangano yeWordPress yaitwa muHarare. Takaita musangano wevakadzi chete muna 2018. Vakadzi vazhinji vakauya kumusangano uyu. Tainga takasununguka kukurukura zvinhu zvakawanda. Takakurukura pamusoro pemutsauko uripo pakati peWordPress.com neWordPress.org takagovana maonero ekugadzirisa rusarura kubasa nezvimwewo.</p>
<p><a href=\"https://s20094.pcdn.co/wp-content/uploads/2021/09/20180324_105352-min.jpg\"><img /></a></p>
<h3>Nguva yandakatanga kushandisa WordPress</h3>
<p>Muna 2018, kurongwa kweWordCamp Harare kwakatungamirwa kekutanga nemusikana ainzi <a href=\"https://tapiwanashe.com/\">Tapiwanashe Manhobo</a> (waiva mufaro mukuru). Ndakanga ndiri mumwe wevairongawo naye. Hurongwa hwekuronga WordCamp Harare mugore iri hwainetsa pamusaka pekuoma kwehupfumi wemuZimbabwe, zvisineyi takaita rombo rakanaka nokuti takawana rubatsiro kubva kunevamwewo vanhu vakatiwedzera mari. Pakupedzisira, zvese zvakabudirira zvakanaka. Takarongawo WordCamp yevana varipasi pemakore gumi nechishanu, munokwanisa kuverenga pamusoro pezuva iri <a href=\"https://thelmachido.wordpress.com/2019/11/21/wordpress-juniours-first-edition/\">pawebhisaiti yangu apa</a>.</p>
<p>Mushure mekuita WordCamp yevana, takave nevamwe vanhu veWordPress aifarira kukurudzira vana kuti vagamuchire ICT. Muna 2019 takanga tisina kuronga kuve neWordCamo yeVana nekuda kwezvimhingamupinyi zvemari asi chakatishamisa ndechekuti takawana mari kubvawo kune vamwe. Takaita Camp iyi pa<a href=\"https://cttzim.org/\">Centre for Total Transformation</a> chinova chikoro chisiri chepamutemo chinodzidzisa vana vanotambura. Tadzidzisa vana ava pamusoro peWordPress, Computer Hardware uye Software.</p>
<div class=\"wp-video\"><a href=\"https://thelmachido.me/vid.mp4\">https://thelmachido.me/vid.mp4</a></div>
<p>Ndofarira WordPress zvakanyanya nekuda kweavo varimu nharaunda yacho, ini ndinonakidzwa nekuenda kumaWordCampi, kusangana nevanhu vatsva uye kungo dzidza zvinhu zvitsva. Gore rakapera ndakakwanisa kuyambuka muganhu weZimbabwe ndichienda kuWordCamp Johannesburg, dai pasina kuti 2020 nyika dzepasi rino dzakawirwa nedenda reCOVID 19 zvimwe ndingadayi ndakaenda kuWordCamp Capetown. Zvisinei hazvo kana denda ranani zvimwe ndichakwanisa kufamba ndichienda kumaWordCamp edzimwe nyika.</p>
<h3>Kukowa zvandakadyara</h3>
<p>Zvichakadaro, chirongwa changu chekuvandudza hunyanzvi hwangu hachina kumira. Kunyangwe ini ndichiri kukwanisa kubika kodhi muC uye Java, ikozvino, ndasanganisirawo WordPress PHP. Zvaive zvisiri nyore kusvika apa, zvakatora kuzvishingisa nekushanda nesimba. Ndinofara mwari aiva neni pamufambo wangu uyu.</p>
<p>Muna Mbudzi gore rakapera, ndaive ndichigadzira mawebhusayiti apo nditsvaga basa. Pasina nguva ndakataura na<a href=\"https://zw.linkedin.com/in/trust-nhokovedzo\">Trust Nhokovenzo</a> uyo akaandipa basa mukambani yake, kambani iyi inonzi <a href=\"https://calmlock.co.zw/\">Calmlock Digital Marketing Agency</a>.</p>
<p>Pane zvimwe zvakawanda kuWordPress zvandisati ndapinda mazviri. Nhaizvozvo kunyangwe ndiri kupedzisa kunyora kwangu apa, nyaya yehupenyu wangu ichaenderera mberi&#8230;</p>
<p>Kusvikira nguva inotevera &#8230;</p>
<p><strong>&#8230;. tsvaga chinangwa chako, chiite mushe mushe ..</strong></p>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/hello-world-discovering-the-world-through-wordpress/\">Hello World &#8211; Hevo Nyika</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Sep 2020 06:00:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Thelma Mutete\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: WordPress Contributors Debate Dashboard Notice for Upcoming Facebook oEmbed Provider Removal\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:249:\"https://wptavern.com/wordpress-contributors-debate-dashboard-notice-for-upcoming-facebook-oembed-provider-removal?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-contributors-debate-dashboard-notice-for-upcoming-facebook-oembed-provider-removal\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5885:\"<p>WordPress contributors are discussing different strategies for responding to Facebook and Instagram <a href=\"https://wptavern.com/upcoming-api-change-will-break-facebook-and-instagram-oembed-links-across-the-web-beginning-october-24\">dropping unauthenticated oEmbed support</a>&nbsp;on October&nbsp;24. WordPress will be removing both Facebook and Instagram as oEmbed providers. When a user attempts to embed content by pasting a URL as they have in the past, they may not understand why it no longer works. They may assume that WordPress broke embeds, causing an increase in the support burden for this change.</p>



<p>A few participants on the <a href=\"https://core.trac.wordpress.org/ticket/50861\">trac ticket</a> for this issue have suggested WordPress detect users who will be impacted and attempt to warn them with a notice.</p>



<p>&ldquo;Since this may impact users unknowingly, it is possible to push a dashboard notice to users who have Facebook/Instagram embeds in their content, showing for site admins, as a one-off that can be dismissed,&rdquo; Marius Jensen said.</p>



<p>&ldquo;We&rsquo;ve previously done post-update-processing to clean up comments, so the idea of looking over content for an embed isn&rsquo;t completely outlandish, and would help with those who don&rsquo;t follow WordPress&rsquo; usual channels to learn of this.&rdquo;</p>



<p>Others don&rsquo;t see the necessity. &ldquo;Why should we make exception here?&rdquo; Milan Dini&#263; said. &ldquo;It&rsquo;s not the first time oEmbed support was discontinued for a provider, and I don&rsquo;t remember anything specific was done then.&rdquo;</p>



<p>There is still some uncertainty about what will happen with existing oEmbeds after Facebook updates its API. During a recent core developer meeting, Helen Helen Hou-Sand&iacute; confirmed that WordPress does not clear&nbsp;oEmbed&nbsp;caches regularly. &ldquo;Technically&nbsp;oEmbed&nbsp;caches are cleared if you save and a valid response is returned, we do not do cron-based garbage collection,&rdquo; Hou-Sand&iacute; said.</p>



<p>In a post today on the core development blog, Jake Spurlock assured users and developers that the existing embeds added before Facebook&rsquo;s API change should still work:</p>



<blockquote class=\"wp-block-quote\"><p>Because oEmbed responses are cached in the database using the hidden&nbsp;<code>oembed_cache</code>&nbsp;post type, any embed added prior to the October 24th deadline will be preserved past the deprecation date. These posts are not purged by default in WordPress Core, so the contents of the embed will persist unless manually deleted.</p></blockquote>



<p>Marius Jensen cautioned that there is still the possibility that existing embeds may not work going, depending on what Facebook does.</p>



<p>&ldquo;We don&rsquo;t know how they plan on implementing the use of unauthorized embed attempts,&rdquo; Jensen said. &ldquo;It could not return an embed code and your link would remain a plain link, or maybe they decide to return some kind of embedded &lsquo;unauthorized&rsquo; content. I don&rsquo;t think anyone has heard any specifics on how Facebook plans on doing this, so we&rsquo;re all just kinda waiting to either hear more, or see what happens.&rdquo;</p>



<p>Jensen said WordPress doesn&rsquo;t re-check the cached results except when something changes with the post, but there may be plugins that clean up temporary data that may create an unpredictable outcome.</p>



<p>&ldquo;The reliability of the caches are hard to determine (and being caches, it&rsquo;s sort of in the term that it&rsquo;s not guaranteed to always be there, but rather fetched and saved for a while when needed),&rdquo; Jensen said.</p>



<p>Ideally WordPress&rsquo; oEmbed caches will prevent millions of embeds from breaking, but it&rsquo;s still unknown how Facebook and third party plugins could change things.</p>



<p>Coming off a rocky 5.5 core update that deprecated jQuery Migrate and flooded official support forums with&nbsp;<a href=\"https://wordpress.org/search/5.5?in=support_forums\">reports of broken sites</a>, some contributors are wary of having another situation where users are left in the dark.</p>



<p>&ldquo;I think a dashboard notice is desirable,&rdquo; Jon Brown said. &ldquo;Otherwise we&rsquo;re not preemptively warning people in a way they can prepare and transition to another solution. We&rsquo;re letting them know the same instant it&rsquo;s going to break (when editing a specific post). I don&rsquo;t think we can safely assume cached data is going to persist forever either, plenty of routines out there purge transient data before its stated expiration date.</p>



<p>&ldquo;I see this as potentially being similar to the problems seen in dropping JQM. It&rsquo;ll cause <em>avoidable and silent breakage</em> client side without even any error logging for a site developer to pick up on. In hindsight, what ideally would have happened with JQM would have been incorporating the detection code from Enable jQuery Migrate Helper into core temporarily, or simply installing that plugin automatically on behalf of users.&rdquo;</p>



<p>Brown suggested WordPress detect calls to the cached embeds and warn users before the calls have the chance to fail so they can consider enabling a plugin to keep their embeds working more reliably.</p>



<p>The discussion remains open in the make.wordpress.org/core <a href=\"https://make.wordpress.org/core/2020/09/22/facebook-and-instagram-embeds-to-be-deprecated-october-24th/\">post</a> and the corresponding <a href=\"https://core.trac.wordpress.org/ticket/50861\">trac ticket</a>. Spurlock said WordPress will likely remove Facebook and Instagram oEmbed providers in the upcoming 5.6 release (scheduled for December 8) but it could also be shipped in a 5.x minor release that happens after October 24. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Sep 2020 04:28:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Gutenberg Hub Launches Landing Page Templates Directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105009\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:175:\"https://wptavern.com/gutenberg-hub-launches-landing-page-templates-directory?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-hub-launches-landing-page-templates-directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7657:\"<img />



<p class=\"has-drop-cap\">Munir Kamal has created <a href=\"https://wptavern.com/copy-and-paste-editor-blocks-via-gutenberghubs-block-library\">copy-and-paste blocks</a>. He has built <a href=\"https://wptavern.com/gutenberg-hub-launches-collection-of-100-block-templates\">sections or &ldquo;patterns&rdquo;</a> from those blocks. He has created a plugin that allows users to completely customize the two features via block options. Yesterday, he <a href=\"https://gutenberghub.com/introducing-gutenberg-landing-page-templates/\">released an initial offering</a> of 22 landing page templates that build upon his earlier work.</p>



<p>Gutenberg Hub can almost be called his <em>magnum opus</em>, at least at this stage of his career. It is a continually growing library of free tools for WordPress&rsquo;s block editor.</p>



<p>Like previous projects, Gutenberg Hub&rsquo;s landing templates require the <a href=\"https://wptavern.com/control-block-design-via-the-editorplus-wordpress-plugin\">EditorPlus plugin</a>. This plugin is essentially a suite of design controls for the core WordPress blocks. The templates make use of these options by default. Given the limitations of the block editor&rsquo;s current design controls, the use of such a plugin is necessary. Otherwise, there would be few other ways to realistically create a template system like this.</p>



<p>Currently, users must copy the block code &mdash; via a convenient &ldquo;copy&rdquo; button &mdash; from the Gutenberg Hub website and then paste it in the editor. It is not an ideal situation, and I have been asking Kamal whether he would consider building a template inserter for months now.</p>



<p>This time around, he preemptively said, &ldquo;And, by the way, I am already working on adding a Template Inserter in my EditorPlus plugin. That will allow users to browse and insert these templates directly from Gutenberg without leaving the website.&rdquo;</p>



<p>He knew the question was coming. No need for me to ask again. He was unable to share a current screenshot of what the inserter looks like, but he is asking for feedback on what people expect of the user experience and interface.</p>



<p>&ldquo;Earlier, I created a template inserter similar to other blocks plugins, but later I changed my mind and thought that I should integrate with the Gutenberg Patterns API and load the templates into the &lsquo;patterns&rsquo; panel in the block inserter,&rdquo; he said. &ldquo;But, I am having a few issues and thinking about going back to the original idea to have a Templates button on the top toolbar that opens a popup window to browse and filter templates that users can insert on a click.&rdquo;</p>



<p>For now, it is still early. However, at least it is on the long-term roadmap and being worked on.</p>



<h2>The Landing Page Templates</h2>



<img />Testing the photography template (with minor adjustments).



<p class=\"has-drop-cap\">At the moment, Gutenberg Hub offers <a href=\"https://gutenberghub.com/template-category/pages/\">22 landing page templates</a>. The &ldquo;page&rdquo; terminology may not mean &ldquo;full page.&rdquo; It simply depends on the active theme. Some themes have an open-canvas type of template that allows users to create the entire page via the editor. However, that is not a common feature, so these page templates will be confined to the post content area in most cases.</p>



<p>The templates also work better with themes that have at least a full-width or no-sidebar option. End-users will want a lot of breathing room to use the templates and tinker with their designs.</p>



<p>Kamal has built templates that stretch across a variety of industries. From restaurants to gyms to education to fashion, there is a lot to choose from right now. He promises more are on the way and at least a 23rd template in the next few days.</p>



<p>&ldquo;For the niches, I did some research from the top WordPress and HTML marketplaces and found the following most common or popular niches,&rdquo; he said. &ldquo;I think I will stick with these niches unless I get some more recommendations.&rdquo;</p>



<p>In comparison, <a href=\"https://wptavern.com/redux-framework-relaunches-focuses-efforts-on-gutenberg-templates\">Redux Templates</a> offers access to over 1,000 sections and templates. Of course, there are trade-offs, such as some of those being commercial and the plugin typically requiring other third-party plugins. While quantity is not the only thing to look at, it proves there are miles of landscape that Gutenberg Hub&rsquo;s templates have not yet explored. But, it is merely the beginning.</p>



<p>Gutenberg Hub&rsquo;s full-page templates are not quite as plug-and-play as its blocks and section templates. This is not so much a fault from the developer&rsquo;s end. It is an issue of the platform, which is constantly being updated, and the range of support from current themes. End-users will start seeing some of the current limitations of the system when a layout does not quite look right with one theme but does with another. Or, if their theme has not been updated to support a new feature, such as the Social Links block, the typical horizontal menu design will likely be a normal vertical list of links instead.</p>



<p>These are not insurmountable issues. Gutenberg and themes need more time to mature before projects like Gutenberg Hub&rsquo;s landing templates are perfect or at least as close to perfect as can be expected.</p>



<p>There are some things that Gutenberg Hub could improve with its templates. With several that I tested, I needed to switch specific blocks to be full width. This should be set up as the default with templates that are clearly meant to be full width in the example screenshots available on the site. It is a minor issue, but correcting this in the editor fixed several layout issues I was having when using the templates.</p>



<h2>Monetization Plans</h2>



<p class=\"has-drop-cap\">The second question that Kamal has not been prepared to answer fully over the past several months is how he will monetize Gutenberg Hub. Eventually, developers need some return on their investment when building tons of free tools. Many would do it all for free as long as their bills somehow got paid, but the reality is that there will come a tipping point where their projects need funding for long-haul maintenance.</p>



<p>Kamal said he has laid the groundwork for funding but has not finalized anything yet. Currently, he is working on three ideas:</p>



<ul><li>Creating a pro version of his EditorPlus plugin.</li><li>Offering premium templates and blocks but is looking for a talented designer to work with.</li><li>Using ads specific to Gutenberg users, but he is not a fan of going this route or ads in general.</li></ul>



<p>He is open to feedback on how to best monetize the website and its projects. However, he said he is unwilling to compromise on giving away current and future free templates and tools.</p>



<h2>Future Gutenberg Projects</h2>



<p class=\"has-drop-cap\">Kamal said he does not have any new Gutenberg-related projects in the pipeline. The current plan is to work on what he has already created, which is a large ecosystem of Gutenberg tools that somehow work together.</p>



<p>Outside of blocks, templates, and plugins, he is beginning to write more free tutorials on the Gutenberg Hub blog and focusing on <a href=\"https://www.youtube.com/GutenbergHub\">creating videos</a> around the project, including a new tutorial <a href=\"https://www.youtube.com/playlist?list=PLfVnkTCddAJ2HMmjw1o12XP7TAEoOV5oE\">series for beginners</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Sep 2020 21:05:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WPTavern: WordPress Mobile Engineers Propose Dual Licensing Gutenberg under GPL v2.0 and MPL v2.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105025\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"https://wptavern.com/wordpress-mobile-engineers-propose-dual-licensing-gutenberg-under-gpl-v2-0-and-mpl-v2-0?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-mobile-engineers-propose-dual-licensing-gutenberg-under-gpl-v2-0-and-mpl-v2-0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6556:\"<p>During a Q&amp;A session at WordCamp Europe 2020 online, Matt Mullenweg mentioned that Gutenberg contributors were considering dual licensing for embedding Gutenberg in mobile apps, along with the requirement that they would need to get an agreement from all contributors. WordPress mobile engineer <a href=\"https://bia.is/\">Maxime Biais</a> has just published a <a href=\"https://make.wordpress.org/core/2020/09/21/proposal-dual-licensing-gutenberg-under-gpl-v2-0-and-mpl-v2-0/\">proposal</a> for discussion, recommending dual licensing the editor under GPL v2.0 and MPL v2.0.</p>



<p>&ldquo;The GPL v2.0 license is a blocker for distributing the Gutenberg library in proprietary mobile apps,&rdquo; Biais said in the corresponding <a href=\"https://github.com/WordPress/gutenberg/issues/23651\">GitHub issue</a>. &ldquo;Currently the only known users of Gutenberg on mobile are the WordPress mobile apps which are under GPL v2.0 (<a href=\"https://github.com/wordpress-mobile/WordPress-Android\">WordPress for Android</a>,&nbsp;<a href=\"https://github.com/wordpress-mobile/WordPress-iOS\">WordPress for iOS</a>). Mobile apps under the GPL v2.0 are not common and this limits Gutenberg usage in many apps.</p>



<p>&ldquo;Rich text editor libraries in the mobile space are lacking. There is no well known open source rich text editor for Android or iOS. We believe that Gutenberg could be a key library for many mobile apps, but that will never happen with the GPL v2.&rdquo;</p>



<p>Mobile app developers are limited by the GPL, because it requires the entire app to be distributed under the same license. The team is proposing dual licensing under MPL v2.0, a weaker copyleft license that is often considered to be more &ldquo;business-friendly.&rdquo; It allows users to combine the software with proprietary code. MPL v2.0 requires the source code for any changes to be available under the MPL, ensuring improvements are shared back to the community. The rest of the app can be distributed under any terms with the MPL v2.0 code included as part of a &ldquo;larger work.&rdquo;</p>



<p>&ldquo;The idea here is to keep some of the WordPress-specific modules under the GPL v2.0 only; some of them are not needed and not relevant for using Gutenberg in another software. Ideally, there would be a different way of bundling the project for being used in WordPress or in a non-GPL software,&rdquo; Biais said.</p>



<p>The GitHub ticket has several comments from developers who hope to be able to use the editor in their own projects. Radek Pietruszewski, tech lead for a collaborative todo app called&nbsp;<a href=\"https://nozbe.com/\">Nozbe Teams</a>, has been requesting a relicensing of Gutenberg since October 2019.</p>



<p>&ldquo;Our tech stack is essentially React on web and React Native on iOS and Android,&rdquo; Pietruszewski said. &ldquo;We&rsquo;re a tiny company, and so we share &gt;80% of app&rsquo;s codebase between these 3 platforms.</p>



<p>&ldquo;Our app sorely lacks a WYSIWYG editor. We had a working implementation on web, but we decided to scrap it, because there was no way to port it on iOS and Android. There are pretty much no viable rich text editors for iOS or Android, yet alone both. But even then, shipping three completely separate, but somehow compatible editors would be a vast amount of work.&rdquo;</p>



<p>When Peitruszewski originally made his case to the mobile team, he identified Gutenberg/Aztec as a basic infrastructure that has the potential to enable many different apps:</p>



<blockquote class=\"wp-block-quote\"><p>And that infrastructure is sorely lacking. There are very few rich text editor libraries on both iOS and Android &mdash;&nbsp;and most of them suck. And if you want an editor that has a shared API for both platforms&hellip;&nbsp;you&rsquo;re stuck. There are no options &ndash; Gutenberg is the only game in town (and it&rsquo;s really good).</p><p>And it&rsquo;s very hard to create this infrastructure. WYSIWYG editors are very hard, and it takes entire teams years to develop them (and they still usually suck). Almost no-one has the resources to develop it just for themselves, and if they do, they&rsquo;re unwilling to open-source it.</p></blockquote>



<p>Automattic&rsquo;s mobile app engineers have <a href=\"https://twitter.com/danroundhill/status/1296941098393190401\">struggled to get regular contributions to the apps</a>, despite them being open source. Dual licensing Gutenberg could open up a new world of contributors with the editor being used more widely across the industry.</p>



<p>&ldquo;While we might not be big enough to be able to tackle a challenge of developing a rich text editor from scratch, we&rsquo;re big enough to contribute features and bug fixes to open source projects,&rdquo; Pietruszewski said.</p>



<p>Matt Mullenweg was the first comment on Biais&rsquo; post in favor of the change: </p>



<blockquote class=\"wp-block-quote\"><p>I think&nbsp;Gutenberg&nbsp;has a chance to become a cross-CMS standard, giving users a familiar interface any place they currently have a rich text box. There are hundreds and hundreds of engineers at other companies solving similar problems in a proprietary way, it would be amazing to get them working together but a huge barrier now is supporting Gutenberg in mobile apps, which every modern web service or CMS has. (Hypothetically, think of Mailchimp as a possible consumer and collaborator here, but it could be any company, SaaS, or other&nbsp;open source&nbsp;CMS.)</p></blockquote>



<p>Unless any major blockers come up in further discussion, this dual licensing change appears to be on track to move forward. Biais noted that a&nbsp;<a href=\"https://github.com/wordpress-mobile/AztecEditor-Android/pull/922\">similar&nbsp;license change has already happened on Aztec-Android</a>&nbsp;and&nbsp;<a href=\"https://github.com/wordpress-mobile/AztecEditor-iOS/issues/1299\">Aztec-iOS</a>. The last hurdle is gaining the approval of all the original code contributors or rewriting the code for those who decline to give approval. </p>



<p>Once Gutenberg can be used under the MPL v2.0, the editor will gain a broader reach, with people already on deck wanting to use it. Other companies and projects that are normally outside WordPress&rsquo; open source orbit will also have the opportunity to enrich Gutenberg&rsquo;s ecosystem with contributions back to the project. At the same time, the MPL 2.0 protects Gutenberg from companies that would try to re-release the code as a closed-source project.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Sep 2020 22:59:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"WPTavern: GitHub to Use ‘Main’ Instead of ‘Master’ as the Default Branch on All New Repositories Starting Next Month\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=105014\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:269:\"https://wptavern.com/github-to-use-main-instead-of-master-as-the-default-branch-on-all-new-repositories-starting-next-month?utm_source=rss&utm_medium=rss&utm_campaign=github-to-use-main-instead-of-master-as-the-default-branch-on-all-new-repositories-starting-next-month\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4844:\"<p class=\"has-drop-cap\">In August, GitHub <a href=\"https://github.blog/changelog/2020-08-26-set-the-default-branch-for-newly-created-repositories/\">announced that it would change</a> the &ldquo;master&rdquo; branch name for all new repositories created on the platform to &ldquo;main&rdquo; starting October 1. The date is less than two weeks away, and WordPress developers need to be prepared for the change if they use the service for version control or project management.</p>



<p>The larger tech and web development community began conversations through various venues in June, a time in which the Black Lives Matter was gaining more traction in the U.S. and worldwide. The discussion centered on removing any terminology that could be discriminatory or oppressive to specific groups of people. This ongoing discussion has shown that there is a deep division over whether such changes are necessary or even helpful.</p>



<p>The WordPress community is dealing with this division itself. Aaron Jorbin <a href=\"https://make.wordpress.org/core/2020/06/18/proposal-update-all-git-repositories-to-use-main-instead-of-master/\">proposed a change</a> at the same time to rename the default branch name on WordPress-owned repositories. Through discussion on his post and elsewhere, the community landed on &ldquo;trunk,&rdquo; which keeps WordPress projects in line with its SVN roots.</p>



<p>&ldquo;To close the circle on this, a decision was made in June and earlier today (August 19),&rdquo; <a href=\"https://make.wordpress.org/core/2020/06/18/proposal-update-all-git-repositories-to-use-main-instead-of-master/#comment-39524\">wrote Helen Hou-Sand&iacute;</a>, a lead WordPress developer, in the comments of the original proposal. &ldquo;I updated the default branch name for new GitHub repositories under the WordPress organization to be trunk after GitHub enabled early access to that feature.&rdquo;</p>



<p>As evidenced by the comments on the <a href=\"https://wptavern.com/proposal-to-rename-the-master-branch-from-wordpress-owned-git-repositories\">Tavern&rsquo;s coverage of the proposal</a> and those on the original post, the WordPress development community as a whole did not support this decision.</p>



<p>Jorbin has updated several of WordPress&rsquo;s repositories and switched them to use <code>trunk</code> instead of <code>master</code>. However, there are still some lingering projects yet to be updated, including the primary <a href=\"https://github.com/WordPress/WordPress\">WordPress</a> and <a href=\"https://github.com/WordPress/wordpress-develop\">WordPress Develop</a> repositories. He left a <a href=\"https://make.wordpress.org/core/2020/06/18/proposal-update-all-git-repositories-to-use-main-instead-of-master/#comment-38817\">comment with an updated lis</a>t in June. There is no public word on whether the existing, leftover projects will be changed.</p>



<h2>WordPress Developer Preparations</h2>



<img />Customizing the default branch for a user&rsquo;s GitHub repositories.



<p class=\"has-drop-cap\">GitHub is merely changing the default branch name for new repositories starting on October 1. This change does not affect existing repositories. Individual users, organization owners, and enterprise administrators can customize the default branch via their account settings now before the switch is made. Owners can also change the default branch name for individual repositories.</p>



<p>The biggest thing that developers need to watch out for is their tooling or other integrations that might still require the master branch. There may be cases where an alternative default branch name will break workflows. If planning to use a different branch name, the best thing to do right now is to spin up the tools you use on a test repository. If something breaks, check to see whether the particular tool you are using will be getting an update. In most cases, this should not be a problem because customized default branch names will be an industry standard.</p>



<p>The great thing about how GitHub is rolling out this feature is that it offers a choice. Those who believe that &ldquo;master&rdquo; is oppressive can change the branch name to something they feel is more inclusive. For those who believe otherwise, they can keep their master branch. But, everyone can use the branch name they prefer.</p>



<p>For existing repositories, GitHub is asking that developers be patient for now. The company is investing in tools to make this a seamless experience <a href=\"https://github.com/github/renaming#later-this-year\">later this year</a>. There are a few technical hurdles to clear first.</p>



<p>Developers should read the full GitHub guide on <a href=\"https://docs.github.com/en/github/administering-a-repository/setting-the-default-branch\">setting the default branch</a> for more information.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Sep 2020 20:39:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:125:\"WPTavern: Matt Mullenweg and Jamstack Community Square Off, Making Long-Term Bets on the Predominant Architecture for the Web\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=104428\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:293:\"https://wptavern.com/matt-mullenweg-and-jamstack-community-square-off-making-long-term-bets-on-the-predominant-architecture-for-the-web?utm_source=rss&utm_medium=rss&utm_campaign=matt-mullenweg-and-jamstack-community-square-off-making-long-term-bets-on-the-predominant-architecture-for-the-web\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:19953:\"<p>Over the past two weeks, Matt Mullenweg and Jamstack community leaders have forged a new rivalry, after Mullenweg told <a href=\"https://thenewstack.io/wordpress-co-founder-matt-mullenweg-is-not-a-fan-of-jamstack/\">The New Stack</a> that he sees Jamstack as &ldquo;a regression for the vast majority of the people adopting it.&rdquo;  </p>



<p>&ldquo;The usability and functionality is actually lower,&rdquo; Mullenweg said to Richard MacManus in an email. &ldquo;Even rebuilding sites in Jamstack harkens back to the Movable Type days, where the bigger your site gets the slower it is to rebuild or update templates.&rdquo; </p>



<p>Mullenweg also described a &ldquo;fragile&rdquo; chain of services required to run Jamstack sites.</p>



<p>&ldquo;You can patch together a dozen services, each with its own account and billing, for hundreds of dollars a month, to get a similar result you&rsquo;d have for a few dollars a month using WordPress on shared hosting,&rdquo; he said. &ldquo;And it would be more fragile, because the chain is only as strong as its weakest link. You are chaining together different toolsets, logins, billing, hosting&hellip; any part of it going down can break the entire flow.&rdquo;</p>



<p>Mullenweg has since further <a href=\"https://wptavern.com/matt-mullenweg-clarifies-jamstack-remarks\">clarified his comments</a> while also doubling down on his original premise, saying that &ldquo;there isn&rsquo;t a vast number of people adopting Jamstack in the first place, and those who do are probably fully aware of the tradeoffs.&rdquo; He outlined how he sees WordPress providing a better experience for users in terms of performance, security, scaling, and developer experience.&nbsp;</p>



<p>Mullenweg&rsquo;s provocative remarks set off a chain of open letters from the CEO&rsquo;s of Jamstack-related services. They are convinced that the LAMP stack is on its way out and that Jamstack is on the precipice of replacing its incumbent as the most dominant architecture of the web. </p>



<p>Ohad Eder-Pressman, co-founder and CEO of <a href=\"https://www.stackbit.com/\">Stackbit</a>, was the first to fire back. He believes that Jamstack is a &ldquo;disruptive innovation&rdquo; that may appear to be inferior now because it is still relatively low level and new when compared to a 17-year old product like WordPress.</p>



<p>&ldquo;We should be asking whether Jamstack is a better architecture than LAMP and what gaps currently exist with products and solutions built on top of the Jamstack,&rdquo; Eder-Pressman said. He agreed that Jamstack tools are still largely focused on developers but makes a bold prediction on the stack&rsquo;s future reach:</p>



<blockquote class=\"wp-block-quote\"><p>The achievements of WordPress in terms of market share and how it democratized early web publishing are amazing. When it comes to architecture I think it was best in class for the early 2000s but it&rsquo;s time to move forward. We already see cohorts of websites where Jamstack adoption crosses 20% &ndash; it&rsquo;s no longer a question of if the Jamstack becomes the predominant architecture for the web but a question of when. The cliche is a cliche but it also rings true &ndash;&nbsp;<strong>First, they ignore you, then they laugh at you (we are here), then you win</strong>.</p></blockquote>



<p>Eder-Pressman agreed with Mullenweg regarding Jamstack&rsquo;s lower usability and functionality but touted the architecture as &ldquo;infinitely more resilient&rdquo; due to being hosted on a CDN. He admitted that rebuilding larger sites can be slow but cited developments like build parallelization, build cache, partial rebuild, and incremental static regeneration as&nbsp;optimizations as efforts the Jamstack ecosystem&nbsp;is exploring to solve this known issue.</p>



<p>Netlify&nbsp;CEO Mathias Biilmann, who originally coined the term &ldquo;Jamstack,&rdquo; goes so far as to hail &ldquo;the end of the WordPress era&rdquo; in his <a href=\"https://www.netlify.com/blog/2020/09/15/on-mullenweg-and-the-jamstack-regression-or-future/\">article</a> refuting Mullenweg&rsquo;s remarks. </p>



<p>&ldquo;There&rsquo;s often a moment right around the time when an old technology is about to be displaced by the next thing, where the main leader in the field goes out and makes a strong argument that absolutely nothing is happening,&rdquo; Biilmann said. &ldquo;A moment that ends up looking like a turning point where the new was undeniably present enough to be worth being in denial about.&rdquo;</p>



<h2>The Bet: By September 2025, what will be the predominant architecture for the web?</h2>



<p>In a brief exchange on Twitter, Mullenweg and Eder-Pressman made a wager for five years into the future, to see if Eder-Pressman&rsquo;s prediction will hold up, as measured by the Alexa top 10k. In order for Jamstack to become the predominant architecture for the web, it will need to surpass WordPress&rsquo; numbers, which are currently hovering at <a href=\"https://trends.builtwith.com/cms/WordPress\">39.75%</a> (via BuiltWith) and <a href=\"https://w3techs.com/technologies/details/cm-wordpress\">38.4%</a>&nbsp;(via w3techs).</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">They currently have us ~37% of top 10k. I wonder if you\'re undercounting us with YC companies too? <a href=\"https://t.co/ki9Ng3DGqI\">https://t.co/ki9Ng3DGqI</a></p>&mdash; Matt Mullenweg (@photomatt) <a href=\"https://twitter.com/photomatt/status/1302048647882784769?ref_src=twsrc%5Etfw\">September 5, 2020</a></blockquote>
</div>



<p>&ldquo;I&rsquo;m happy to make a long bet: 1 year, 5 years, 10 years,&rdquo; Mullenweg said in another <a href=\"https://twitter.com/photomatt/status/1306368508792504321\">thread</a> in response to Netlify&rsquo;s CEO. &ldquo;We&rsquo;re building and rebuilding WordPress to be generational. We&rsquo;ve navigated and created bigger architectural shifts in the past, and will do so in the future.&rdquo;</p>



<p>&ldquo;I&rsquo;m a developer, founder, and investor in the space of web technologies &ndash; if I&rsquo;m not willing to engage in a public discussion and share my predictions for where the web is heading then what merit does my work have?&rdquo; Eder-Pressman said when I asked him why he was willing to make this public wager.</p>



<p>&ldquo;I felt compelled given Mullenweg&rsquo;s comments and what I believe is the lack of appreciation for how much adoption and momentum Jamstack technologies already have. If anything I would say that my bet is actually pretty cautious.&rdquo;</p>



<p>Eder-Pressman and his team at Stackbit are working on a tool to track Jamstack adoption across the web, as BuiltWith does not yet have a Jamstack stat panel that correctly aggregates all the technologies associated with this relatively new category of websites.</p>



<p>&ldquo;We&rsquo;ve built an internal tool that tracks adoption of Jamstack technologies across different cohorts of websites which we find informative,&rdquo; he said. &ldquo;This isn&rsquo;t unlike what say Builtwith provides except that we track a few technologies that they don&rsquo;t and we bundle this into a Jamstack adoption indicator. We&rsquo;ve used this internally up until now and are planning to release some public facing version of it later this year.&rdquo;</p>



<p>As the CEO of Stackbit, a service that cranks out Jamstack sites in 60 seconds while bypassing any requirement to use the command line or download npm packages, Eder-Pressman is actively engaged in trying to bring this technology stack to the masses. The company aims to solve the very problems that Mullenweg identified in his critical comments, as is evident in the marketing copy on the Stackbit website. It acknowledges that piecing together a Jamstack website can be challenging even for developers:</p>



<blockquote class=\"wp-block-quote\"><p>&ldquo;In a fragmented Jamstack environment, developers struggle to glue products together when trying out the latest tech. Stackbit connects the best tools on the market, and helps them play together.&rdquo;</p></blockquote>



<p>A year ago, Stackbit caught my attention and I contacted them to find out when WordPress would land among their list of CMS import options. At that time they said they were considering WordPress as a headless CMS option but did not have it on the immediate roadmap. One year later, Stackbit is no closer to building import capabilities for the most popular CMS on the web.</p>



<p>&ldquo;It&rsquo;s on the horizon but its not something we&rsquo;ve prioritized,&rdquo; Eder-Pressman said. &ldquo;WordPress is a full blown monolithic CMS. It has been used before as a headless CMS but there are better headless CMS choices out there. Even Mullenweg <a href=\"https://twitter.com/photomatt/status/1302028302530404353\">agrees</a> it&rsquo;s a complicated premise.&rdquo;</p>



<p>When asked if his recent conversations have changed the company&rsquo;s plans to support WordPress imports, he said, &ldquo;No, it doesn&rsquo;t make us want to do this any more or less. I really enjoyed the conversation and am glad that Mullenweg recognizes the rise of the Jamstack so much so that he found it necessary to take aim at it. We as a company are driven by the market, user demand, growth opportunities and a healthy vision for the future of the web.&rdquo;</p>



<p>Jamstack will need to make itself accessible to the wide world of non-technical website owners if its advocates hope to capture any meaningful segment of the Alexa top 10k marketshare. Stackbit, for one, is still grossly underestimating WordPress&rsquo; ability to sustain its <a href=\"https://joost.blog/cms-market-share-june-2020-analysis/\">phenomenal growth</a>, and doesn&rsquo;t see the necessity for creating a simple path to convert WordPress users. Eder-Pressman believes that making Jamstack accessible starts with developers.</p>



<p>&ldquo;The Jamstack is an architecture which is winning the minds of developers around the world and across the web development stack,&rdquo; he said. &ldquo;Adoption for new architectures often begins with developers so I&rsquo;m excited to see a company like say Netlify boast over 1 million developers on its Jamstack platform.&rdquo; </p>



<p>Eder-Pressman&rsquo;s tool for measuring Jamstack adoption will need to produce some compelling data on the stack&rsquo;s growth, if his bet is going to materialize. While nearly every offering in the Jamstack ecosystem still falls squarely within the realm of experienced developers, it doesn&rsquo;t seem likely that five years is enough time for it to overtake WordPress as the predominant architecture for the web. WordPress hasn&rsquo;t achieved its dominance by prioritizing developer happiness over usability.</p>



<p>Looking at the numbers five years from now, will we see Jamstack overtake WordPress as the most popular way to build a website? Will Jamstack grow with developer usage and then plateau once it fails to reach regular people who don&rsquo;t have a git-based workflow at the top of their wishlists? Are we going to find Jamstack and WordPress neck and neck in the battle for the predominant architecture for the web? Those who work with a hybrid of both technologies see no need for this kind of rivalry.</p>



<h2>Shifting the conversation towards collaboration: &ldquo;Jamstack can be an opportunity for our industry, rather than a threat.&rdquo;</h2>



<p>&ldquo;Reading Mullenweg&rsquo;s comments and the responses from CEOs in the Jamstack community make me feel caught in the middle and a bit frustrated,&rdquo; <a href=\"https://www.getshifter.io/\">Shifter</a> COO Daniel Olson said. &ldquo;I see friction between two communities that have so much in common.&rdquo;</p>



<p>Olson has been a proponent of using Jamstack with WordPress for the past four years since launching Shifter, a static site generator and hosting company that supports headless WordPress sites on the Jamstack. </p>



<p>&ldquo;If you look for the most secure, cost-effective way to build and host a high-traffic website today, the cross-section you&rsquo;ll arrive at is the Jamstack. Looking at how it offers each of those benefits, you will find inspiration and ways WordPress could do the same,&rdquo; Olson said. &ldquo;Rather than write something off wholesale, see what you can learn and apply it.&rdquo;</p>



<p>Olson said his mission is to bridge the gaps between WordPress and the benefits Jamstack offers, while working through its early days and messy parts, innovating on the tools that work.</p>



<p>&ldquo;We should be working together to address specific challenges and worry less about how we get there,&rdquo; Olson said. &ldquo;Some technologies are indeed a better fit for solving each of those challenges but you don&rsquo;t need to leave one ecosystem for the other to do it. You can share knowledge and best practices and discover what&rsquo;s possible. There&rsquo;s a good chance you&rsquo;ll end up creating something new, which is part of that innovation we need in our communities.&rdquo;</p>



<p>Jamstack hosting services for WordPress are eager to remind users that they don&rsquo;t have to go all in on the technology. You can have your JAM and spread it on top of WordPress, accommodating developers&rsquo; love for experimenting with new frontend technologies, while preserving the dynamic publishing power that has been refined over the past 17 years. These hybrid hosting companies aim to enable this without leaving users behind. </p>



<p>&ldquo;Matt is absolutely right that the usability and functionality of the Jamstack is lower,&rdquo; <a href=\"https://www.strattic.com/\">Strattic</a> co-founder and CEO Miriam Schwab said. &ldquo;The Jamstack is a great example of technology that is incredibly appealing to developers, but the actual end users &ndash; writers, marketers, business owners &ndash; cannot use it. I&rsquo;ve heard many stories of major companies that have come to the decision to adopt Jamstack for all web development as a company-wide policy, only to find that their marketing team has gone rogue and is installing WordPress sites in order to get their job done.</p>



<p>&ldquo;The reason for this is like Matt said: every Jamstack site is a compilation of layers of services, and each layer has dozens of options available: you need a static site generator, a CMS, static hosting, and a CDN &ndash; and you need to tie it all together with version control. This is all cool and shiny, and the output is truly fantastic because when you have a site that&rsquo;s a collection of pre-rendered static files served up through a CDN it&rsquo;s fast, secure, scalable and stable. But then along comes marketing and they want to set up a landing page and they are totally dependent on their dev team and can&rsquo;t move forward without them. That defeats the purpose of a CMS-driven website! With WP, you get all the layers in one platform&hellip;but you don&rsquo;t get the awesome output.&rdquo;</p>



<p>Schwab said she sees WordPress having its age work both for it and against it, but ultimately she believes in enabling real world users to manage their own websites without having to rely on developers. </p>



<p>&ldquo;I&rsquo;ve seen many companies abandon WP for the shiny new stack, and then come back to it,&rdquo; Schwab said. &ldquo;Github is a good example of this &ndash; yes Github, the modern repository of cutting-edge code moved their blog off of WordPress, and then came back because it truly is the best tool for just getting your content out there. There aren&rsquo;t a zillion steps and integrations &ndash; you write content, click Publish, and that&rsquo;s it. It gets the job done, and the fanciest tools will never beat something that just gets the job done.&rdquo;</p>



<p>At the same time, WordPress needs to be open to enabling diverse frontend implementations, if it wants to remain relevant for the next decade. &ldquo;WP is running on legacy architecture,&rdquo; Schwab said. &ldquo;It&rsquo;s showing its age, and it&rsquo;s not appealing to new generations of developers. We need to keep WordPress appealing and interesting to developers in order to secure its future for years to come. If we don&rsquo;t make developers excited, we will inevitably see a decline.&rdquo;&nbsp;She encourages the WordPress community to embrace Jamstack as &ldquo;a breath of fresh air.&rdquo; </p>



<p>&ldquo;Jamstack can be an opportunity for our industry, rather than a threat,&rdquo; Schwab said. &ldquo;There are ways for the two industries to collaborate, like in the case of headless WP deployments using Gatsby.&rdquo;</p>



<p>Unlike many other Jamstack service companies, the team behind Gatsby has <a href=\"https://wptavern.com/gatsby-raises-15m-plans-to-invest-more-heavily-in-wordpress-and-cms-integrations\">more readily embraced WordPress</a> as a data source and a critical component of its continued success. The company <a href=\"https://wptavern.com/jason-bahl-joins-the-gatsby-team-to-work-on-wpgraphql-full-time\">hired Jason Bahl</a>, creator of the GraphQL for WordPress project, to work on WPGraphQL (and its immediate ecosystem) full-time, while providing a bridge to the WordPress world.</p>



<p>&ldquo;Maybe I&rsquo;m getting caught up in semantics, but the JAM in JAMStack means JavaScript, APIs and Markup,&rdquo; Bahl said. &ldquo;It wasn&rsquo;t long ago when Matt prescribed the WordPress ecosystem to &lsquo;Learn JavaScript Deeply,&rsquo; and not long after that when a Jamstack application called Gutenberg was merged into WordPress core, along with React. Gutenberg is the JavaScript, the WP REST API is the API and the end result is markup. Jamstack isn&rsquo;t a regression, it&rsquo;s a future that Automattic is helping drive WordPress toward.&rdquo;</p>



<p>When Mullenweg says he is ready to build and rebuild WordPress to be generational, it&rsquo;s a promise he has already delivered on by introducing the React-based Gutenberg editor two years ago, successfully pushing past an enormous amount of resistance from the developer community.</p>



<p>Bahl said he sees this continued legacy of improvement happening over and over again in various ways, made possible by WordPress&rsquo; pluggable system:</p>



<blockquote class=\"wp-block-quote\"><p>WordPress ships with a lot of APIs, but often they are replaced with something newer and better. For example, it&rsquo;s common for sites to offload images to a CDN instead of use the built-in file system for media. Or instead of using built-in WordPress MySQL search, users will reach for ElasticSearch, Algolia or Solr. In the case of WordPress and the JAMStack, reaching for Next, Gatsby or Gridsome to replace the built-in Theme API isn&rsquo;t a regression, it&rsquo;s using newer technology to handle things that built-in parts of WordPress might not do as well. The Theme API of WordPress is just one API and replacing it with technology that does the job better isn&rsquo;t a regression.</p></blockquote>



<p>Gatsby&rsquo;s build step, which has received <a href=\"https://twitter.com/tesseralis/status/1293649015020457984\">negative attention in the news</a> recently, is one example of what Bahl thinks Mullenweg was referring to as a regression for users. Bahl is working with Gatsby to reduce the friction associated with decoupled architectures when using WordPress as the API in Jamstack.</p>



<p>&ldquo;I don&rsquo;t see Jamstack competing against WordPress,&rdquo; Bahl said. &ldquo;In my mind, Jamstack with WordPress as the API is the future of the web. WordPress is the best CMS. Gatsby specifically is trying to embrace this. This isn&rsquo;t a zero sum game. If the Gatsby + WordPress experience can allow users to use the best CMS in the world while using modern dev tooling, it&rsquo;s a win all around.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 19 Sep 2020 18:54:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"WPTavern: Matt Mullenweg Clarifies Jamstack Remarks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=104883\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:147:\"https://wptavern.com/matt-mullenweg-clarifies-jamstack-remarks?utm_source=rss&utm_medium=rss&utm_campaign=matt-mullenweg-clarifies-jamstack-remarks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6205:\"<p>Two weeks ago, Matt Mullenweg made some pointed remarks in an article from <a href=\"https://thenewstack.io/wordpress-co-founder-matt-mullenweg-is-not-a-fan-of-jamstack/\">The New Stack</a>, calling Jamstack &ldquo;a regression for the vast majority of the people adopting it.&rdquo; In preparation for an upcoming article that will include comments from leaders across both the WordPress and Jamstack communities, I asked Mullenweg if he stands by his remarks characterizing Jamstack as a regression. His response was lengthy and is printed here in its entirety to preserve cohesion.</p>



<p><strong>Q: Do you stand by your remarks that Jamstack is a regression for the vast majority of the people adopting it?</strong></p>



<p><strong>Answer:</strong></p>



<p>&ldquo;Vast majority of people adopting it&rdquo; was probably too harsh, because there isn&rsquo;t a vast number of people adopting Jamstack in the first place, and those who do are probably fully aware of the tradeoffs. There are some good reasons, for certain situations, to decouple and add complexity to your architecture, and WordPress&rsquo; REST API works fantastically as a backend there. But I worry they are over-selling the promise of what&rsquo;s really an architectural decision. If&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://jamstack.org/\">you look at the benefits they purport</a>,&nbsp;it&rsquo;s better performance, security, scaling, and developer experience:</p>



<img />



<p><strong>Better Performance:</strong> You can achieve the same performance by putting a great CDN like Cloudflare on top of WordPress, and your life will be infinitely easier when you want to add dynamic features like a store or comments. You can also easily find a static WordPress host like&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://www.strattic.com/\">Strattic</a>&nbsp;or&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://www.getshifter.io/\">Shifter</a>.</p>



<p><strong>Higher security:</strong> I don&rsquo;t believe that introducing a number of proprietary and sub-scale SaaS services like Netlify into your stack will make your site more secure. I believe the most secure thing you can do is run fully open source code, as widely vetted and used as possible, on servers you control, or from the fewest number of vendors possible. WordPress securely runs some of the most attacked websites on the internet, including major media, Facebook, and&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://whitehouse.gov/\">WhiteHouse.gov</a>. Having this many moving parts doesn&rsquo;t inspire confidence:</p>



<img />



<p><strong>Cheaper, easier scaling:</strong> CDNs are more expensive than normal hosting accounts, and you can get WordPress running on a decent host for less than $5/mo. And there are even more powerful offerings: The personal plan on&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://wp.com/\">WP.com</a>&nbsp;can serve tens of millions of visitors per day, to the website or the headless API, includes a global CDN, and a domain name for $4/mo, and we still have a profit margin.&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://graphcms.com/pricing\">GraphCMS starts at $29/mo and only gives you &ldquo;5,000 entities,&rdquo;</a> whatever that means.&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://www.contentstack.com/pricing\">Contentstack is $3,500/mo</a>. And that&rsquo;s just for the headless CMS part! You still need to sign up and pay for a bunch of the other stuff in that graphic before you have a website a human can visit in a browser.</p>



<p><strong>Better developer experience:</strong> If your developer wants to copy and paste updates from marketing to the website, sure, but if they want people to be able to update the website without their help, they should go with something easier for users like WordPress. If you&rsquo;re curious about the developer experience, or an investor thinking about this space, I really suggest you watch this three hour and thirty minute tutorial to really understand what is being sold under the premise of &ldquo;better&rdquo;:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>Have I ever built stuff like that? Totally! It can be a ton of fun, like building a rocket at home or fixing up an old car. I&rsquo;ve seen some awesome sites built on decoupled architectures or static publishing, using headless WordPress rather than the CMS&rsquo;s above, but still a similar idea. People are trying to paint me as being against Jamstack, but that is as foreign to me as being against duct tape &mdash; it&rsquo;s good for some things, bad for others, and it&rsquo;s not going away. I just wish they would be more intellectually rigorous and honest when marketing it. I expect a Jamstack-like approach to exist forever, just like the ideas behind Jamstack pre-date it getting jammed down our throats by Netlify&rsquo;s marketing team.</p>



<p>Biilmann has got the Ballmer / iPhone story backwards &mdash;&nbsp;Microsoft&rsquo;s mistake there was they made something too complicated, and the iPhone simplified it. Jamstack introduces numerous vendors, build steps, network calls, interfaces, even billing relationships for something that&rsquo;s a single button press in WordPress.</p>



<p>The reason services like&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://wordpress.com/\">WordPress.com</a>&nbsp;and Shopify are growing so much is they are taking things that were complicated and making them simpler and accessible to a much wider audience. My mission is to democratize publishing and commerce, to make it radically accessible to everyone regardless of technical or economic ability, and increase the freedom and openness on the internet.&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://twitter.com/photomatt/status/1306368508792504321\">As I said on Twitter</a>, the first 15 years of WordPress were just the first few chapters. I&rsquo;m looking forward to building and rebuilding the platform the rest of my lifetime, and when that comes to an end I hope future generations will carry the torch.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Sep 2020 22:49:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Gutenberg’s Custom Spacing Should Be Theme Controlled\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=104867\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:169:\"https://wptavern.com/gutenbergs-custom-spacing-should-be-theme-controlled?utm_source=rss&utm_medium=rss&utm_campaign=gutenbergs-custom-spacing-should-be-theme-controlled\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5679:\"<img />Adjusting padding on a Group block.



<p class=\"has-drop-cap\">When <a href=\"https://wptavern.com/gutenberg-9-0-brings-major-improvements-to-navigation-screen-and-query-block\">Gutenberg 9.0 landed</a> earlier this week, it came with an experimental <a href=\"https://github.com/WordPress/gutenberg/pull/24966\">padding control</a> for the Group block. Most users will not see it unless their theme has opted into supporting the feature using the <code>experimental-custom-spacing</code> flag.</p>



<p>This was not the first that we have seen of the padding option on a block. <a href=\"https://wptavern.com/gutenberg-8-3-updates-block-categories-includes-parent-block-selector-and-adds-new-design-controls\">Gutenberg 8.3</a> introduced it for the Cover block. Since then, nothing has changed with the implementation.</p>



<p>The problem with the custom spacing/padding option is that it creates an inline style that does not adjust based on the design of the theme. Fortunately, the feature is still experimental. This means that we have time to reevaluate how it works.</p>



<p>Unless we&rsquo;re doing away with any remaining illusion that themes will play an important aspect of WordPress&rsquo;s future and front-end design becomes fully entrenched within core, theme authors need some level of control. And, even if themes are going the way of the dinosaur, custom padding numbers on the block level will create design consistency issues down the road. Using 100 pixels of padding might make sense within a site&rsquo;s current design, but 96 pixels might make sense within a future design. When a user adds dozens or hundreds of blocks with custom padding today, it will wreak havoc on tomorrow&rsquo;s spacing and rhythm.</p>



<p>Besides that, the average user has little concept of design rules. Having a standardized system for spacing would give theme authors control over the output while giving end-users the ability to customize the look.</p>



<p>I have argued that WordPress needs some sort of <a href=\"https://wptavern.com/themes-of-the-future-a-design-framework-and-a-master-theme\">design framework</a>. For example, Tailwind CSS has specific padding classes. So does Bootstrap and nearly every other CSS framework. The web development community has been down this road. It is a well-trodden path, and WordPress is not innovating by using inline styles.</p>



<p>If the WordPress platform is going to put this sort of power into the hands of its users, it should do so in a way that allows designers to do their thing and not push users toward semi-permanent, inline-style soup in their content.</p>



<p>Pre-Gutenberg, I would have been entirely against the idea of WordPress introducing any sort of CSS or design framework. However, the platform is consistently moving toward becoming a UI-based design tool rather than simply a way to manage content. Users will have design-related options on a global scale all the way down to individual blocks. Users should absolutely have the ability to adjust a block&rsquo;s padding in such a system. They should not need an understanding of CSS to do so. Instead, for most use cases, users should be able to adjust padding based on whether they want larger or smaller spacing, not specific CSS values.</p>



<p>I propose a full set of standardized padding classes. The same would go for margins or other design-related options down the road. Gutenberg/WordPress should create a set of default values for these classes, which theme authors could override based on their design.</p>



<p>This is not a new concept. Dave Smith, a developer for Automattic, introduced a <a href=\"https://github.com/WordPress/gutenberg/pull/16730\">patch in 2019</a> that used named selectors for spacing on the Group block. He gave the following reasoning for choosing this approach over absolute values:</p>



<blockquote class=\"wp-block-quote\"><p>Imagine you are a Theme designer. You craft your CSS with spacing that is perfect for the design. You want to ensure that is consistent throughout your Theme, even if the page layout is being created by the end-user in the Block Editor.</p><p>With the approach I&rsquo;ve taken here, when a size is selected only classes are added to the Block in the DOM. This affords the Theme creator the opportunity to provide custom sizes in CSS that are suitable for their Theme. If they opt not to do this then sensible defaults are provided.</p><p>With the pixels approach, we&rsquo;re locking users of the Block into absolute values and asking them to make a lot of decisions that they&rsquo;d probably prefer not to have to make. It could also lead to an inconsistent visual experience.</p></blockquote>



<p>This ship has already sailed and sunk with custom colors and font sizes. Gutenberg had an opportunity to standardize class names for these options but left it to theme authors. As a result, there is no standard across the theme market, which means that choosing the &ldquo;large&rdquo; font size or the &ldquo;blue&rdquo; text color provided by the theme will likely not carry across to the user&rsquo;s next theme. Now, we are on the cusp of far more design-related options as WordPress moves toward full-site editing. It is time to consider some standards on design-related class names and provide a framework that all themes can use.</p>



<p>Gutenberg could still provide a <em>custom</em> padding option just like it does for colors and font sizes. Users who choose to go this route would be making an explicit choice to work outside of the standard. But, let&rsquo;s not go down this road of allowing users to set absolute spacing values as the default option.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Sep 2020 18:49:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: GoDaddy Acquires SkyVerge, Creator of Over 60 WooCommerce Add-Ons\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=104658\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:193:\"https://wptavern.com/godaddy-acquires-skyverge-creator-of-over-60-woocommerce-add-ons?utm_source=rss&utm_medium=rss&utm_campaign=godaddy-acquires-skyverge-creator-of-over-60-woocommerce-add-ons\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4911:\"<p class=\"has-drop-cap\">On September 14, GoDaddy <a href=\"https://aboutus.godaddy.net/newsroom/news-releases/press-release-details/2020/GoDaddy-Acquires-SkyVerge-to-Help-Everyday-Entrepreneurs-Sell-Online-with-WordPress-and-WooCommerce/default.aspx\">announced it had acquired SkyVerge</a>, a major WooCommerce-focused development company, for an undisclosed amount. At the moment, GoDaddy is playing it close to the vest in terms of its future plans. It has not publicly announced anything beyond a continued commitment to current customers.</p>



<p>The initial announcement makes note that SkyVerge&rsquo;s free plugins on WordPress.org have been downloaded more than 3.1 million times. However, the company&rsquo;s <a href=\"https://profiles.wordpress.org/skyverge/#content-plugins\">nine plugins in the directory</a> currently have over 155,000 active installs. Nevertheless, SkyVerge&rsquo;s real value is in its team and its impressive array of free and commercial add-on plugins available directly from its site.</p>



<p>WooCommerce is a cash cow for companies with the right products and marketing at the moment. GoDaddy seems to be going all-in on the back of WordPress&rsquo;s most popular eCommerce solution. It launched a <a href=\"https://wptavern.com/godaddy-launches-ecommerce-hosting-plan-in-partnership-with-woocommerce\">managed WooCommerce hosting plan</a> in October 2019. The hosting company has now added over 60 WooCommerce extensions to its inventory in one swoop.</p>



<p>&ldquo;As more small businesses and entrepreneurs go online, having a highly performant eCommerce experience is becoming more important than ever,&rdquo; said Rich Tabor, Senior Product Manager of WordPress Experience at GoDaddy. &ldquo;Late last year we launched a Managed WooCommerce offering, bundling many WooCommerce extensions in the Managed WordPress environment.&rdquo;</p>



<p>SkyVerge has quietly become a massively successful WordPress and WooCommerce business. It was bringing in <a href=\"https://www.starterstory.com/develop-ecommerce-tools\">$350,000 per month</a> at the end of 2019. There was no response on how well the business has performed thus far in 2020.</p>



<p>The entire SkyVerge team came along for the transition to GoDaddy. &ldquo;We&rsquo;re just beginning to deliver more capabilities and an even better setup and ongoing usage experience for our customers,&rdquo; said Tabor. &ldquo;The SkyVerge team will lead and accelerate those plans. They are an incredibly talented and innovative team that lives and breathes WooCommerce. Joining forces with them advances GoDaddy&rsquo;s WordPress strategy and enhances our ability to deliver intuitive eCommerce experiences that help everyday entrepreneurs sell online.&rdquo;</p>



<p>With so many extensions in place, the big question for average users is whether those extensions will become a part of GoDaddy&rsquo;s eCommerce hosting bundle. Tabor either did not or could not let slip any plans in the works. &ldquo;We&rsquo;re just beginning to determine how to best deliver SkyVerge&rsquo;s wonderful products to GoDaddy customers. SkyVerge brings a lot of great software. It&rsquo;s reasonable to expect we&rsquo;ll be delivering that to our customers who are selling online.&rdquo;</p>



<p>It is doubtful that GoDaddy went into this acquisition without at least some short-term plans or visions for how its managed hosting service would use these extensions. For now, we will have to wait and see.</p>



<p>It seems that the immediate plan will be to maintain business as usual. Tabor said GoDaddy had no changes to announce related to SkyVerge&rsquo;s products and website. &ldquo;We are committed to continuing support of SkyVerge&rsquo;s customers and investing in the SkyVerge software,&rdquo; he said.</p>



<p>SkyVerge also created <a href=\"https://jilt.com/\">Jilt</a>, which is an email marketing platform for eCommerce sites. The platform currently supports WooCommerce, Easy Digital Downloads, Shopify, and Shopify Plus. Tabor did not directly respond to what the future looked like for Jilt&rsquo;s non-WooCommerce customers nor did he give any indication of whether there were plans to expand Jilt to other eCommerce systems.</p>



<p>He did say that GoDaddy would continue to invest in its priority eCommerce platforms, which are WooCommerce and GoDaddy Websites + Marketing.</p>



<p>Max Rice, co-founder of SkyVerge, did leave some indication of Jilt&rsquo;s future in his <a href=\"https://www.skyverge.com/blog/skyverge-joins-godaddy/\">announcement post</a>. &ldquo;We made a commitment to be there for your business with software you can depend on, and we&rsquo;re sticking to it,&rdquo; he said. &ldquo;We&rsquo;ll continue to support our existing WooCommerce plugins and Jilt. While we&rsquo;ll be building something new at GoDaddy, everything we&rsquo;ve already built is a big part of that.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Sep 2020 20:59:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: Gutenberg 9.0 Brings Major Improvements to Navigation Screen and Query Block\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=104795\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:217:\"https://wptavern.com/gutenberg-9-0-brings-major-improvements-to-navigation-screen-and-query-block?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-9-0-brings-major-improvements-to-navigation-screen-and-query-block\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2749:\"<p>If you haven&rsquo;t played around with Gutenberg&rsquo;s experiments lately, the Navigation block is getting some exciting updates. Version 9.0 was released today with drag-and-drop support added to the list view of navigation items.  </p>



<img />



<p>Contributors have been <a href=\"https://github.com/WordPress/gutenberg/issues/24875\">working through several different prototypes</a> aimed at unifying the controls and simplifying the menu building process. The Navigation screen included in version 9.0 has been redesigned to <a href=\"https://github.com/WordPress/gutenberg/issues/25014\">improve the &ldquo;Create Menu&rdquo; flow</a> and includes the following changes:</p>



<ul><li>New&nbsp;<em>Header</em>&nbsp;and&nbsp;<em>Toolbar</em>&nbsp;components.</li><li><em>Manage Locations</em>&nbsp;has been rewritten and is now a popover.</li><li><em>Add New</em>&nbsp;form has been rewritten and now appears inline in the toolbar.</li><li><em>Automatically Add Pages</em>&nbsp;checkbox and&nbsp;<em>Delete menu</em>&nbsp;button has been rewritten and now appears in the block inspector.</li></ul>



<p>The screen is starting to take shape but is still very much a work in progress. If you want to test it, you can enable it under Gutenberg &gt; Experiments.</p>



<p>The Query block was another main focus fr the 9.0 release. It is taking a giant leap forward with new features like search, filtering by author, support for order/order by (date + title), and tags. This block should be tested locally and is still behind the&nbsp;<code>__experimentalEnableFullSiteEditing</code>&nbsp;flag since it requires full site editing blocks to display queried content.</p>



<img />



<p>Other notable UI enhancements include <a href=\"https://github.com/WordPress/gutenberg/pull/24852\">a new drag handle added to block toolbar</a> for drag-and-drop capability. (It is not visible on the top toolbar). Blocks can be dragged to other areas of a post as an alternative to using the up/down arrows.</p>



<img />



<p>This release also <a href=\"https://github.com/WordPress/gutenberg/pull/24472\">removes the Facebook and Instagram blocks</a> from the inserter, as Facebook will be&nbsp;<a href=\"https://wptavern.com/upcoming-api-change-will-break-facebook-and-instagram-oembed-links-across-the-web-beginning-october-24\">dropping unauthenticated oEmbed support</a>&nbsp;on October&nbsp;24. WordPress core is also set to remove Facebook and Instagram as an oEmbed provider in an upcoming release.</p>



<p>For a full list of all the enhancements, bug fixes, experiments, and documentation updates, check out the <a href=\"https://make.wordpress.org/core/2020/09/16/whats-new-in-gutenberg-16-september/\">9.0 release post</a> on WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Sep 2020 03:18:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"HeroPress: How To Become A Freelancer – A Few Things I Learned Before I Gave Up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=3280\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:206:\"https://heropress.com/essays/how-to-become-a-freelancer-a-few-things-i-learned-before-i-gave-up/#utm_source=rss&utm_medium=rss&utm_campaign=how-to-become-a-freelancer-a-few-things-i-learned-before-i-gave-up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:28154:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2020/09/091620-min.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: I realized that freelancing is not the only way to achieve my goals.\" /><p><a href=\"https://heropress.com/feed/#serbian\">Članak je takođe dostupan na sprskom jeziku.</a></p>
<p>Everyone’s story is unique. Our life journeys differ in so many aspects and these experiences shape us into who we are now. Therefore, things that we, as individuals, learn along the way can’t always apply to someone else’s life goals, potentials, aspirations, and struggles.</p>
<p>But, sometimes, knowing about other people’s mistakes and successes can help us navigate through our life challenges better. We can avoid making the same mistakes and, even better, we can get inspired to accomplish similar achievements.</p>
<p>That is why I decided to share a few things that I have learned by trying to become a freelancer. Spoiler alert &#8211; I’m a corporate employee now.</p>
<p>My career path was a bit unusual. I wasn’t quite tech-savvy until 5 years ago and my entire focus was around the fitness industry from 2006 until 2015. Being a fitness trainer was a dream job for me when I was 26 but, by the age of 35, it became somehow, well, boring.</p>
<p>Then I had a huge epiphany &#8211; numerous opportunities come with WordPress and freelancing was one of them. So, if you are at the stage of your life when becoming a freelancer seems like a good idea, read on.</p>
<p>I will try to break down 5 things that helped me in starting my freelance career. They are formulated as general tips for beginners but some of them can also be applied when changing the course of your career. So, let’s dive right in.</p>
<h3>Question your motives</h3>
<p>The first and the most important thing that you should ask yourself before you do anything in your life is why. “Why am I doing this?”</p>
<p>So, why do you want to become a freelancer?</p>
<p>Is it because you need an extra income? Or maybe because of flexible working hours. Or because you will be able to work from different locations? Or you see freelancing as just a phase before you get enough experience to open your agency and have others working for you.</p>
<blockquote><p>Be honest with yourself. List all the reasons why you want to become a freelancer. This will help you later on in choosing the right jobs or maybe in considering some other alternatives to freelancing.</p></blockquote>
<p>For example, these are my top 3 motives to become a freelancer:</p>
<ul>
<li>Opportunity to grow intellectually and learn new things</li>
<li>Flexible working hours (by not being forced to work 9 am to 5 pm every day, I was able to avoid the boring routine)</li>
<li>Peaceful and quiet working environment &#8211; quite opposite to the gym where everything is so loud</li>
</ul>
<p>So, after you question your goals and motives, and you are certain that you want to become a freelancer what’s next? My suggestion is &#8211; develop WordPress related skills.</p>
<h3>Get the skills &#8211; choose WordPress</h3>
<p>Why WordPress you might ask? Well, for a start, WordPress gives various opportunities and it is not a developer-only niche.</p>
<p>Although, when someone thinks of freelancing and WordPress, web developer and web designer are first associations, there is a huge variety of WordPress related freelance jobs:</p>
<ul>
<li>Web developer (coding websites, themes, and plugins)</li>
<li>Web implementor (creating websites from existing themes without coding)</li>
<li>Web designer (designing website mockups, editing images or creating infographics for websites)</li>
<li>Client support professional (helping people with their websites)</li>
<li>Website maintenance professional (takes care of the website to make sure that WordPress, themes, and plugins are up to date and new backups are created regularly)</li>
<li>WordPress teacher (teaching clients how to use WordPress or teaching other web professionals)</li>
<li>Content writer</li>
<li>Accessibility specialist (making sure that certain standards are met and suggesting solutions for accessibility barriers)</li>
<li>SEO consultant</li>
<li>Statistics consultant (especially for webshops)</li>
<li>WordPress assistant (adding new content and editing existing posts)</li>
<li>Website migration specialist (moving websites from one server to another)</li>
<li>Web security specialist</li>
</ul>
<p>Another reason why WordPress is great for freelancers is a strong community that exists around this CMS. There are regular meetups, WordCamps, and other events (they are now switched to online), where you can get a ton of useful information, and also get to ask like-minded people literally anything. The community is so large and diverse, that you will definitely find the answer to any question. It’s much easier to start your freelance career when you have such a great community around you.</p>
<h3>Plan in advance</h3>
<p>Now that you know where the opportunity lies, you can start planning your career.</p>
<p>Becoming a freelancer is a process. At the beginning of that process, you should acquire or improve relevant skills that will make you stand out in the freelance market. And, of course, as you learn and grow, you will be able to take more challenging and better-paid jobs.</p>
<p>Which skill should you focus on? If you already have a basic skill set for at least one of the previously listed jobs, you can improve your knowledge in that direction and specialize in that area.</p>
<p>However, if you don’t have any relevant skills, in my opinion, it would be the easiest to step into the freelancing world with a job that has a shorter learning curve and build your knowledge around that. Example &#8211; you can start with either content writing or as a web implementer since these jobs have a shorter learning curve than SEO related jobs or web development. Then, from content writing, you can expand your knowledge towards SEO and from a web implementer, you can become a developer. Just don’t stop learning.</p>
<p>Also, if you have specific talents or hobbies like writing or design, you can base your career on that.</p>
<blockquote><p>There is nothing better than doing what you love.</p></blockquote>
<p>Additionally, it would be a good idea to analyze the market before you jump into the learning process.</p>
<p>For example, now it would not be the best time to specialize in writing travel-related content, while it would be a great moment for any job related to webshops and online sales.</p>
<p>If you want to learn web development, web design, web security, or SEO, you should always focus on new trends, so your skills can be useful in the future as well.</p>
<p>For different jobs, working terms often vary so you should take this into consideration when choosing your career path. At some jobs, you can work flexible hours while at others you have to be available during predefined hours. This is what you should have in mind when specializing in a certain area or looking for a first job.</p>
<h3>Hurray, it’s time to get a first freelancing job</h3>
<p>If you currently have a job, it would be wise to either save some money before you quit your job to become a full-time freelancer or try freelancing for a few hours per week, in the beginning, to see if you like it or not. If you become successful and decide that freelancing is something that fits your needs, only then quit your job, not before.</p>
<blockquote><p>Although some people do benefit when taking a risk, think twice before you take any irreversible actions.</p></blockquote>
<p>And here are some tactics that worked for me when trying to get my first freelancing job:</p>
<p><i>Use a freelancing platform</i> &#8211; although this is not mandatory, it is much easier to get the first job when you are using a freelancing platform. My choice was Upwork back in the day, but there are several platforms that you can use to get the first job faster.</p>
<p><i>Triple-check your resume</i> &#8211; I guess that this is not something that I should mention but I will anyway, just in case. Don’t make spelling mistakes in your resume, it will give the impression that you are not thorough and that you will oversee mistakes in your other work as well.</p>
<p><i>Present yourself in a professional manner</i> &#8211; Take the time to present your professional skills in the best possible light but still stay humble. Don’t write: “Best WordPress developer that never wrote a bad code”. This is not evidence-based, and it will make you seem arrogant. Instead, you can write: “Web developer with 3 years of experience and over 50 satisfied clients, specialized in WordPress.” This statement is based on facts and it shows your credibility.</p>
<p><i>Fill up your portfolio</i> &#8211; If you have any previous work (that is presentable, of course) you should put it in your portfolio. Emphasis on presentable. If not, you can make a few websites, designs, or write some example texts if you are a content writer in order to showcase your skills. This is not applicable to all jobs, like SEO consultants or customer support but if you have the opportunity to create a portfolio, use the opportunity.</p>
<p><i>Use video material</i> &#8211; Short introductory video will make you stand out since making promotional video material is not something that many freelancers do. It will help you create a more human professional approach. For your clients, you will not be just a list of skills and previous experiences, but a real person that has these skills and experiences and that provides a certain service for them.</p>
<p><i>Have a detailed strategy when choosing your first employer &#8211;</i> Choose your first employer wisely, very wisely. I can’t emphasize enough how important this is so I will give you an example. When I had to apply for my first job, I considered the following:</p>
<ul>
<li>How this employer was rated by other freelancers which worked for him previously</li>
<li>How the employer rated other freelancers</li>
<li>How much money he had already spent on this platform and if he posts regular job offers</li>
<li>The number of open positions for this job and the number of freelancers that have already applied. In my case, the job had about 10 open positions so that amplified my chances of getting hired, even if the competition is high.</li>
</ul>
<p><i>The first job is not all about the money &#8211;</i> Don’t get greedy on your first job. If you get good reviews, your second job can be paid 2-3 times more. And your third job can go up to 5 times more. That was my experience at least.</p>
<h3>Be careful, you are an adult</h3>
<p>Individual responsibility is key when it comes to freelancing. You have the freedom to choose who you are going to work for, what kind of job are you going to take, and how it is going to be delivered. And freedom often comes with responsibility. They are like two sides of the same coin.</p>
<p>You should never miss a deadline. If you are not sure that you are going to be able to deliver, don’t take the job or as an alternative have someone very reliable as a backup, just in case. When you miss a deadline, your client loses money, and they have every right to be angry. This will very likely affect your reviews after the job is complete. And then, the opportunity to get your next job and so on. This can start a downward spiral for your career.</p>
<p>However, we are all humans and unpredictable things can happen. If for some reason you are not able to complete your work in a timely manner, let your client know immediately so they can have enough time to hire someone else.</p>
<p>Also, it is important to make everything clear in advance, before you accept the job. Let your clients know what your expectations are and make sure that you understand what they expect from you. For example, if you are a content writer, make sure that you know the length of the text in characters or words, ask if some keywords should be used and how frequently, what writing style your client prefers, and so on. And if you are a designer, specify how many revisions are included in the price.</p>
<blockquote><p>The clearer the initial arrangement is, the more satisfied both you and your client will be at the end.</p></blockquote>
<p>If you have flexible working hours, don’t let other people interrupt you. If your friends and family wouldn’t show up in your office every day if you were a bank clerk, they shouldn’t interrupt you when you work from home. It’s the same principle and it’s up to you to set the boundaries and let them know about your working schedule. It’s not up to them.</p>
<p>So, these are some basic guidelines that helped me in starting my freelance career and I hope that they will be helpful for you as well.</p>
<blockquote><p>There is no unique recipe and one size doesn’t fit all when it comes to the path you ought to take.</p></blockquote>
<p>It’s just important to stay focused on your goals and to be open to new opportunities.</p>
<p>If you were wondering why I’m not a freelancer anymore, this is where the answer lies. By constantly being interested in different opportunities, I realized that freelancing is not the only way to achieve my goals. There are companies that offer flexible working hours and peaceful work environment while stimulating professional growth and creative thinking.</p>
<p>Plus I gained something very precious by joining a team &#8211; my colleagues became my support system both professionally and privately, and that is what I have been missing while being a freelancer.</p>
<p>I wish you a lot of luck and success in the future, regardless of the path you choose to take.</p>
<h1 id=\"serbian\">Kako postati frilenser &#8211; stvari koje sam naučila pre nego što sam odustala</h1>
<p>Naše životne priče su različite. Svako od nas ima svoj jedinstveni životni put, a iskustva koja steknemo oblikuju nas u osobe koje smo danas. Zbog toga, stvari koje mi, kao pojedinci, naučimo na svom putu ne mogu uvek lako da se primene na situacije kroz koje prolazi neko drugi.</p>
<p>Ipak, ponekad sagledavanje tuđih uspeha i grešaka može da nam pomogne da se bolje snađemo u sopstvenim životnim izazovima. Možemo da izbegnemo da napravimo istu grešku koju je napravio naš prijatelj ili, još bolje, možemo postati motivisani da postignemo jednak ako ne i veći uspeh kao neko iz našeg okruženja.</p>
<p>Zbog toga sam odlučila da sa vama podelim ono što sam naučila pokušavajući da postanem frilenser. Spoiler alert &#8211; sada sam zaposlena u korporacji.</p>
<p>Moja karijera je isla pomalo neuobičajenim putem. Nisam uopšte bila naklonjena informatici do pre pet godina. Tačnije nisam znala skoro ništa o toj oblasti. Bila sam potpuno fokusirana na fitnes industriju i radila sam isključivo kao fitnes trener od 2006. do 2015. To je za mene bio posao iz snova dok sam bila mlađa ali mi je oko moje 35. godine već pomalo dosadio.</p>
<p>Tada sam otkrila WordPress i shvatila da se mnogobrojne prilike otvaraju bas sa poznavanjem ove platforme. A frilensing je jedna od njih. Tako da, ako ste trenutno u fazi kada vam se frilensovanje čini kao dobra ideja, nastavite da čitate.</p>
<p>Pokušaću da detaljno opišem pet stvari koje sam naučila pokušavajući da postanem frilenser. Formulisala sam ih kao uopštene savete za početnike, ali neki od njih mogu da se primene i kada menjate kurs svoje frilens karijere.</p>
<h3>Preispitajte svoje motive</h3>
<p>Prva i najvažnija stvar koju treba da se zapitate pre nego što uradite išta u životu je zašto. “Zašto to radim?” Zbog čega želite da postanete frilenseri? Da li zbog toga što vam treba dodatni prihod? Ili zbog fleksibilnog radnog vremena? Ili da biste mogli da radite sa bilo koje lokacije na svetu? Ili frilensing vidite kao fazu pre nego što steknete dovoljno iskustva da možete da otvorite svoju agenciju.</p>
<blockquote><p>Budite iskreni prema sebi. Popišite koji su to razlozi zbog kojih želite da budete frilenser. Ovo će vam kasnije pomoći pri izboru adekvatnog frilensing posla ili pri razmatranju neke druge alternative.</p></blockquote>
<p>Na primer, ovo su bila moja tri glavna razloga:</p>
<ul>
<li>Prilika da naučim nesto novo i da se intelektualno razvijam u nekom novom pravcu</li>
<li>Fleksibilno radno vreme &#8211; time što sam imala fleksibilno radno vreme bila sam u mogućnosti da izbednem dosadnu “od 9 do 5” rutinu</li>
<li>Tiho i mirno radno okruženje, potpuno u suprotnosti sa teretanama u kojima je uvek bučno</li>
</ul>
<p>Nakon što ste preispitali svoje ciljeve i motive, i sigurni ste da želite da se bavite frilensingom, šta dalje? Moj predlog je naučite nešto što je vezano za WordPress.</p>
<h3>Steknite znanja vezana za WordPress</h3>
<p>Sada se možda pitate zašto baš WordPress. Za početak, zato što WordPress nudi mnoštvo raznovrsnih prilika, i to ne samo za developere.</p>
<p>Iako, kad se pomene WordPress, prvo što će nekome pasti na pamet je ili developer ili web dizajner, postoji veliki broj različitih poslova vezanih za WordPress:</p>
<ul>
<li>Web developer (kodira sajtove, teme i dodatke)</li>
<li>Web implementator (pravi sajtove od gotovih tema bez kodiranja)</li>
<li>Web dizajner (dizajnira skice sajtova, edituje slike i kreira infografike za sajtove)</li>
<li>Korisnička podrška (pomaže klijentima kada se nešto desi sa sajtom)</li>
<li>Održavanje sajtova (redovno održava sajt, kreira bekape, ažurira teme, dodatke i sam WordPress)</li>
<li>WordPress predavač (uči klijente kako da koriste WordPress ili uči druge web profesionalce koji se usavršavaju u nekoj oblasti)</li>
<li>Pisac tekstova za sajtove</li>
<li>Specijalista za aksesibilnost (vodi računa da određeni standardi budu ispunjeni i predlaže rešenja za barijere u aksesibilnosti)</li>
<li>SEO konsultant</li>
<li>Statističar (najčešće radi za velike onlajn prodavnice)</li>
<li>WordPress asistent (unosi novi sadržaj i menja postojći)</li>
<li>Specijalista za migracije (seli sajtove sa servera na server)</li>
<li>Specjalista za web bezbednost</li>
</ul>
<p>Još jedan razlog zbog kojeg mislim da je dobro izabrati WordPress je jaka zajednica koja se okupila oko ovog CMS-a. Redovno se održavaju manja okupljanja (trenutno na daljinu) ali i ona veća koja su nazvana WordCamp (takođe na daljinu do daljnjeg) na kojima možete dobiti pregršt korisnih informacija i pitati druge profesionalce sve što vas interesuje. Zajednica je toliko velika i raznolika da ćete tu pronaći odgovor na skoro svako stručno pitanje. Mnogo je lakse započeti frilens karijeru kada su sjajni ljudi oko vas.</p>
<h3>Planirajte unapred</h3>
<p>Sada kada znate u kom ćete pravcu ići, vreme je da počnete da planirate svoju karijeru.</p>
<p>Postati frilenser je proces. Na početku tog procesa potrebno je da steknete ili dodatno unapredite svoje veštine kojima ćete se istaći u odnosu na konkurenciju. I naravno kako učite i napredujete, moći ćete da prihvatate izazovnije i bolje plaćene poslove.</p>
<p>Na koja se onda znanja fokusirati? Ukoliko već imate neko predznanje za neki od prethodno navedenih poslova, možete se dalje razvijati u tom pravcu i specijalizovati se za tu oblast.</p>
<p>S druge strane, ukoliko nemate nikakvo relevantno predznanje, po mom mišljenju bi najlakše bilo započeti sa poslom koji ima kraći period učenja pa da kasnije nadograđujete znanje. Na primer, možete početi kao pisac tekstova za sajtove ili kao implementator jer se ti poslovi brže savladavaju nego poslovi vezani za SEO ili web development. Onda od pisanja sadržaja za sajtove možete proširiti znanje na SEO a od implementatora vremenom postati developer. Samo budite radoznali i ne prestajte da učite.</p>
<p>Takođe, ukoliko imate specifične talente ili neki hobi kao npr. pisanje ili dizajn, možete da bazirate karijeru oko toga.</p>
<blockquote><p>Najlepše je kad neko zarađuje od nečega što inače voli da radi.</p></blockquote>
<p>Uz to, valjalo bi da proučite tržište pre nego što se “bacite” na učenje.</p>
<p>Na primer, sada nije trenutak da se specijalizujete za pisanje sadržaja koji je vezan za putovanja, a pravi je momenat za sticanje veština koje, na bilo koji način, imaju veze sa onlajn prodavnicama i prodajom putem Interneta.</p>
<p>Ukoliko želite da savladate web development, SEO, web dizajn ili web bezbednost, bitno je da se fokusirate na nove trendove, tehnologije i alate, kako bi vaše veštine bile primenljive i u budućnosti.</p>
<p>Za različite poslove, uslovi rada mogu biti veoma različiti, pa bi i to valjalo imati na umu. Za neke vrste posla, radno vreme je fleksibilno, dok za druge, morate biti raspoloživi tokom određenog doba dana (ako radite kao korisnička podrška, na primer). I ovo bi trebalo da uzmete u obzir kada birate za koju oblast ćete se specijalizovati.</p>
<h3>Konačno! Vreme je za prvi posao!</h3>
<p>Ako ste zaposleni, bilo bi pametno da prištedite novac pre nego što napustite posao da biste se bavili isključivo frilensingom. Druga pametna opcija bi bila da vam na početku frilensing bude dodatni posao uz ono što već radite kako biste videli da li vam takav način rada odgovara ili ne. Ako postanete uspešni i shvatite da je frilensing nešto što odgovara vašim potrebama, tek tada napustite trenutni posao, ne pre toga.</p>
<blockquote><p>Iako neki ljudi profitiraju kada rizikuju, dobro razmislite pre nego što preduzmete korake posle kojih nema nazad.</p></blockquote>
<p>Evo nekoliko taktika koje su mi pomogle kada sam pokušavala da dobijem svoj prvi posao kao frilenser:</p>
<p><i>Koristite platformu za frilensere</i> &#8211; iako nije obavezno, mnogo je lakše doći do prvog posla kada koristite neku platformu namenjenu frilenserima. U to doba, moj izbor je bio Upwork. Svakako, sada postoji i nekoliko drugih platformi pomoću kojih možete brže doći do prvog posla.</p>
<p><i>Triput proverite svoju biografiju</i> &#8211; pretpostavljam da to nije nešto što bi trebalo da pomenem, ali svejedno ću naglasiti, za svaki slučaj. Ne pravite pravopisne greške u biografiji jer ćete time stvoriti utisak da niste temeljni i da će vam se greške lako potkrasti i dok obavljate svoj posao.</p>
<p><i>Predstavite se profesionalno</i> &#8211; Uložite trud da svoje profesionalne veštine predstavite u najboljem mogućem svetlu, ali i dalje budite skromni. Nemojte napisati: &#8220;Najbolji WordPress developer koji nikada nije napisao loš kod&#8221;. Ovo nije zasnovano na dokazima i učiniće da izgledate arogantno. Umesto toga, možete napisati: &#8220;Web programer sa 3 godine iskustva i preko 50 zadovoljnih klijenata, specijalizovan za WordPress.&#8221; Ova izjava je zasnovana na činjenicama i deluje verodostojno.</p>
<p><i>Popunite portfolio</i> &#8211; Ako imate bilo kakav prethodni rad (koji je naravno reprezentativan), trebalo bi da ga dodate u portfolio. Naglasak je na reprezentativan. Ako ne, možete da napravite nekoliko sajtova, dizajnirate skice sajtova ili napišete primere tekstova kako biste prikazali svoje veštine. Ovo se ne odnosi na sve poslove, kao što su SEO konsultanti ili korisnička podrška, ali ako imate priliku da napravite portfolio, iskoristite priliku.</p>
<p><i>Koristite video materijale</i> &#8211; Kratki uvodni video će skrenuti pažnju na vas jer izrada promotivnog video materijala nije nešto što mnogi frilenseri rade. Pomoći će vam da delujete ljudskije i profesionalnije. Za svoje klijente nećete biti samo lista veština i prethodnih iskustava, već stvarna osoba koja zaista ima te veštine i iskustva i koja im pruža određenu uslugu.</p>
<p><i>Imajte detaljnu strategiju pri izboru prvog poslodavca</i> &#8211; Birajte svog prvog poslodavca mudro. Ne mogu dovoljno da naglasim koliko je ovo važno, pa ću vam dati primer. Kada sam se prijavljivala za svoj prvi posao, uzela sam u obzir sledeće:</p>
<ul>
<li>Kako su ovog poslodavca ocenili drugi frilenseri koji su ranije radili za njega</li>
<li>Kako je poslodavac ocenio druge frilensere</li>
<li>Koliko novca je već potrošio na ovoj platformi i da li redovno objavljuje ponude za posao</li>
<li>Broj otvorenih pozicija za ponuđeni posao i broj frilensera koji su se već prijavili. U mom slučaju, posao je imao oko 10 otvorenih radnih mesta, što je povećalo moje šanse za zapošljavanje, čak i u slučaju da je konkurencija velika.</li>
</ul>
<p>Kod prvog posla nije bitan samo novac &#8211; nemojte biti pohlepni. Ako budete dobro ocenjeni, vaš drugi posao može biti plaćen 2-3 puta više. A vaš treći posao može biti vrednovan i do 5 puta više. To je barem bilo moje iskustvo.</p>
<h3>Vodite računa, odrasla ste osoba</h3>
<p>Individualna odgovornost je ključna kada je u pitanju uspeh u frilensingu. Imate slobodu da izaberete za koga ćete raditi, kakav ćete posao prihvatiti i kako ćete isporučiti dogovoreno. A uz slobodu često dolazi i odgovornost. Oni su poput dve strane iste medalje.</p>
<p>Nikada ne smete propustiti rok. Ako niste sigurni da ćete uspeti da završite, nemojte ni prihvatati posao ili, umesto toga, za svaki slučaj imajte nekoga vrlo pouzdanog da priskoči u pomoć ako zatreba. Kada propustite rok, vaš klijent gubi novac i ima puno pravo da se naljuti. Ovo će vrlo verovatno uticati na vaše ocene nakon obavljenog posla. A posledično, i na priliku da dobijete sledeći posao i tako dalje. To može pokrenuti silaznu spiralu za vašu karijeru.</p>
<p>Međutim, svi smo ljudi i mogu se dogoditi nepredvidive stvari. Ako iz nekog razloga niste u mogućnosti da svoj posao obavite u roku, odmah obavestite svog klijenta kako bi imao dovoljno vremena da zaposli nekog drugog.</p>
<p>Takođe je važno da sve bude jasno definisano unapred, pre nego što prihvatite posao. Obavestite svoje klijente o svojim očekivanjima i uverite se da razumete šta oni očekuju od vas. Na primer, ako treba da pišete tekst za sajt, uverite se da znate dužinu teksta u karakterima ili rečima, pitajte da li treba koristiti neke ključne reči i koliko često, koji stil pisanja preferira vaš klijent itd. A ako ste dizajner, navedite koliko je revizija uključeno u cenu.</p>
<blockquote><p>Što je početni dogovor jasniji, to ćete na kraju biti zadovoljniji i vi i vaši klijenti.</p></blockquote>
<p>Ako imate fleksibilno radno vreme, ne dozvolite da vas drugi ljudi prekidaju. Ako se vaši prijatelji i porodica ne bi svakodnevno pojavljivali u vašoj kancelariji da ste bankarski službenik, ne bi trebalo da vas prekidaju ni kada radite od kuće. To je isti princip i na vama je da postavite granice i obavestite ih o svom radnom vremenu. To nije njihov zadatak.</p>
<p>Ovo su neke osnovne smernice koje su mi pomogle u započinjanju karijere frilensera i nadam se da će biti korisne i vama.</p>
<blockquote><p>Ne postoji jedinstveni recept i jedna veličina ne odgovara svima kada je reč o putu kojim treba da krenete.</p></blockquote>
<p>Važno je samo ostati fokusiran na svoje ciljeve i biti otvoren za nove mogućnosti.</p>
<p>Ako ste se pitali zašto više nisam frilenser, evo odgovora. Stalnim sagledavanjem različitih mogućnosti, shvatila sam da frilensing nije jedini način da postignem svoje ciljeve. Postoje kompanije koje nude fleksibilno radno vreme i mirno radno okruženje, istovremeno stimulišući profesionalni rast i kreativno razmišljanje.</p>
<p>Uz to, stekla sam nešto vrlo dragoceno pridruživanjem timu &#8211; moje kolege su postale moj sistem podrške i profesionalno i privatno, i to je ono što mi je nedostajalo dok sam bila frilenser.</p>
<p>Želim vam puno sreće i uspeha u budućnosti, bez obzira na put koji ste odabrali!</p>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/how-to-become-a-freelancer-a-few-things-i-learned-before-i-gave-up/\">How To Become A Freelancer &#8211; A Few Things I Learned Before I Gave Up</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Sep 2020 06:00:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Tijana Andrejic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 20 Oct 2020 04:44:03 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Tue, 20 Oct 2020 04:30:07 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20200501142607\";}","no");
INSERT INTO `wp_options` VALUES("137","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1603212245","no");
INSERT INTO `wp_options` VALUES("138","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1603169045","no");
INSERT INTO `wp_options` VALUES("139","_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b","1603212245","no");
INSERT INTO `wp_options` VALUES("140","_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2020/10/the-month-in-wordpress-september-2020/\'>The Month in WordPress: September 2020</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/woocommerce-tests-new-instagram-shopping-checkout-feature-now-in-closed-beta?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=woocommerce-tests-new-instagram-shopping-checkout-feature-now-in-closed-beta\'>WPTavern: WooCommerce Tests New Instagram Shopping Checkout Feature, Now in Closed Beta</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/past-twenty-wordpress-themes-to-get-new-block-patterns?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=past-twenty-wordpress-themes-to-get-new-block-patterns\'>WPTavern: Past Twenty* WordPress Themes To Get New Block Patterns</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/using-the-web-stories-for-wordpress-plugin-you-better-play-by-googles-rules?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=using-the-web-stories-for-wordpress-plugin-you-better-play-by-googles-rules\'>WPTavern: Using the Web Stories for WordPress Plugin? You Better Play By Google’s Rules</a></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("143","finished_updating_comment_type","1","yes");
INSERT INTO `wp_options` VALUES("144","current_theme","BlankSlate","yes");
INSERT INTO `wp_options` VALUES("145","theme_mods_blankslate","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:9:\"main-menu\";i:5;}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `wp_options` VALUES("146","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("149","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("151","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("152","recently_activated","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("153","cntctfrm_options","a:70:{s:21:\"plugin_option_version\";s:5:\"4.1.5\";s:23:\"display_settings_notice\";i:1;s:13:\"first_install\";i:1603171890;s:22:\"suggest_feature_banner\";i:1;s:10:\"user_email\";s:5:\"admin\";s:12:\"custom_email\";s:24:\"yasdilofficial@gmail.com\";s:12:\"select_email\";s:6:\"custom\";s:10:\"from_email\";s:6:\"custom\";s:17:\"custom_from_email\";s:19:\"wordpress@localhost\";s:10:\"attachment\";i:0;s:23:\"attachment_explanations\";i:1;s:9:\"send_copy\";i:0;s:4:\"gdpr\";i:0;s:10:\"from_field\";s:24:\"Pusat Informasi Covid-19\";s:17:\"select_from_field\";s:6:\"custom\";s:18:\"display_name_field\";i:1;s:21:\"display_address_field\";i:0;s:19:\"display_phone_field\";i:0;s:19:\"required_name_field\";i:1;s:22:\"required_address_field\";i:0;s:20:\"required_email_field\";i:1;s:20:\"required_phone_field\";i:0;s:22:\"required_subject_field\";i:1;s:22:\"required_message_field\";i:1;s:15:\"required_symbol\";s:1:\"*\";s:16:\"display_add_info\";i:1;s:17:\"display_sent_from\";i:1;s:17:\"display_date_time\";i:1;s:11:\"mail_method\";s:7:\"wp-mail\";s:19:\"display_coming_from\";i:1;s:18:\"display_user_agent\";i:1;s:8:\"language\";a:0:{}s:12:\"change_label\";i:0;s:9:\"gdpr_link\";s:0:\"\";s:10:\"name_label\";a:1:{s:7:\"default\";s:5:\"Name:\";}s:13:\"address_label\";a:1:{s:7:\"default\";s:8:\"Address:\";}s:11:\"email_label\";a:1:{s:7:\"default\";s:14:\"Email Address:\";}s:11:\"phone_label\";a:1:{s:7:\"default\";s:13:\"Phone number:\";}s:13:\"subject_label\";a:1:{s:7:\"default\";s:8:\"Subject:\";}s:13:\"message_label\";a:1:{s:7:\"default\";s:8:\"Message:\";}s:16:\"attachment_label\";a:1:{s:7:\"default\";s:11:\"Attachment:\";}s:18:\"attachment_tooltip\";a:1:{s:7:\"default\";s:144:\"Supported file types: HTML, TXT, CSS, GIF, PNG, JPEG, JPG, TIFF, BMP, AI, EPS, PS, CSV, RTF, PDF, DOC, DOCX, XLS, XLSX, ZIP, RAR, WAV, MP3, PPT.\";}s:15:\"send_copy_label\";a:1:{s:7:\"default\";s:14:\"Send me a copy\";}s:10:\"gdpr_label\";a:1:{s:7:\"default\";s:55:\"I consent to having this site collect my personal data.\";}s:16:\"gdpr_text_button\";a:1:{s:7:\"default\";s:10:\"Learn more\";}s:12:\"submit_label\";a:1:{s:7:\"default\";s:6:\"Submit\";}s:10:\"name_error\";a:1:{s:7:\"default\";s:22:\"Your name is required.\";}s:13:\"address_error\";a:1:{s:7:\"default\";s:20:\"Address is required.\";}s:11:\"email_error\";a:1:{s:7:\"default\";s:34:\"A valid email address is required.\";}s:11:\"phone_error\";a:1:{s:7:\"default\";s:25:\"Phone number is required.\";}s:13:\"subject_error\";a:1:{s:7:\"default\";s:20:\"Subject is required.\";}s:13:\"message_error\";a:1:{s:7:\"default\";s:25:\"Message text is required.\";}s:16:\"attachment_error\";a:1:{s:7:\"default\";s:25:\"File format is not valid.\";}s:23:\"attachment_upload_error\";a:1:{s:7:\"default\";s:18:\"File upload error.\";}s:21:\"attachment_move_error\";a:1:{s:7:\"default\";s:31:\"The file could not be uploaded.\";}s:21:\"attachment_size_error\";a:1:{s:7:\"default\";s:23:\"This file is too large.\";}s:13:\"captcha_error\";a:1:{s:7:\"default\";s:28:\"Please fill out the CAPTCHA.\";}s:10:\"form_error\";a:1:{s:7:\"default\";s:44:\"Please make corrections below and try again.\";}s:17:\"action_after_send\";i:1;s:10:\"thank_text\";a:1:{s:7:\"default\";s:28:\"Thank you for contacting us.\";}s:12:\"redirect_url\";s:0:\"\";s:20:\"delete_attached_file\";s:1:\"0\";s:10:\"html_email\";i:1;s:21:\"change_label_in_email\";i:0;s:6:\"layout\";i:1;s:15:\"submit_position\";s:4:\"left\";s:12:\"order_fields\";a:2:{s:12:\"first_column\";a:11:{i:0;s:21:\"cntctfrm_contact_name\";i:1;s:24:\"cntctfrm_contact_address\";i:2;s:22:\"cntctfrm_contact_email\";i:3;s:22:\"cntctfrm_contact_phone\";i:4;s:24:\"cntctfrm_contact_subject\";i:5;s:24:\"cntctfrm_contact_message\";i:6;s:21:\"cntctfrm_contact_gdpr\";i:7;s:27:\"cntctfrm_contact_attachment\";i:8;s:26:\"cntctfrm_contact_send_copy\";i:9;s:18:\"cntctfrm_subscribe\";i:10;s:16:\"cntctfrm_captcha\";}s:13:\"second_column\";a:0:{}}s:5:\"width\";a:3:{s:4:\"type\";s:7:\"default\";s:11:\"input_value\";s:3:\"100\";s:10:\"input_unit\";s:1:\"%\";}s:23:\"active_multi_attachment\";i:0;s:17:\"plugin_db_version\";s:5:\"4.1.1\";}","yes");
INSERT INTO `wp_options` VALUES("154","bstwbsftwppdtplgns_options","a:1:{s:8:\"bws_menu\";a:1:{s:7:\"version\";a:1:{s:36:\"contact-form-plugin/contact_form.php\";s:5:\"2.1.7\";}}}","yes");
INSERT INTO `wp_options` VALUES("157","get_settings_option","a:11:{s:10:\"width_wrjs\";s:3:\"960\";s:12:\"caption_wrjs\";s:1:\"1\";s:11:\"height_wrjs\";s:3:\"350\";s:11:\"effect_wrjs\";s:5:\"slide\";s:14:\"direction_wrjs\";s:0:\"\";s:9:\"post_wrjs\";s:6:\"vslide\";s:10:\"delay_wrjs\";s:4:\"5000\";s:13:\"duration_wrjs\";s:3:\"600\";s:19:\"show_panel_nav_wrjs\";s:1:\"1\";s:10:\"start_wrjs\";i:1;s:17:\"pauseOnHover_wrjs\";s:1:\"1\";}","yes");
INSERT INTO `wp_options` VALUES("158","_transient_timeout_settings_errors","1603171947","no");
INSERT INTO `wp_options` VALUES("159","_transient_settings_errors","a:1:{i:0;a:4:{s:7:\"setting\";s:7:\"general\";s:4:\"code\";s:16:\"settings_updated\";s:7:\"message\";s:15:\"Settings saved.\";s:4:\"type\";s:7:\"success\";}}","no");
INSERT INTO `wp_options` VALUES("161","multiple_slider_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("167","_site_transient_timeout_theme_roots","1603177359","no");
INSERT INTO `wp_options` VALUES("168","_site_transient_theme_roots","a:4:{s:10:\"blankslate\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("169","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("170","aio_wp_security_configs","a:91:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:24:\"yasdilofficial@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"o94kag3qlzyufma8qmj2\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"e2kqricv0z2031ph5m0n\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";i:4;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:2;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:24:\"yasdilofficial@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:24:\"yasdilofficial@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("171","_transient_timeout_users_online","1603177766","no");
INSERT INTO `wp_options` VALUES("172","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1603175966;s:10:\"ip_address\";s:3:\"::1\";}}","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("3","5","_edit_lock","1603170470:1");
INSERT INTO `wp_postmeta` VALUES("4","6","_wp_attached_file","2020/10/56e7cfd4-b7a3-47bb-bb17-5977d4b76406_169.jpg");
INSERT INTO `wp_postmeta` VALUES("5","6","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:366;s:4:\"file\";s:52:\"2020/10/56e7cfd4-b7a3-47bb-bb17-5977d4b76406_169.jpg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:52:\"56e7cfd4-b7a3-47bb-bb17-5977d4b76406_169-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:52:\"56e7cfd4-b7a3-47bb-bb17-5977d4b76406_169-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("6","7","_wp_attached_file","2020/10/ilustrasi-vaksin-corona-3_169.jpeg");
INSERT INTO `wp_postmeta` VALUES("7","7","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:366;s:4:\"file\";s:42:\"2020/10/ilustrasi-vaksin-corona-3_169.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:42:\"ilustrasi-vaksin-corona-3_169-300x169.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:42:\"ilustrasi-vaksin-corona-3_169-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("8","8","_wp_attached_file","2020/10/infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1.jpeg");
INSERT INTO `wp_postmeta` VALUES("9","8","_wp_attachment_metadata","a:5:{s:5:\"width\";i:960;s:6:\"height\";i:1753;s:4:\"file\";s:71:\"2020/10/infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1.jpeg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:71:\"infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1-164x300.jpeg\";s:5:\"width\";i:164;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:72:\"infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1-561x1024.jpeg\";s:5:\"width\";i:561;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:71:\"infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:72:\"infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1-841x1536.jpeg\";s:5:\"width\";i:841;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("10","9","_wp_attached_file","2020/10/logo.png");
INSERT INTO `wp_postmeta` VALUES("11","9","_wp_attachment_metadata","a:5:{s:5:\"width\";i:120;s:6:\"height\";i:120;s:4:\"file\";s:16:\"2020/10/logo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("12","10","_wp_attached_file","2020/10/tes-swab-pedagang-di-kawasan-cipinang-kebembem-3_169.jpeg");
INSERT INTO `wp_postmeta` VALUES("13","10","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:365;s:4:\"file\";s:65:\"2020/10/tes-swab-pedagang-di-kawasan-cipinang-kebembem-3_169.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:65:\"tes-swab-pedagang-di-kawasan-cipinang-kebembem-3_169-300x168.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:65:\"tes-swab-pedagang-di-kawasan-cipinang-kebembem-3_169-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("16","5","_thumbnail_id","10");
INSERT INTO `wp_postmeta` VALUES("17","12","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES("18","12","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("19","12","_menu_item_object_id","12");
INSERT INTO `wp_postmeta` VALUES("20","12","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES("21","12","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("22","12","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("23","12","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("24","12","_menu_item_url","http://localhost/lksn-20-gorontalo/module_cms/wordpress/");
INSERT INTO `wp_postmeta` VALUES("26","13","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("27","13","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("28","13","_menu_item_object_id","2");
INSERT INTO `wp_postmeta` VALUES("29","13","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("30","13","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("31","13","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("32","13","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("33","13","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("35","14","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("36","14","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("37","14","_menu_item_object_id","3");
INSERT INTO `wp_postmeta` VALUES("38","14","_menu_item_object","category");
INSERT INTO `wp_postmeta` VALUES("39","14","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("40","14","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("41","14","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("42","14","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("44","15","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("45","15","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("46","15","_menu_item_object_id","4");
INSERT INTO `wp_postmeta` VALUES("47","15","_menu_item_object","category");
INSERT INTO `wp_postmeta` VALUES("48","15","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("49","15","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("50","15","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("51","15","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("53","16","_menu_item_type","taxonomy");
INSERT INTO `wp_postmeta` VALUES("54","16","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("55","16","_menu_item_object_id","2");
INSERT INTO `wp_postmeta` VALUES("56","16","_menu_item_object","category");
INSERT INTO `wp_postmeta` VALUES("57","16","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("58","16","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("59","16","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("60","16","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("62","18","_wp_attached_file","2020/10/2020_03_20_90132_1584696800._large.jpg");
INSERT INTO `wp_postmeta` VALUES("63","18","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:576;s:4:\"file\";s:46:\"2020/10/2020_03_20_90132_1584696800._large.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"2020_03_20_90132_1584696800._large-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"2020_03_20_90132_1584696800._large-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:46:\"2020_03_20_90132_1584696800._large-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:46:\"2020_03_20_90132_1584696800._large-960x350.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("64","19","_wp_attached_file","2020/10/2020_07_21_100645_1595301415._large.jpg");
INSERT INTO `wp_postmeta` VALUES("65","19","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1360;s:6:\"height\";i:907;s:4:\"file\";s:47:\"2020/10/2020_07_21_100645_1595301415._large.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:47:\"2020_07_21_100645_1595301415._large-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:48:\"2020_07_21_100645_1595301415._large-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:47:\"2020_07_21_100645_1595301415._large-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:47:\"2020_07_21_100645_1595301415._large-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:47:\"2020_07_21_100645_1595301415._large-960x350.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("66","20","_wp_attached_file","2020/10/2020_09_09_103935_1599585809._large.jpg");
INSERT INTO `wp_postmeta` VALUES("67","20","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:47:\"2020/10/2020_09_09_103935_1599585809._large.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:47:\"2020_09_09_103935_1599585809._large-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:48:\"2020_09_09_103935_1599585809._large-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:47:\"2020_09_09_103935_1599585809._large-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:47:\"2020_09_09_103935_1599585809._large-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:47:\"2020_09_09_103935_1599585809._large-960x350.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("68","21","_wp_attached_file","2020/10/hut-tjp.gif");
INSERT INTO `wp_postmeta` VALUES("69","21","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:48;s:4:\"file\";s:19:\"2020/10/hut-tjp.gif\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"hut-tjp-300x36.gif\";s:5:\"width\";i:300;s:6:\"height\";i:36;s:9:\"mime-type\";s:9:\"image/gif\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"hut-tjp-150x48.gif\";s:5:\"width\";i:150;s:6:\"height\";i:48;s:9:\"mime-type\";s:9:\"image/gif\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:18:\"hut-tjp-200x48.gif\";s:5:\"width\";i:200;s:6:\"height\";i:48;s:9:\"mime-type\";s:9:\"image/gif\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("70","22","_wp_attached_file","2020/10/totalcases.png");
INSERT INTO `wp_postmeta` VALUES("71","22","_wp_attachment_metadata","a:5:{s:5:\"width\";i:746;s:6:\"height\";i:431;s:4:\"file\";s:22:\"2020/10/totalcases.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"totalcases-300x173.png\";s:5:\"width\";i:300;s:6:\"height\";i:173;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"totalcases-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:22:\"totalcases-200x200.png\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:22:\"totalcases-746x350.png\";s:5:\"width\";i:746;s:6:\"height\";i:350;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("72","23","_wp_attached_file","2020/10/totaldeaths.png");
INSERT INTO `wp_postmeta` VALUES("73","23","_wp_attachment_metadata","a:5:{s:5:\"width\";i:746;s:6:\"height\";i:431;s:4:\"file\";s:23:\"2020/10/totaldeaths.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"totaldeaths-300x173.png\";s:5:\"width\";i:300;s:6:\"height\";i:173;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"totaldeaths-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:23:\"totaldeaths-200x200.png\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:23:\"totaldeaths-746x350.png\";s:5:\"width\";i:746;s:6:\"height\";i:350;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("74","24","_wp_attached_file","2020/10/totalrecovery.png");
INSERT INTO `wp_postmeta` VALUES("75","24","_wp_attachment_metadata","a:5:{s:5:\"width\";i:746;s:6:\"height\";i:431;s:4:\"file\";s:25:\"2020/10/totalrecovery.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"totalrecovery-300x173.png\";s:5:\"width\";i:300;s:6:\"height\";i:173;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"totalrecovery-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:25:\"totalrecovery-200x200.png\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:25:\"totalrecovery-746x350.png\";s:5:\"width\";i:746;s:6:\"height\";i:350;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("76","17","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("77","17","_thumbnail_id","19");
INSERT INTO `wp_postmeta` VALUES("78","17","_slide_link_url","http://localhost/lksn-20-gorontalo/module_cms/wordpress/2020/10/20/pandemi-bikin-banyak-orang-berburu-produk-alami/");
INSERT INTO `wp_postmeta` VALUES("79","17","_edit_lock","1603171903:1");
INSERT INTO `wp_postmeta` VALUES("80","17","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("81","17","_wp_trash_meta_time","1603172110");
INSERT INTO `wp_postmeta` VALUES("82","17","_wp_desired_post_slug","17");
INSERT INTO `wp_postmeta` VALUES("83","27","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("84","27","_edit_lock","1603172122:1");
INSERT INTO `wp_postmeta` VALUES("85","27","_slide_link_url","http://localhost/lksn-20-gorontalo/module_cms/wordpress/2020/10/20/pandemi-bikin-banyak-orang-berburu-produk-alami/");
INSERT INTO `wp_postmeta` VALUES("86","27","_thumbnail_id","19");
INSERT INTO `wp_postmeta` VALUES("87","29","_wp_attached_file","2020/10/1588320336041-Untitled-design-66.jpeg");
INSERT INTO `wp_postmeta` VALUES("88","29","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:281;s:4:\"file\";s:45:\"2020/10/1588320336041-Untitled-design-66.jpeg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:45:\"1588320336041-Untitled-design-66-300x169.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:45:\"1588320336041-Untitled-design-66-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:45:\"1588320336041-Untitled-design-66-200x200.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("89","30","_wp_attached_file","2020/10/1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER.jpeg");
INSERT INTO `wp_postmeta` VALUES("90","30","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:1066;s:4:\"file\";s:77:\"2020/10/1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER.jpeg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:77:\"1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER-225x300.jpeg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:78:\"1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:77:\"1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:77:\"1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER-200x200.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:77:\"1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER-800x350.jpeg\";s:5:\"width\";i:800;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("91","31","_wp_attached_file","2020/10/1588321542436-Foto-Bayu-Purnama.jpeg");
INSERT INTO `wp_postmeta` VALUES("92","31","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:44:\"2020/10/1588321542436-Foto-Bayu-Purnama.jpeg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"1588321542436-Foto-Bayu-Purnama-300x225.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"1588321542436-Foto-Bayu-Purnama-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:44:\"1588321542436-Foto-Bayu-Purnama-200x200.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:44:\"1588321542436-Foto-Bayu-Purnama-800x350.jpeg\";s:5:\"width\";i:800;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("93","32","_wp_attached_file","2020/10/1588321694416-Foto-Bayu-Purnama-2.jpeg");
INSERT INTO `wp_postmeta` VALUES("94","32","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:1066;s:4:\"file\";s:46:\"2020/10/1588321694416-Foto-Bayu-Purnama-2.jpeg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"1588321694416-Foto-Bayu-Purnama-2-225x300.jpeg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:47:\"1588321694416-Foto-Bayu-Purnama-2-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"1588321694416-Foto-Bayu-Purnama-2-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:46:\"1588321694416-Foto-Bayu-Purnama-2-200x200.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:46:\"1588321694416-Foto-Bayu-Purnama-2-800x350.jpeg\";s:5:\"width\";i:800;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("95","33","_wp_attached_file","2020/10/1588321936950-Foto-Ian-Pranadi.jpeg");
INSERT INTO `wp_postmeta` VALUES("96","33","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:367;s:4:\"file\";s:43:\"2020/10/1588321936950-Foto-Ian-Pranadi.jpeg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:43:\"1588321936950-Foto-Ian-Pranadi-300x138.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:138;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:43:\"1588321936950-Foto-Ian-Pranadi-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:43:\"1588321936950-Foto-Ian-Pranadi-200x200.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:15:\"slide-thumbnail\";a:4:{s:4:\"file\";s:43:\"1588321936950-Foto-Ian-Pranadi-800x350.jpeg\";s:5:\"width\";i:800;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("97","34","_wp_attached_file","2020/10/1601876059594-francisco-gonzalez-m8uejd58gce-unsplash.jpeg");
INSERT INTO `wp_postmeta` VALUES("98","34","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:281;s:4:\"file\";s:66:\"2020/10/1601876059594-francisco-gonzalez-m8uejd58gce-unsplash.jpeg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:66:\"1601876059594-francisco-gonzalez-m8uejd58gce-unsplash-300x169.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:66:\"1601876059594-francisco-gonzalez-m8uejd58gce-unsplash-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:66:\"1601876059594-francisco-gonzalez-m8uejd58gce-unsplash-200x200.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("99","35","_wp_attached_file","2020/10/vice_logo_0.jpg");
INSERT INTO `wp_postmeta` VALUES("100","35","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:337;s:4:\"file\";s:23:\"2020/10/vice_logo_0.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"vice_logo_0-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"vice_logo_0-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:23:\"vice_logo_0-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("101","36","_wp_attached_file","2020/10/vice-1-360x240-1.png");
INSERT INTO `wp_postmeta` VALUES("102","36","_wp_attachment_metadata","a:5:{s:5:\"width\";i:360;s:6:\"height\";i:240;s:4:\"file\";s:28:\"2020/10/vice-1-360x240-1.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"vice-1-360x240-1-300x200.png\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"vice-1-360x240-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"small_thumb\";a:4:{s:4:\"file\";s:28:\"vice-1-360x240-1-200x200.png\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("103","37","_edit_lock","1603173911:1");
INSERT INTO `wp_postmeta` VALUES("106","37","_thumbnail_id","32");
INSERT INTO `wp_postmeta` VALUES("107","39","_edit_lock","1603175814:1");
INSERT INTO `wp_postmeta` VALUES("110","39","_thumbnail_id","30");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES("1","1","2020-10-20 04:43:45","2020-10-20 04:43:45","<!-- wp:paragraph -->
<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>
<!-- /wp:paragraph -->","Hello world!","","publish","open","open","","hello-world","","","2020-10-20 04:43:45","2020-10-20 04:43:45","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2020-10-20 04:43:45","2020-10-20 04:43:45","<!-- wp:paragraph -->
<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...or something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>As a new WordPress user, you should go to <a href=\"http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>
<!-- /wp:paragraph -->","Sample Page","","publish","closed","open","","sample-page","","","2020-10-20 04:43:45","2020-10-20 04:43:45","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2020-10-20 04:43:45","2020-10-20 04:43:45","<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost/lksn-20-gorontalo/module_cms/wordpress.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->","Privacy Policy","","draft","closed","open","","privacy-policy","","","2020-10-20 04:43:45","2020-10-20 04:43:45","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("4","1","2020-10-20 04:43:58","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2020-10-20 04:43:58","0000-00-00 00:00:00","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=4","0","post","","0");
INSERT INTO `wp_posts` VALUES("5","1","2020-10-20 04:58:08","2020-10-20 04:58:08","<!-- wp:paragraph -->
<p>Jakarta, CNN Indonesia -- Gaya hidup alami menjadi tren yang turut naik daun saat pandemi Covid-19. Semakin banyak orang sadar akan kesehatan yang diperlihatkan dengan meningkatnya minat konsumen pada produk-produk alami.<br>Survei terbaru dari FMCG Gurus Indonesia pada Juli 2020 menemukan, pandemi mendorong 95 persen konsumen di Indonesia untuk melakukan banyak upaya supaya tetap sehat. Minat konsumen terhadap produk-produk alami di Indonesia meningkat dari 67 persen pada Mei menjadi 78 persen pada Juli.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>\"Seperti pepatah mengatakan \'kita adalah apa yang kita makan\', semakin banyak konsumen yang mengasosiasikan produk alami dengan dampak baik untuk tubuh karena dinilai lebih aman, enak, dan kualitas yang terjamin,\" tulis FMCG Gurus Indonesia dalam keterangan resmi yang diterima CNNIndonesia.com, Selasa (13/10).</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Survei menemukan bahwa produk alami dianggap autentik, bergizi, berkelanjutan, dan layak dipercaya oleh konsumen. Konsumen umumnya percaya bahwa produk-produk yang sifatnya ramah lingkungan akan memberikan dampak yang baik untuk tubuh mereka.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Selain itu, survei juga memperlihatkan peningkatan minat pola makan khusus seperti plant-based, vegetarian, dan flexitarian. Ketiganya kerap dikaitkan dengan dampak kesehatan yang lebih baik dan ramah lingkungan.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Namun, di sisi lain, demi menyesuaikan diri dengan gaya hidup yang sibuk, masih banyak juga konsumen yang kerap membeli berbagai produk alami kemasan. Konsumen juga kerap tak memperhatikan bahan-bahan apa saja yang terkandung dalam produk yang umumnya tercantum dalam kemasan.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>\"Meski lebih banyak konsumen mengharapkan makanan yang dibuat dari bahan-bahan alami, termasuk pewarna natural, tapi tidak banyak dari konsumen yang menyadari apakah makanan yang dikonsumsinya menggunakan pewarna buatan atau pewarna alami,\" tulis survei.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sayangnya, klaim \'sehat\' atau \'alami\' pada kemasan mungkin tidak menggambarkan informasi penting yang perlu diketahui konsumen. Memperhatikan daftar bahan pada kemasan produk menjadi faktor kunci untuk mengetahui kualitas produk.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>\"Untuk ke depannya, ketika Anda berbelanja bahan makanan, baca lah daftar bahan-bahannya. Pilih lah produk terbaik untuk kesehatan Anda dan keluarga,\" tutup survei.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>(asr)</p>
<!-- /wp:paragraph -->","Pandemi Bikin Banyak Orang Berburu Produk Alami","","publish","open","open","","pandemi-bikin-banyak-orang-berburu-produk-alami","","","2020-10-20 04:58:08","2020-10-20 04:58:08","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=5","0","post","","0");
INSERT INTO `wp_posts` VALUES("6","1","2020-10-20 04:57:15","2020-10-20 04:57:15","","56e7cfd4-b7a3-47bb-bb17-5977d4b76406_169","","inherit","open","closed","","56e7cfd4-b7a3-47bb-bb17-5977d4b76406_169","","","2020-10-20 04:57:15","2020-10-20 04:57:15","","5","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/56e7cfd4-b7a3-47bb-bb17-5977d4b76406_169.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("7","1","2020-10-20 04:57:16","2020-10-20 04:57:16","","ilustrasi-vaksin-corona-3_169","","inherit","open","closed","","ilustrasi-vaksin-corona-3_169","","","2020-10-20 04:57:16","2020-10-20 04:57:16","","5","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/ilustrasi-vaksin-corona-3_169.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("8","1","2020-10-20 04:57:16","2020-10-20 04:57:16","","infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1","","inherit","open","closed","","infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1","","","2020-10-20 04:57:16","2020-10-20 04:57:16","","5","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/infografis-fakta-3-vaksin-corona-buatan-china-incaran-ri-1.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("9","1","2020-10-20 04:57:17","2020-10-20 04:57:17","","logo","","inherit","open","closed","","logo","","","2020-10-20 04:57:17","2020-10-20 04:57:17","","5","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/logo.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("10","1","2020-10-20 04:57:17","2020-10-20 04:57:17","","tes-swab-pedagang-di-kawasan-cipinang-kebembem-3_169","","inherit","open","closed","","tes-swab-pedagang-di-kawasan-cipinang-kebembem-3_169","","","2020-10-20 04:57:17","2020-10-20 04:57:17","","5","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/tes-swab-pedagang-di-kawasan-cipinang-kebembem-3_169.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("11","1","2020-10-20 04:58:08","2020-10-20 04:58:08","<!-- wp:paragraph -->
<p>Jakarta, CNN Indonesia -- Gaya hidup alami menjadi tren yang turut naik daun saat pandemi Covid-19. Semakin banyak orang sadar akan kesehatan yang diperlihatkan dengan meningkatnya minat konsumen pada produk-produk alami.<br>Survei terbaru dari FMCG Gurus Indonesia pada Juli 2020 menemukan, pandemi mendorong 95 persen konsumen di Indonesia untuk melakukan banyak upaya supaya tetap sehat. Minat konsumen terhadap produk-produk alami di Indonesia meningkat dari 67 persen pada Mei menjadi 78 persen pada Juli.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>\"Seperti pepatah mengatakan \'kita adalah apa yang kita makan\', semakin banyak konsumen yang mengasosiasikan produk alami dengan dampak baik untuk tubuh karena dinilai lebih aman, enak, dan kualitas yang terjamin,\" tulis FMCG Gurus Indonesia dalam keterangan resmi yang diterima CNNIndonesia.com, Selasa (13/10).</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Survei menemukan bahwa produk alami dianggap autentik, bergizi, berkelanjutan, dan layak dipercaya oleh konsumen. Konsumen umumnya percaya bahwa produk-produk yang sifatnya ramah lingkungan akan memberikan dampak yang baik untuk tubuh mereka.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Selain itu, survei juga memperlihatkan peningkatan minat pola makan khusus seperti plant-based, vegetarian, dan flexitarian. Ketiganya kerap dikaitkan dengan dampak kesehatan yang lebih baik dan ramah lingkungan.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Namun, di sisi lain, demi menyesuaikan diri dengan gaya hidup yang sibuk, masih banyak juga konsumen yang kerap membeli berbagai produk alami kemasan. Konsumen juga kerap tak memperhatikan bahan-bahan apa saja yang terkandung dalam produk yang umumnya tercantum dalam kemasan.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>\"Meski lebih banyak konsumen mengharapkan makanan yang dibuat dari bahan-bahan alami, termasuk pewarna natural, tapi tidak banyak dari konsumen yang menyadari apakah makanan yang dikonsumsinya menggunakan pewarna buatan atau pewarna alami,\" tulis survei.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sayangnya, klaim \'sehat\' atau \'alami\' pada kemasan mungkin tidak menggambarkan informasi penting yang perlu diketahui konsumen. Memperhatikan daftar bahan pada kemasan produk menjadi faktor kunci untuk mengetahui kualitas produk.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>\"Untuk ke depannya, ketika Anda berbelanja bahan makanan, baca lah daftar bahan-bahannya. Pilih lah produk terbaik untuk kesehatan Anda dan keluarga,\" tutup survei.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>(asr)</p>
<!-- /wp:paragraph -->","Pandemi Bikin Banyak Orang Berburu Produk Alami","","inherit","closed","closed","","5-revision-v1","","","2020-10-20 04:58:08","2020-10-20 04:58:08","","5","http://localhost/lksn-20-gorontalo/module_cms/wordpress/2020/10/20/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("12","1","2020-10-20 05:10:26","2020-10-20 05:10:26","","Home","","publish","closed","closed","","home","","","2020-10-20 05:10:29","2020-10-20 05:10:29","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=12","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("13","1","2020-10-20 05:10:26","2020-10-20 05:10:26"," ","","","publish","closed","closed","","13","","","2020-10-20 05:10:29","2020-10-20 05:10:29","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=13","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("14","1","2020-10-20 05:10:26","2020-10-20 05:10:26"," ","","","publish","closed","closed","","14","","","2020-10-20 05:10:29","2020-10-20 05:10:29","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=14","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("15","1","2020-10-20 05:10:26","2020-10-20 05:10:26"," ","","","publish","closed","closed","","15","","","2020-10-20 05:10:29","2020-10-20 05:10:29","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=15","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("16","1","2020-10-20 05:10:26","2020-10-20 05:10:26"," ","","","publish","closed","closed","","16","","","2020-10-20 05:10:29","2020-10-20 05:10:29","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=16","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("17","1","2020-10-20 05:32:58","2020-10-20 05:32:58","","","","trash","closed","closed","","17__trashed","","","2020-10-20 05:35:10","2020-10-20 05:35:10","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?post_type=vslides&#038;p=17","0","vslides","","0");
INSERT INTO `wp_posts` VALUES("18","1","2020-10-20 05:32:49","2020-10-20 05:32:49","","2020_03_20_90132_1584696800._large","","inherit","open","closed","","2020_03_20_90132_1584696800-_large","","","2020-10-20 05:32:49","2020-10-20 05:32:49","","17","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/2020_03_20_90132_1584696800._large.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("19","1","2020-10-20 05:32:50","2020-10-20 05:32:50","","2020_07_21_100645_1595301415._large","","inherit","open","closed","","2020_07_21_100645_1595301415-_large","","","2020-10-20 05:32:50","2020-10-20 05:32:50","","17","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/2020_07_21_100645_1595301415._large.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("20","1","2020-10-20 05:32:50","2020-10-20 05:32:50","","2020_09_09_103935_1599585809._large","","inherit","open","closed","","2020_09_09_103935_1599585809-_large","","","2020-10-20 05:32:50","2020-10-20 05:32:50","","17","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/2020_09_09_103935_1599585809._large.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("21","1","2020-10-20 05:32:51","2020-10-20 05:32:51","","hut-tjp","","inherit","open","closed","","hut-tjp","","","2020-10-20 05:32:51","2020-10-20 05:32:51","","17","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/hut-tjp.gif","0","attachment","image/gif","0");
INSERT INTO `wp_posts` VALUES("22","1","2020-10-20 05:32:52","2020-10-20 05:32:52","","totalcases","","inherit","open","closed","","totalcases","","","2020-10-20 05:32:52","2020-10-20 05:32:52","","17","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/totalcases.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("23","1","2020-10-20 05:32:52","2020-10-20 05:32:52","","totaldeaths","","inherit","open","closed","","totaldeaths","","","2020-10-20 05:32:52","2020-10-20 05:32:52","","17","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/totaldeaths.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("24","1","2020-10-20 05:32:52","2020-10-20 05:32:52","","totalrecovery","","inherit","open","closed","","totalrecovery","","","2020-10-20 05:32:52","2020-10-20 05:32:52","","17","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/totalrecovery.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("25","1","2020-10-20 05:33:51","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2020-10-20 05:33:51","0000-00-00 00:00:00","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?post_type=vslides&p=25","0","vslides","","0");
INSERT INTO `wp_posts` VALUES("26","1","2020-10-20 05:34:07","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2020-10-20 05:34:07","0000-00-00 00:00:00","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?post_type=vslides&p=26","0","vslides","","0");
INSERT INTO `wp_posts` VALUES("27","1","2020-10-20 05:35:32","2020-10-20 05:35:32","","Covid","","publish","closed","closed","","covid","","","2020-10-20 05:36:38","2020-10-20 05:36:38","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?post_type=vslides&#038;p=27","0","vslides","","0");
INSERT INTO `wp_posts` VALUES("28","1","2020-10-20 05:36:42","2020-10-20 05:36:42","","Covid","","inherit","closed","closed","","27-autosave-v1","","","2020-10-20 05:36:42","2020-10-20 05:36:42","","27","http://localhost/lksn-20-gorontalo/module_cms/wordpress/2020/10/20/27-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("29","1","2020-10-20 05:48:03","2020-10-20 05:48:03","","1588320336041-Untitled-design-66","","inherit","open","closed","","1588320336041-untitled-design-66","","","2020-10-20 05:48:03","2020-10-20 05:48:03","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/1588320336041-Untitled-design-66.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("30","1","2020-10-20 05:48:04","2020-10-20 05:48:04","","1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER","","inherit","open","closed","","1588321411892-00100lrportrait_00100_burst20200329053816497_cover","","","2020-10-20 05:48:04","2020-10-20 05:48:04","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/1588321411892-00100lrPORTRAIT_00100_BURST20200329053816497_COVER.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("31","1","2020-10-20 05:48:04","2020-10-20 05:48:04","","1588321542436-Foto-Bayu-Purnama","","inherit","open","closed","","1588321542436-foto-bayu-purnama","","","2020-10-20 05:48:04","2020-10-20 05:48:04","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/1588321542436-Foto-Bayu-Purnama.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("32","1","2020-10-20 05:48:05","2020-10-20 05:48:05","","1588321694416-Foto-Bayu-Purnama-2","","inherit","open","closed","","1588321694416-foto-bayu-purnama-2","","","2020-10-20 05:48:05","2020-10-20 05:48:05","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/1588321694416-Foto-Bayu-Purnama-2.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("33","1","2020-10-20 05:48:06","2020-10-20 05:48:06","","1588321936950-Foto-Ian-Pranadi","","inherit","open","closed","","1588321936950-foto-ian-pranadi","","","2020-10-20 05:48:06","2020-10-20 05:48:06","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/1588321936950-Foto-Ian-Pranadi.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("34","1","2020-10-20 05:48:06","2020-10-20 05:48:06","","1601876059594-francisco-gonzalez-m8uejd58gce-unsplash","","inherit","open","closed","","1601876059594-francisco-gonzalez-m8uejd58gce-unsplash","","","2020-10-20 05:48:06","2020-10-20 05:48:06","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/1601876059594-francisco-gonzalez-m8uejd58gce-unsplash.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("35","1","2020-10-20 05:48:06","2020-10-20 05:48:06","","vice_logo_0","","inherit","open","closed","","vice_logo_0","","","2020-10-20 05:48:06","2020-10-20 05:48:06","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/vice_logo_0.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("36","1","2020-10-20 05:48:07","2020-10-20 05:48:07","","vice-1-360x240","","inherit","open","closed","","vice-1-360x240","","","2020-10-20 05:48:07","2020-10-20 05:48:07","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/wp-content/uploads/2020/10/vice-1-360x240-1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("37","1","2020-10-20 06:07:11","2020-10-20 06:07:11","<!-- wp:paragraph -->
<p>The Health Ministry announced 4,127 new confirmed COVID-19 cases on Wednesday, bringing the total number of infections nationwide to 344,749. According to data released by the ministry on Wednesday, 129 more people have died of the disease, bringing the death toll to 12,156. The total number of recovered patients has also increased to 267,851. The ministry added 37,044 people were tested on Wednesday, bringing the total number of people tested to 2,415,606.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>COVID-19 in Indonesia<br>Last updated on October 14, 2020<br>Total: 344,749 confirmed, 12,156 dead, 267,851 recovered</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The capital city recorded 1,038 new confirmed cases, bringing the total tally to 90,266. Meanwhile, West Java reported 442 new cases, West Sumatra 351, Riau 300, East Java 299 and Central Java 286. The virus has spread to all of the country\'s 34 provinces. (kmt)</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This article was published in thejakartapost.com with the title \"Indonesia\'s latest official COVID-19 figures - National - The Jakarta Post\". Click to read: https://www.thejakartapost.com/news/2020/03/23/indonesias-latest-covid-19-figures.html.</p>
<!-- /wp:paragraph -->","Indonesia\'s latest official COVID-19 figures","","publish","open","open","","indonesias-latest-official-covid-19-figures","","","2020-10-20 06:07:11","2020-10-20 06:07:11","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=37","0","post","","0");
INSERT INTO `wp_posts` VALUES("38","1","2020-10-20 06:07:11","2020-10-20 06:07:11","<!-- wp:paragraph -->
<p>The Health Ministry announced 4,127 new confirmed COVID-19 cases on Wednesday, bringing the total number of infections nationwide to 344,749. According to data released by the ministry on Wednesday, 129 more people have died of the disease, bringing the death toll to 12,156. The total number of recovered patients has also increased to 267,851. The ministry added 37,044 people were tested on Wednesday, bringing the total number of people tested to 2,415,606.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>COVID-19 in Indonesia<br>Last updated on October 14, 2020<br>Total: 344,749 confirmed, 12,156 dead, 267,851 recovered</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The capital city recorded 1,038 new confirmed cases, bringing the total tally to 90,266. Meanwhile, West Java reported 442 new cases, West Sumatra 351, Riau 300, East Java 299 and Central Java 286. The virus has spread to all of the country\'s 34 provinces. (kmt)</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This article was published in thejakartapost.com with the title \"Indonesia\'s latest official COVID-19 figures - National - The Jakarta Post\". Click to read: https://www.thejakartapost.com/news/2020/03/23/indonesias-latest-covid-19-figures.html.</p>
<!-- /wp:paragraph -->","Indonesia\'s latest official COVID-19 figures","","inherit","closed","closed","","37-revision-v1","","","2020-10-20 06:07:11","2020-10-20 06:07:11","","37","http://localhost/lksn-20-gorontalo/module_cms/wordpress/2020/10/20/37-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("39","1","2020-10-20 06:08:01","2020-10-20 06:08:01","<!-- wp:paragraph -->
<p>Public must help curb COVID-19 misinformation as many still believe they cannot catch it: Task force</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>With the SARS-CoV-2 virus continuing to spread at an alarming rate, more and more public figures are contracting COVID-19, including United States President Donald Trump. Meanwhile, in Indonesia, high-ranked officials, including Transportation Minister Budi Karya Sumadi and Religious Affairs Minister Fachrul Razi, have also tested positive for COVID-19. However, despite the rising number of COVID-19 cases around the globe, a Statistics Indonesia (BPS) survey has discovered that 17 percent of Indonesians believe it is impossible for them to contract the disease. “It is a huge number,” said national COVID-19 task force chief Doni Monardo during a virtual event on Friday. Doni explained that given the country’s population of 270 million people, 17 percent meant that 44.9 million people believed they would not catch the virus. He went on to say that a previous survey conducted in July had revealed that there were five provinces with high percentages of COVID-19 ignorance, namely Jakarta, where 30 percent of people believe they will not catch the virus, followed by East Java with 29 percent, Central Java 18 percent, West Java 16 percent and South Kalimantan 14 percent. Meanwhile, the latest survey conducted by BPS from Sept. 7 to 14, involving 90,967 respondents, showed that Maluku and North Sulawesi were ranked first and second in the category, with 29.18 and 27.66 percent, respectively, of respondents from the provinces certain that they would not get coronavirus. Doni said that a lack of public awareness campaigns was a contributing factor to the issue.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>“There are still many people that have yet to receive full information about COVID-19,” he said. With that in mind, Doni encouraged all elements of society to take part in curbing the transmission of COVID-19. During the discussion Doni also mentioned Bali, where, according to the survey, 20.78 percent of people believe they will not contract COVID-19. Doni explained that he had asked Bali Governor I Wayan Koster to involve all elements of society in handling COVID-19. “[When] more people are involved in handling the COVID-19 pandemic, it will directly increase awareness,” he reasoned. When asked about how the government is dealing with misinformation about COVID-19, Doni explained that starting Oct. 1, the national COVID-19 task force had begun a partnership with the Press Council and other journalist associations to work on a COVID-19 awareness program. Moreover, the task force also invited 5,800 journalists from across the archipelago to participate in the Behavior Change Program, which aims to fight misinformation. Doni shared his hopes that this collaboration would help to increase awareness that COVID-19 was real and not a conspiracy. Indonesia has seen a continuously rising number of cases since March. As of Saturday, the country had recorded 328,952 confirmed cases with 251,481 recoveries and 11,765 deaths. (jes) Editor’s note: This article is part of a public campaign by the COVID-19 task force to raise people’s awareness about the pandemic.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This article was published in thejakartapost.com with the title \"Public must help curb COVID-19 misinformation as many still believe they cannot catch it: Task force\". Click to read: https://www.thejakartapost.com/news/2020/10/11/public-must-help-curb-covid-19-misinformation-as-many-still-believe-they-cannot-catch-it-task-force.html.</p>
<!-- /wp:paragraph -->","Public must help curb COVID-19 misinformation as many still believe they cannot catch it Task force","","publish","open","open","","public-must-help-curb-covid-19-misinformation-as-many-still-believe-they-cannot-catch-it-task-force","","","2020-10-20 06:08:01","2020-10-20 06:08:01","","0","http://localhost/lksn-20-gorontalo/module_cms/wordpress/?p=39","0","post","","0");
INSERT INTO `wp_posts` VALUES("40","1","2020-10-20 06:08:01","2020-10-20 06:08:01","<!-- wp:paragraph -->
<p>Public must help curb COVID-19 misinformation as many still believe they cannot catch it: Task force</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>With the SARS-CoV-2 virus continuing to spread at an alarming rate, more and more public figures are contracting COVID-19, including United States President Donald Trump. Meanwhile, in Indonesia, high-ranked officials, including Transportation Minister Budi Karya Sumadi and Religious Affairs Minister Fachrul Razi, have also tested positive for COVID-19. However, despite the rising number of COVID-19 cases around the globe, a Statistics Indonesia (BPS) survey has discovered that 17 percent of Indonesians believe it is impossible for them to contract the disease. “It is a huge number,” said national COVID-19 task force chief Doni Monardo during a virtual event on Friday. Doni explained that given the country’s population of 270 million people, 17 percent meant that 44.9 million people believed they would not catch the virus. He went on to say that a previous survey conducted in July had revealed that there were five provinces with high percentages of COVID-19 ignorance, namely Jakarta, where 30 percent of people believe they will not catch the virus, followed by East Java with 29 percent, Central Java 18 percent, West Java 16 percent and South Kalimantan 14 percent. Meanwhile, the latest survey conducted by BPS from Sept. 7 to 14, involving 90,967 respondents, showed that Maluku and North Sulawesi were ranked first and second in the category, with 29.18 and 27.66 percent, respectively, of respondents from the provinces certain that they would not get coronavirus. Doni said that a lack of public awareness campaigns was a contributing factor to the issue.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>“There are still many people that have yet to receive full information about COVID-19,” he said. With that in mind, Doni encouraged all elements of society to take part in curbing the transmission of COVID-19. During the discussion Doni also mentioned Bali, where, according to the survey, 20.78 percent of people believe they will not contract COVID-19. Doni explained that he had asked Bali Governor I Wayan Koster to involve all elements of society in handling COVID-19. “[When] more people are involved in handling the COVID-19 pandemic, it will directly increase awareness,” he reasoned. When asked about how the government is dealing with misinformation about COVID-19, Doni explained that starting Oct. 1, the national COVID-19 task force had begun a partnership with the Press Council and other journalist associations to work on a COVID-19 awareness program. Moreover, the task force also invited 5,800 journalists from across the archipelago to participate in the Behavior Change Program, which aims to fight misinformation. Doni shared his hopes that this collaboration would help to increase awareness that COVID-19 was real and not a conspiracy. Indonesia has seen a continuously rising number of cases since March. As of Saturday, the country had recorded 328,952 confirmed cases with 251,481 recoveries and 11,765 deaths. (jes) Editor’s note: This article is part of a public campaign by the COVID-19 task force to raise people’s awareness about the pandemic.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This article was published in thejakartapost.com with the title \"Public must help curb COVID-19 misinformation as many still believe they cannot catch it: Task force\". Click to read: https://www.thejakartapost.com/news/2020/10/11/public-must-help-curb-covid-19-misinformation-as-many-still-believe-they-cannot-catch-it-task-force.html.</p>
<!-- /wp:paragraph -->","Public must help curb COVID-19 misinformation as many still believe they cannot catch it Task force","","inherit","closed","closed","","39-revision-v1","","","2020-10-20 06:08:01","2020-10-20 06:08:01","","39","http://localhost/lksn-20-gorontalo/module_cms/wordpress/2020/10/20/39-revision-v1/","0","revision","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");
INSERT INTO `wp_term_relationships` VALUES("5","2","0");
INSERT INTO `wp_term_relationships` VALUES("12","5","0");
INSERT INTO `wp_term_relationships` VALUES("13","5","0");
INSERT INTO `wp_term_relationships` VALUES("14","5","0");
INSERT INTO `wp_term_relationships` VALUES("15","5","0");
INSERT INTO `wp_term_relationships` VALUES("16","5","0");
INSERT INTO `wp_term_relationships` VALUES("17","6","0");
INSERT INTO `wp_term_relationships` VALUES("27","6","0");
INSERT INTO `wp_term_relationships` VALUES("37","3","0");
INSERT INTO `wp_term_relationships` VALUES("37","4","0");
INSERT INTO `wp_term_relationships` VALUES("39","4","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","category","","0","2");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","nav_menu","","0","5");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","multiple_slider","Slider Shortcode is: [wrjs_post_slider=\"slug name\"]","0","1");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Uncategorized","uncategorized","0");
INSERT INTO `wp_terms` VALUES("2","News Update","news-update","0");
INSERT INTO `wp_terms` VALUES("3","COVID-19 Events","covid-19-events","0");
INSERT INTO `wp_terms` VALUES("4","Each selected editor","each-selected-editor","0");
INSERT INTO `wp_terms` VALUES("5","Menu 1","menu-1","0");
INSERT INTO `wp_terms` VALUES("6","covid","covid","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin20");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","text_widget_custom_html,text_widget_paste_html");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"7c4cc1af3ddf423ad6b7bc72a3d89b3498daaefc89e4bbb737a94949bdfb38d0\";a:4:{s:10:\"expiration\";i:1603341833;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36\";s:5:\"login\";i:1603169033;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","4");
INSERT INTO `wp_usermeta` VALUES("18","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","metaboxhidden_nav-menus","a:1:{i:0;s:12:\"add-post_tag\";}");
INSERT INTO `wp_usermeta` VALUES("20","1","wp_user-settings","libraryContent=browse&editor=html");
INSERT INTO `wp_usermeta` VALUES("21","1","wp_user-settings-time","1603172824");
INSERT INTO `wp_usermeta` VALUES("22","1","meta-box-order_vslides","a:3:{s:4:\"side\";s:55:\"submitdiv,multiple_sliderdiv,pageparentdiv,postimagediv\";s:6:\"normal\";s:32:\"slugdiv,wrjs_metabox_link_slider\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `wp_usermeta` VALUES("23","1","screen_layout_vslides","2");
INSERT INTO `wp_usermeta` VALUES("24","2","nickname","20editor");
INSERT INTO `wp_usermeta` VALUES("25","2","first_name","20");
INSERT INTO `wp_usermeta` VALUES("26","2","last_name","editor");
INSERT INTO `wp_usermeta` VALUES("27","2","description","");
INSERT INTO `wp_usermeta` VALUES("28","2","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("29","2","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("30","2","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("31","2","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("32","2","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("33","2","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("34","2","locale","");
INSERT INTO `wp_usermeta` VALUES("35","2","wp_capabilities","a:1:{s:6:\"editor\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("36","2","wp_user_level","7");
INSERT INTO `wp_usermeta` VALUES("37","2","dismissed_wp_pointers","");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES("1","admin20","$P$BsgHt9xdX8MLmMwN6e4Eiv9rhhwTWe.","admin20","yasdilofficial@gmail.com","http://localhost/lksn-20-gorontalo/module_cms/wordpress","2020-10-20 04:43:45","","0","admin20");
INSERT INTO `wp_users` VALUES("2","20editor","$P$B3yyiLqb6BSpHjPGBRTM.4.6.5ah.y.","20editor","adi@gmail.com","http://facebook.com","2020-10-20 05:52:56","1603173177:$P$BXCSbD4z4uYo60FAFSTyZlyR0aQVyY0","0","20 editor");


